/**
 * Hooks réutilisables pour fetcher/muter les données via les API routes MySQL.
 * Remplace @animaapp/playground-react-sdk dans toute l'app.
 */
import { useState, useEffect, useCallback } from "react";

// ── Types alignés sur le schéma Drizzle ───────────────────────────────────────

export interface ApiCustomer {
  id: string;
  orgId: string;
  name: string;
  phone: string | null;
  email: string | null;
  address: string | null;
  city: string | null;
  postalCode: string | null;
  vehicleInfo: string | null;
  vehicles: unknown;
  notes: string | null;
  createdAt: string | null;
  updatedAt: string | null;
}

export interface ApiRepairOrder {
  id: string;
  orgId: string;
  orderNumber: string;
  customerId: string | null;
  customerName: string;
  vehicleInfo: string | null;
  plate: string | null;
  mileage: string | null;
  mechanic: string | null;
  jobDescription: string | null;
  status: string;
  subtotal: string;
  tpsAmount: string;
  tvqAmount: string;
  total: string;
  amountPaid: string;
  date: string | null;
  notes: string | null;
  createdAt: string | null;
  updatedAt: string | null;
}

export interface ApiRepairOrderItem {
  id: string;
  orgId: string;
  repairOrderId: string;
  type: string;
  description: string;
  partNumber: string | null;
  qty: string | null;
  unitPrice: string | null;
  hours: string | null;
  rate: string | null;
  amount: string | null;
  createdAt: string | null;
}

export interface ApiAppointment {
  id: string;
  orgId: string;
  customerId: string | null;
  customerName: string;
  phone: string | null;
  vehicleInfo: string | null;
  service: string | null;
  date: string;
  time: string | null;
  duration: number | null;
  mechanic: string | null;
  status: string;
  notes: string | null;
  createdAt: string | null;
  updatedAt: string | null;
}

export interface ApiInventoryItem {
  id: string;
  orgId: string;
  name: string;
  partNumber: string | null;
  category: string | null;
  brand: string | null;
  unit: string | null;
  price: string | null;
  unitCost: string;
  unitPrice: string;
  qty: number;
  minQty: number | null;
  supplier: string | null;
  location: string | null;
  notes: string | null;
  createdAt: string | null;
  updatedAt: string | null;
}

export interface ApiSupplier {
  id: string;
  orgId: string;
  name: string;
  companyName: string;
  contactName: string | null;
  phone: string | null;
  email: string | null;
  address: string | null;
  city: string | null;
  postalCode: string | null;
  website: string | null;
  accountNumber: string | null;
  cardImageUrl: string | null;
  tags: string | null;
  category: string | null;
  notes: string | null;
  createdAt: string | null;
  updatedAt: string | null;
}

// ── Generic fetch hook ─────────────────────────────────────────────────────────

function useApiFetch<T>(url: string | null) {
  const [data, setData] = useState<T[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const refetch = useCallback(async () => {
    if (!url) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json();
      setData(Array.isArray(json) ? json : []);
    } catch (e) {
      setError(String(e));
    } finally {
      setLoading(false);
    }
  }, [url]);

  useEffect(() => {
    refetch();
  }, [refetch]);

  return { data, isPending: loading, error, refetch };
}

// ── Generic mutation helpers ───────────────────────────────────────────────────

async function apiPost<T>(url: string, body: Partial<T>): Promise<T> {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function apiPut<T>(url: string, body: Partial<T>): Promise<T> {
  const res = await fetch(url, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function apiDelete(url: string): Promise<void> {
  const res = await fetch(url, { method: "DELETE" });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
}

// ── Customers ──────────────────────────────────────────────────────────────────

export function useApiCustomers(orgId: string | undefined) {
  const url = orgId ? `/api/customers?orgId=${encodeURIComponent(orgId)}` : null;
  const result = useApiFetch<ApiCustomer>(url);
  const create = (body: Partial<ApiCustomer>) => apiPost<ApiCustomer>("/api/customers", body);
  const update = (id: string, body: Partial<ApiCustomer>) => apiPut<ApiCustomer>(`/api/customers/${id}`, body);
  const remove = (id: string) => apiDelete(`/api/customers/${id}`);
  return { ...result, create, update, remove };
}

export async function fetchCustomers(orgId: string): Promise<ApiCustomer[]> {
  const res = await fetch(`/api/customers?orgId=${encodeURIComponent(orgId)}`);
  if (!res.ok) return [];
  return res.json();
}

// ── Repair Orders ──────────────────────────────────────────────────────────────

export function useApiRepairOrders(orgId: string | undefined) {
  const url = orgId ? `/api/repair-orders?orgId=${encodeURIComponent(orgId)}` : null;
  const result = useApiFetch<ApiRepairOrder>(url);
  const create = (body: Partial<ApiRepairOrder>) => apiPost<ApiRepairOrder>("/api/repair-orders", body);
  const update = (id: string, body: Partial<ApiRepairOrder>) => apiPut<ApiRepairOrder>(`/api/repair-orders/${id}`, body);
  const remove = (id: string) => apiDelete(`/api/repair-orders/${id}`);
  return { ...result, create, update, remove };
}

export async function fetchRepairOrders(orgId: string): Promise<ApiRepairOrder[]> {
  const res = await fetch(`/api/repair-orders?orgId=${encodeURIComponent(orgId)}`);
  if (!res.ok) return [];
  return res.json();
}

// ── Repair Order Items ─────────────────────────────────────────────────────────

export function useApiRepairOrderItems(repairOrderId: string | undefined) {
  const url = repairOrderId ? `/api/repair-order-items?repairOrderId=${encodeURIComponent(repairOrderId)}` : null;
  const result = useApiFetch<ApiRepairOrderItem>(url);
  const create = (body: Partial<ApiRepairOrderItem>) => apiPost<ApiRepairOrderItem>("/api/repair-order-items", body);
  const remove = (id: string) => apiDelete(`/api/repair-order-items/${id}`);
  return { ...result, create, remove };
}

export async function fetchRepairOrderItems(repairOrderId: string): Promise<ApiRepairOrderItem[]> {
  const res = await fetch(`/api/repair-order-items?repairOrderId=${encodeURIComponent(repairOrderId)}`);
  if (!res.ok) return [];
  return res.json();
}

// ── Appointments ───────────────────────────────────────────────────────────────

export function useApiAppointments(orgId: string | undefined) {
  const url = orgId ? `/api/appointments?orgId=${encodeURIComponent(orgId)}` : null;
  const result = useApiFetch<ApiAppointment>(url);
  const create = (body: Partial<ApiAppointment>) => apiPost<ApiAppointment>("/api/appointments", body);
  const update = (id: string, body: Partial<ApiAppointment>) => apiPut<ApiAppointment>(`/api/appointments/${id}`, body);
  const remove = (id: string) => apiDelete(`/api/appointments/${id}`);
  return { ...result, create, update, remove };
}

// ── Inventory ──────────────────────────────────────────────────────────────────

export function useApiInventory(orgId: string | undefined) {
  const url = orgId ? `/api/inventory?orgId=${encodeURIComponent(orgId)}` : null;
  const result = useApiFetch<ApiInventoryItem>(url);
  const create = (body: Partial<ApiInventoryItem>) => apiPost<ApiInventoryItem>("/api/inventory", body);
  const update = (id: string, body: Partial<ApiInventoryItem>) => apiPut<ApiInventoryItem>(`/api/inventory/${id}`, body);
  const remove = (id: string) => apiDelete(`/api/inventory/${id}`);
  return { ...result, create, update, remove };
}

// ── Suppliers ──────────────────────────────────────────────────────────────────

export function useApiSuppliers(orgId: string | undefined) {
  const url = orgId ? `/api/suppliers?orgId=${encodeURIComponent(orgId)}` : null;
  const result = useApiFetch<ApiSupplier>(url);
  const create = (body: Partial<ApiSupplier>) => apiPost<ApiSupplier>("/api/suppliers", body);
  const update = (id: string, body: Partial<ApiSupplier>) => apiPut<ApiSupplier>(`/api/suppliers/${id}`, body);
  const remove = (id: string) => apiDelete(`/api/suppliers/${id}`);
  return { ...result, create, update, remove };
}
