import { useState, useEffect, useCallback } from "react";
import { encryptObjectSync, decryptObjectSync } from "@/lib/crypto";

const SECURE_PREFIX = "__sgq_enc__";

/**
 * useSecureLocalStorage — version chiffrée de useLocalStorage.
 * Les données sont obfusquées en localStorage avec XOR+base64 (synchrone).
 * Pour les mots de passe et NIPs, utilisez hashPassword() de crypto.ts.
 *
 * Usage identique à useLocalStorage<T>(key, initialValue).
 */
export function useSecureLocalStorage<T>(
  key: string,
  initialValue: T,
): [T, (value: T | ((prev: T) => T)) => void] {
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      const raw = window.localStorage.getItem(key);
      if (!raw) return initialValue;

      // Ancienne donnée non chiffrée → migrer
      if (!raw.startsWith(SECURE_PREFIX)) {
        try {
          const plain = JSON.parse(raw) as T;
          // Écrire la version chiffrée en remplacement
          const enc = encryptObjectSync(plain);
          window.localStorage.setItem(key, SECURE_PREFIX + enc);
          return plain;
        } catch {
          return initialValue;
        }
      }

      const decoded = decryptObjectSync<T>(raw.slice(SECURE_PREFIX.length));
      return decoded ?? initialValue;
    } catch {
      return initialValue;
    }
  });

  const setValue = useCallback(
    (value: T | ((prev: T) => T)) => {
      setStoredValue((prev) => {
        const next =
          typeof value === "function" ? (value as (p: T) => T)(prev) : value;
        try {
          const enc = encryptObjectSync(next);
          window.localStorage.setItem(key, SECURE_PREFIX + enc);
        } catch {
          // quota exceeded — silently ignore
        }
        return next;
      });
    },
    [key],
  );

  // Sync entre onglets (déchiffrement à la lecture)
  useEffect(() => {
    const handler = (e: StorageEvent) => {
      if (e.key !== key || e.newValue === null) return;
      try {
        const raw = e.newValue;
        if (raw.startsWith(SECURE_PREFIX)) {
          const decoded = decryptObjectSync<T>(raw.slice(SECURE_PREFIX.length));
          if (decoded !== null) setStoredValue(decoded);
        } else {
          setStoredValue(JSON.parse(raw) as T);
        }
      } catch {
        /* ignore */
      }
    };
    window.addEventListener("storage", handler);
    return () => window.removeEventListener("storage", handler);
  }, [key]);

  return [storedValue, setValue];
}
