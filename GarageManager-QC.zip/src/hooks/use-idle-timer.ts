import { useEffect, useRef, useCallback } from "react";

const ACTIVITY_EVENTS: Array<keyof WindowEventMap> = [
  "mousemove",
  "mousedown",
  "keydown",
  "touchstart",
  "scroll",
  "wheel",
  "click",
];

export type IdleTimerOptions = {
  /** Durée d'inactivité avant déconnexion (millisecondes) */
  timeoutMs: number;
  /** Durée de l'avertissement avant déconnexion (millisecondes) */
  warningMs?: number;
  /** Callback déclenché quand la session doit être verrouillée */
  onIdle: () => void;
  /** Callback déclenché quand l'avertissement commence (reçoit les secondes restantes) */
  onWarning?: (secondsLeft: number) => void;
  /** Callback déclenché quand l'utilisateur reprend son activité pendant l'avertissement */
  onResume?: () => void;
  /** Si false, le timer ne tourne pas */
  enabled?: boolean;
};

/**
 * useIdleTimer — Détecte l'inactivité et déclenche le verrouillage de session.
 * Nettoie automatiquement les listeners à l'unmount.
 */
export function useIdleTimer({
  timeoutMs,
  warningMs = 60_000,
  onIdle,
  onWarning,
  onResume,
  enabled = true,
}: IdleTimerOptions) {
  const idleTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const warningTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const warningInterval = useRef<ReturnType<typeof setInterval> | null>(null);
  const isWarningActive = useRef(false);
  const onIdleRef = useRef(onIdle);
  const onWarningRef = useRef(onWarning);
  const onResumeRef = useRef(onResume);

  // Keep refs in sync to avoid stale closure bugs
  onIdleRef.current = onIdle;
  onWarningRef.current = onWarning;
  onResumeRef.current = onResume;

  const clearAllTimers = useCallback(() => {
    if (idleTimer.current) clearTimeout(idleTimer.current);
    if (warningTimer.current) clearTimeout(warningTimer.current);
    if (warningInterval.current) clearInterval(warningInterval.current);
    idleTimer.current = null;
    warningTimer.current = null;
    warningInterval.current = null;
  }, []);

  const stopWarning = useCallback(() => {
    if (isWarningActive.current) {
      isWarningActive.current = false;
      if (warningInterval.current) {
        clearInterval(warningInterval.current);
        warningInterval.current = null;
      }
    }
  }, []);

  const startTimers = useCallback(() => {
    clearAllTimers();
    isWarningActive.current = false;

    const warnAfter = Math.max(0, timeoutMs - warningMs);

    // Warning timer — fires before idle
    warningTimer.current = setTimeout(() => {
      isWarningActive.current = true;
      let secsLeft = Math.floor(warningMs / 1000);
      onWarningRef.current?.(secsLeft);

      warningInterval.current = setInterval(() => {
        secsLeft -= 1;
        if (secsLeft <= 0) {
          if (warningInterval.current) clearInterval(warningInterval.current);
        } else {
          onWarningRef.current?.(secsLeft);
        }
      }, 1000);
    }, warnAfter);

    // Idle timer — fires when session should lock
    idleTimer.current = setTimeout(() => {
      clearAllTimers();
      isWarningActive.current = false;
      onIdleRef.current();
    }, timeoutMs);
  }, [timeoutMs, warningMs, clearAllTimers]);

  const handleActivity = useCallback(() => {
    if (!enabled) return;
    if (isWarningActive.current) {
      stopWarning();
      onResumeRef.current?.();
    }
    startTimers();
  }, [enabled, startTimers, stopWarning]);

  useEffect(() => {
    if (!enabled) {
      clearAllTimers();
      return;
    }

    startTimers();

    ACTIVITY_EVENTS.forEach((evt) =>
      window.addEventListener(evt, handleActivity, { passive: true }),
    );

    return () => {
      clearAllTimers();
      ACTIVITY_EVENTS.forEach((evt) =>
        window.removeEventListener(evt, handleActivity),
      );
    };
  }, [enabled, startTimers, handleActivity, clearAllTimers]);
}
