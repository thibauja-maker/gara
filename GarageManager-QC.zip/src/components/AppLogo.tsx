/**
 * AppLogo — affiche le logo GarageManager en s'adaptant au thème.
 * - Mode sombre : logo affiché normalement (fond sombre se fond avec le bg sombre)
 * - Mode clair  : filter invert(1) → fond devient blanc/transparent sur bg clair
 */
import { useTheme } from "@/context/ThemeContext";

interface AppLogoProps {
  className?: string;
  alt?: string;
}

export default function AppLogo({ className = "h-10 w-auto", alt = "GarageManager" }: AppLogoProps) {
  const { theme } = useTheme();
  const isDark = theme.mode === "dark";

  return (
    <img
      src="/assets/4195b6e3-0917-4512-8bbd-ea2cef4adf6f.png"
      alt={alt}
      className={`object-contain shrink-0 transition-all duration-300 ${className}`}
      style={{
        // mix-blend-mode multiply : les pixels sombres/noirs du fond disparaissent sur bg clair
        // En mode sombre : normal, le fond sombre se fond naturellement avec le bg sombre
        mixBlendMode: isDark ? "normal" : "multiply",
      }}
    />
  );
}
