import { useState } from "react";
import {
  X, Gear, Wrench, Bell, Users, CurrencyDollar, Clock,
  CheckCircle, FloppyDisk, PencilSimple, Trash,
} from "@phosphor-icons/react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { useLocalStorage } from "@/hooks/use-local-storage";

type Props = { onClose: () => void; orgId?: string };
type Tab = "general" | "lifts" | "labor" | "notifications" | "users";

const TABS: { id: Tab; label: string; icon: React.ElementType }[] = [
  { id: "general",       label: "Général",          icon: Gear           },
  { id: "lifts",         label: "Lifts",             icon: Wrench         },
  { id: "labor",         label: "Main-d\u2019œuvre", icon: CurrencyDollar },
  { id: "notifications", label: "Notifications",     icon: Bell           },
  { id: "users",         label: "Utilisateurs",      icon: Users          },
];

const ROLES: string[] = [
  "Admin",
  "Chef m\u00e9canicien",
  "M\u00e9canicien",
  "R\u00e9ceptionniste",
  "G\u00e9rant",
  "Apprenti",
];

// ── Persisted types ──────────────────────────────────────────────────────────
export type ShopGeneral = {
  shopName: string;
  softwareName: string;
  accountHolder: string;
  accountHolderRole: string;
  address: string;
  phone: string;
  email: string;
  tpsNumber: string;
  tvqNumber: string;
  currency: string;
  language: string;
  hoursOpen: string;
  hoursClose: string;
  lunchBreak: boolean;
};

export type ShopLift = {
  id: number;
  name: string;
  capacity: string;
  type: string;
  active: boolean;
};

export type LaborRate = {
  id: number;
  label: string;
  rate: number;
};

export type ShopNotification = {
  id: string;
  label: string;
  desc: string;
  checked: boolean;
};

export type NotifChannels = {
  inApp: boolean;
  email: boolean;
  sms: boolean;
};

export type TeamMember = {
  id: number;
  name: string;
  email: string;
  role: string;
  initials: string;
  active: boolean;
};

export type TimeIncrement = "15 min" | "30 min" | "1 heure";

// ── Default values ────────────────────────────────────────────────────────────
const DEFAULT_GENERAL: ShopGeneral = {
  shopName: "Nordic Garage",
  softwareName: "GarageManager",
  accountHolder: "Marc Gagnon",
  accountHolderRole: "Gestionnaire",
  address: "1234 Rue Saint-Jean, Qu\u00e9bec, QC G1R 1R2",
  phone: "(418) 555-0100",
  email: "contact@nordicgarage.ca",
  tpsNumber: "123456789 RT0001",
  tvqNumber: "1234567890 TQ0001",
  currency: "CAD",
  language: "fr-CA",
  hoursOpen: "08:00",
  hoursClose: "18:00",
  lunchBreak: true,
};

const DEFAULT_LIFTS: ShopLift[] = [
  { id: 1, name: "Lift 1", capacity: "5 000 kg", type: "2 colonnes", active: true  },
  { id: 2, name: "Lift 2", capacity: "3 500 kg", type: "Ciseaux",    active: true  },
  { id: 3, name: "Lift 3", capacity: "5 000 kg", type: "2 colonnes", active: false },
];

const DEFAULT_LABOR_RATES: LaborRate[] = [
  { id: 1, label: "Taux standard",   rate: 110 },
  { id: 2, label: "Taux sp\u00e9cialis\u00e9", rate: 135 },
  { id: 3, label: "Diagnostic",      rate: 95  },
];

const DEFAULT_NOTIFICATIONS: ShopNotification[] = [
  { id: "wo_created",   label: "Ordre de travail cr\u00e9\u00e9",     desc: "Alerte \u00e0 la cr\u00e9ation d\u2019un nouvel OT",     checked: true  },
  { id: "wo_done",      label: "Ordre de travail compl\u00e9t\u00e9", desc: "Alerte quand un OT est marqu\u00e9 termin\u00e9",        checked: true  },
  { id: "invoice_late", label: "Facture en retard",                   desc: "Rappel si facture impay\u00e9e > 30 jours",             checked: true  },
  { id: "appt_1h",      label: "Rendez-vous dans 1 heure",           desc: "Notification 60 min avant chaque RV",                  checked: false },
  { id: "stock_low",    label: "Inventaire bas",                      desc: "Alerte quand le stock est sous le minimum",            checked: true  },
  { id: "est_expired",  label: "Estimation expir\u00e9e",             desc: "Rappel quand une estimation expire",                   checked: false },
];

const DEFAULT_NOTIF_CHANNELS: NotifChannels = { inApp: true, email: true, sms: false };

const DEFAULT_MEMBERS: TeamMember[] = [
  { id: 1, name: "Marc Gagnon",    email: "marc@garagemanager.ca",   role: "Admin",             initials: "MG", active: true  },
  { id: 2, name: "Julie Gagnon",   email: "julie@garagemanager.ca",  role: "M\u00e9canicien",   initials: "JG", active: true  },
  { id: 3, name: "Marc Tremblay",  email: "marc.t@garagemanager.ca", role: "M\u00e9canicien",   initials: "MT", active: true  },
  { id: 4, name: "Sophie Leblanc", email: "sophie@garagemanager.ca", role: "R\u00e9ceptionniste", initials: "SL", active: false },
];

const DEFAULT_TIME_INCREMENT: TimeIncrement = "30 min";

// ── Helpers ───────────────────────────────────────────────────────────────────
function getInitials(name: string) {
  return name.split(" ").map((w) => w[0] ?? "").join("").toUpperCase().slice(0, 2);
}

// ── Component ─────────────────────────────────────────────────────────────────
export default function ShopSettingsModal({ onClose, orgId = "default" }: Props) {
  const [tab, setTab]     = useState<Tab>("general");
  const [saved, setSaved] = useState(false);

  // ── Persisted state — préfixé par orgId pour isolation totale ───────────
  const [general,       setGeneralStored] = useLocalStorage<ShopGeneral>      (`garagemanager_${orgId}_shop_general`,   DEFAULT_GENERAL);
  const [lifts,         setLiftsStored]   = useLocalStorage<ShopLift[]>        (`garagemanager_${orgId}_shop_lifts`,     DEFAULT_LIFTS);
  const [laborRates,    setLaborStored]   = useLocalStorage<LaborRate[]>       (`garagemanager_${orgId}_shop_labor`,     DEFAULT_LABOR_RATES);
  const [notifRules,    setNotifRules]    = useLocalStorage<ShopNotification[]>(`garagemanager_${orgId}_shop_notifs`,    DEFAULT_NOTIFICATIONS);
  const [notifChan,     setNotifChan]     = useLocalStorage<NotifChannels>     (`garagemanager_${orgId}_shop_notif_chan`, DEFAULT_NOTIF_CHANNELS);
  const [members,       setMembers]       = useLocalStorage<TeamMember[]>      (`garagemanager_${orgId}_shop_members`,   DEFAULT_MEMBERS);
  const [timeIncrement, setTimeIncrement] = useLocalStorage<TimeIncrement>     (`garagemanager_${orgId}_shop_time_inc`,  DEFAULT_TIME_INCREMENT);

  // ── Local drafts ─────────────────────────────────────────────────────────
  const [draftGeneral,    setDraftGeneral]    = useState<ShopGeneral>(general);
  const [draftLifts,      setDraftLifts]      = useState<ShopLift[]>(lifts);
  const [draftLabor,      setDraftLabor]      = useState<LaborRate[]>(laborRates);
  const [draftNotifRules, setDraftNotifRules] = useState<ShopNotification[]>(notifRules);
  const [draftNotifChan,  setDraftNotifChan]  = useState<NotifChannels>(notifChan);
  const [draftMembers,    setDraftMembers]    = useState<TeamMember[]>(members);
  const [draftTimeInc,    setDraftTimeInc]    = useState<TimeIncrement>(timeIncrement);

  // ── UI-only states ────────────────────────────────────────────────────────
  const [deleteLiftConfirm, setDeleteLiftConfirm] = useState<number | null>(null);
  const [editingMember, setEditingMember] = useState<TeamMember | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);
  const [inviteOpen,    setInviteOpen]    = useState(false);
  const [invite,        setInvite]        = useState({ name: "", email: "", role: "M\u00e9canicien" });

  // ── Save all drafts → localStorage ───────────────────────────────────────
  const handleSave = () => {
    setGeneralStored(draftGeneral);
    setLiftsStored(draftLifts);
    setLaborStored(draftLabor);
    setNotifRules(draftNotifRules);
    setNotifChan(draftNotifChan);
    setMembers(draftMembers);
    setTimeIncrement(draftTimeInc);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const gField = (key: keyof ShopGeneral) => ({
    value: draftGeneral[key] as string,
    onChange: (e: React.ChangeEvent<HTMLInputElement>) =>
      setDraftGeneral((p) => ({ ...p, [key]: e.target.value })),
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div
        className="relative z-10 w-full max-w-2xl bg-card border border-border rounded-2xl shadow-2xl overflow-hidden flex flex-col"
        style={{ maxHeight: "88vh" }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
              <Gear size={15} weight="duotone" className="text-primary" />
            </div>
            <div>
              <h2 className="text-[15px] font-semibold text-foreground">Paramètres D'atelier</h2>
              <p className="text-[11px] text-muted-foreground">Configuration avanc\u00e9e de votre atelier</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-md text-muted-foreground hover:bg-muted transition-colors"
          >
            <X size={15} weight="bold" />
          </button>
        </div>

        <div className="flex flex-1 min-h-0">
          {/* Sidebar tabs */}
          <div className="w-44 shrink-0 border-r border-border bg-muted/30 py-3 px-2 flex flex-col gap-0.5">
            {TABS.map((t) => {
              const Icon = t.icon;
              return (
                <button
                  key={t.id}
                  onClick={() => setTab(t.id)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-[13px] font-medium transition-all text-left ${
                    tab === t.id
                      ? "bg-primary text-primary-foreground shadow-sm"
                      : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  }`}
                >
                  <Icon size={14} weight="duotone" />
                  {t.label}
                </button>
              );
            })}
          </div>

          {/* Tab content */}
          <div className="flex-1 overflow-y-auto px-6 py-5">

            {/* ── GÉNÉRAL ──────────────────────────────────────────────── */}
            {tab === "general" && (
              <div className="space-y-5">
                <div>
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">
                    Informations de l&#39;atelier
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label className="text-xs text-muted-foreground">Nom de l&#39;atelier</Label>
                      <Input {...gField("shopName")} className="h-9 text-sm rounded-lg" />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-xs text-muted-foreground">Nom du logiciel</Label>
                      <Input {...gField("softwareName")} className="h-9 text-sm rounded-lg" placeholder="ex : Ledger" />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-xs text-muted-foreground">Nom du titulaire du compte</Label>
                      <Input {...gField("accountHolder")} className="h-9 text-sm rounded-lg" placeholder="ex : Marc Gagnon" />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-xs text-muted-foreground">Titre du titulaire</Label>
                      <Input {...gField("accountHolderRole")} className="h-9 text-sm rounded-lg" placeholder="ex : Gestionnaire" />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-xs text-muted-foreground">T&#233;l&#233;phone de l&#39;atelier</Label>
                      <Input {...gField("phone")} className="h-9 text-sm rounded-lg" />
                    </div>
                    <div className="sm:col-span-2 space-y-1.5">
                      <Label className="text-xs text-muted-foreground">Adresse</Label>
                      <Input {...gField("address")} className="h-9 text-sm rounded-lg" />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-xs text-muted-foreground">Courriel de contact</Label>
                      <Input {...gField("email")} type="email" className="h-9 text-sm rounded-lg" placeholder="contact@atelier.ca" />
                    </div>
                  </div>
                </div>
                <Separator />
                <div>
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">
                    Num\u00e9ros de taxes
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label className="text-xs text-muted-foreground">N\u00b0 TPS (f\u00e9d\u00e9ral)</Label>
                      <Input {...gField("tpsNumber")} className="h-9 text-sm rounded-lg font-mono" placeholder="123456789 RT0001" />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-xs text-muted-foreground">N\u00b0 TVQ (Qu\u00e9bec)</Label>
                      <Input {...gField("tvqNumber")} className="h-9 text-sm rounded-lg font-mono" placeholder="1234567890 TQ0001" />
                    </div>
                  </div>
                </div>
                <Separator />
                <div>
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">
                    Heures d&#39;ouverture
                  </p>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label className="text-xs text-muted-foreground">Heure d&#39;ouverture</Label>
                      <Input
                        type="time"
                        value={draftGeneral.hoursOpen}
                        onChange={(e) => setDraftGeneral((p) => ({ ...p, hoursOpen: e.target.value }))}
                        className="h-9 text-sm rounded-lg"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-xs text-muted-foreground">Heure de fermeture</Label>
                      <Input
                        type="time"
                        value={draftGeneral.hoursClose}
                        onChange={(e) => setDraftGeneral((p) => ({ ...p, hoursClose: e.target.value }))}
                        className="h-9 text-sm rounded-lg"
                      />
                    </div>
                  </div>
                  <label className="flex items-center gap-2.5 mt-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={draftGeneral.lunchBreak}
                      onChange={(e) => setDraftGeneral((p) => ({ ...p, lunchBreak: e.target.checked }))}
                      className="accent-primary"
                    />
                    <span className="text-sm text-foreground">Pause d\u00eener 12h00 \u2014 13h00</span>
                  </label>
                </div>
              </div>
            )}

            {/* ── LIFTS ─────────────────────────────────────────────────── */}
            {tab === "lifts" && (
              <div className="space-y-4">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                  Configuration des lifts
                </p>
                <div className="space-y-3">
                  {draftLifts.map((lift) => (
                    <div key={lift.id} className="p-4 rounded-xl border border-border bg-background hover:bg-muted/30 transition-colors">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <Wrench size={14} weight="duotone" className="text-primary" />
                          <span className="text-sm font-semibold text-foreground">{lift.name}</span>
                          <Badge
                            className={`text-[10px] px-2 py-0 rounded-full border-0 ${
                              lift.active
                                ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400"
                                : "bg-muted text-muted-foreground"
                            }`}
                          >
                            {lift.active ? "Actif" : "Inactif"}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-3">
                          <button
                            onClick={() =>
                              setDraftLifts((p) =>
                                p.map((l) => l.id === lift.id ? { ...l, active: !l.active } : l)
                              )
                            }
                            className="text-xs text-primary hover:underline"
                          >
                            {lift.active ? "D\u00e9sactiver" : "Activer"}
                          </button>
                          <button
                            onClick={() => setDeleteLiftConfirm(lift.id)}
                            className="w-6 h-6 flex items-center justify-center rounded-md text-muted-foreground hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                            title="Supprimer ce lift"
                          >
                            <Trash size={13} weight="duotone" />
                          </button>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1.5">
                          <Label className="text-xs text-muted-foreground">Nom affich&#233;</Label>
                          <Input
                            value={lift.name}
                            onChange={(e) =>
                              setDraftLifts((p) =>
                                p.map((l) => l.id === lift.id ? { ...l, name: e.target.value } : l)
                              )
                            }
                            className="h-8 text-xs rounded-md"
                          />
                        </div>
                        <div className="space-y-1.5">
                          <Label className="text-xs text-muted-foreground">Type</Label>
                          <Input
                            value={lift.type}
                            onChange={(e) =>
                              setDraftLifts((p) =>
                                p.map((l) => l.id === lift.id ? { ...l, type: e.target.value } : l)
                              )
                            }
                            className="h-8 text-xs rounded-md"
                          />
                        </div>
                        <div className="space-y-1.5">
                          <Label className="text-xs text-muted-foreground">Capacit\u00e9</Label>
                          <Input
                            value={lift.capacity}
                            onChange={(e) =>
                              setDraftLifts((p) =>
                                p.map((l) => l.id === lift.id ? { ...l, capacity: e.target.value } : l)
                              )
                            }
                            className="h-8 text-xs rounded-md"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <button
                  onClick={() =>
                    setDraftLifts((p) => [
                      ...p,
                      {
                        id: Date.now(),
                        name: `Lift ${p.length + 1}`,
                        capacity: "5 000 kg",
                        type: "2 colonnes",
                        active: true,
                      },
                    ])
                  }
                  className="flex items-center gap-1.5 text-xs text-primary hover:underline mt-1"
                >
                  + Ajouter un lift
                </button>

                {/* Delete lift confirm */}
                {deleteLiftConfirm !== null && (
                  <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
                    <div className="absolute inset-0 bg-black/40" onClick={() => setDeleteLiftConfirm(null)} />
                    <div className="relative z-10 w-full max-w-xs bg-card border border-border rounded-2xl shadow-2xl p-5 space-y-4">
                      <div className="text-center space-y-2">
                        <div className="w-11 h-11 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center mx-auto">
                          <Trash size={18} weight="duotone" className="text-red-500" />
                        </div>
                        <h3 className="text-sm font-semibold text-foreground">Supprimer ce lift&#160;?</h3>
                        <p className="text-xs text-muted-foreground">
                          {draftLifts.find((l) => l.id === deleteLiftConfirm)?.name} sera supprim\u00e9 d\u00e9finitivement. Cette action est irr\u00e9versible.
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => setDeleteLiftConfirm(null)}
                          className="flex-1 px-3 py-2 rounded-lg text-sm border border-border text-muted-foreground hover:bg-muted transition-colors"
                        >
                          Annuler
                        </button>
                        <button
                          onClick={() => {
                            setDraftLifts((p) => p.filter((l) => l.id !== deleteLiftConfirm));
                            setDeleteLiftConfirm(null);
                          }}
                          className="flex-1 px-3 py-2 rounded-lg text-sm bg-red-500 text-white hover:bg-red-600 transition-colors"
                        >
                          Supprimer
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* ── MAIN-D'ŒUVRE ──────────────────────────────────────────── */}
            {tab === "labor" && (
              <div className="space-y-4">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                  Taux de main-d&#39;\u0153uvre
                </p>
                <div className="space-y-2">
                  {draftLabor.map((lr) => (
                    <div key={lr.id} className="flex items-center gap-3 p-3 rounded-xl border border-border bg-background">
                      <div className="flex-1">
                        <Input
                          value={lr.label}
                          onChange={(e) =>
                            setDraftLabor((p) =>
                              p.map((r) => r.id === lr.id ? { ...r, label: e.target.value } : r)
                            )
                          }
                          className="h-8 text-sm rounded-md border-transparent bg-transparent px-0 focus:border-border focus:bg-card focus:px-3 transition-all"
                        />
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <Input
                          type="number"
                          value={lr.rate}
                          onChange={(e) =>
                            setDraftLabor((p) =>
                              p.map((r) => r.id === lr.id ? { ...r, rate: parseFloat(e.target.value) || 0 } : r)
                            )
                          }
                          className="h-8 w-20 text-sm rounded-md text-right"
                        />
                        <span className="text-xs text-muted-foreground">$/h</span>
                        <button
                          onClick={() => setDraftLabor((p) => p.filter((r) => r.id !== lr.id))}
                          className="text-muted-foreground hover:text-red-500 transition-colors ml-1"
                        >
                          <X size={13} weight="bold" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
                <button
                  onClick={() =>
                    setDraftLabor((p) => [...p, { id: Date.now(), label: "Nouveau taux", rate: 110 }])
                  }
                  className="flex items-center gap-1.5 text-xs text-primary hover:underline"
                >
                  + Ajouter un taux
                </button>
                <Separator />
                <div className="p-4 rounded-xl bg-muted/40 border border-border">
                  <div className="flex items-center gap-2 mb-2">
                    <Clock size={14} weight="duotone" className="text-primary" />
                    <p className="text-xs font-semibold text-foreground uppercase tracking-wide">
                      Incr\u00e9ment de temps
                    </p>
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    {(["15 min", "30 min", "1 heure"] as TimeIncrement[]).map((v) => (
                      <button
                        key={v}
                        onClick={() => setDraftTimeInc(v)}
                        className={`px-3 py-1.5 rounded-full text-xs border transition-all ${
                          draftTimeInc === v
                            ? "bg-primary text-primary-foreground border-primary"
                            : "border-border text-muted-foreground hover:bg-primary hover:text-primary-foreground hover:border-primary"
                        }`}
                      >
                        {v}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* ── NOTIFICATIONS ─────────────────────────────────────────── */}
            {tab === "notifications" && (
              <div className="space-y-4">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                  R\u00e8gles de notification
                </p>
                <div className="space-y-2">
                  {draftNotifRules.map((n) => (
                    <label
                      key={n.id}
                      className="flex items-start gap-3 p-3 rounded-lg hover:bg-muted/50 cursor-pointer border border-transparent hover:border-border transition-all"
                    >
                      <input
                        type="checkbox"
                        checked={n.checked}
                        onChange={(e) =>
                          setDraftNotifRules((p) =>
                            p.map((r) => r.id === n.id ? { ...r, checked: e.target.checked } : r)
                          )
                        }
                        className="mt-0.5 accent-primary"
                      />
                      <div>
                        <p className="text-sm font-medium text-foreground">{n.label}</p>
                        <p className="text-xs text-muted-foreground">{n.desc}</p>
                      </div>
                    </label>
                  ))}
                </div>
                <Separator />
                <div>
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">
                    Canal de notification
                  </p>
                  <div className="flex gap-2 flex-wrap">
                    {(
                      [
                        { key: "inApp" as const, label: "Dans l\u2019app" },
                        { key: "email" as const, label: "Courriel"        },
                        { key: "sms"   as const, label: "SMS"             },
                      ]
                    ).map((c) => (
                      <label
                        key={c.key}
                        className="flex items-center gap-2 px-3 py-2 rounded-lg border border-border cursor-pointer hover:bg-muted transition-colors text-sm text-foreground"
                      >
                        <input
                          type="checkbox"
                          checked={draftNotifChan[c.key]}
                          onChange={(e) =>
                            setDraftNotifChan((p) => ({ ...p, [c.key]: e.target.checked }))
                          }
                          className="accent-primary"
                        />
                        {c.label}
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* ── UTILISATEURS ──────────────────────────────────────────── */}
            {tab === "users" && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                    Membres de l&#39;&#233;quipe
                  </p>
                  <button
                    onClick={() => {
                      setInvite({ name: "", email: "", role: "M\u00e9canicien" });
                      setInviteOpen(true);
                    }}
                    className="flex items-center gap-1.5 text-xs text-primary border border-primary/40 rounded-lg px-2.5 py-1.5 hover:bg-primary/5 transition-colors"
                  >
                    + Inviter un membre
                  </button>
                </div>

                {/* Invite form */}
                {inviteOpen && (
                  <div className="p-4 rounded-xl border border-primary/30 bg-primary/5 space-y-3">
                        <p className="text-xs font-semibold text-foreground">Nouveau membre de l&#39;&#233;quipe</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <Label className="text-xs text-muted-foreground">Nom complet</Label>
                        <Input
                          value={invite.name}
                          onChange={(e) => setInvite((p) => ({ ...p, name: e.target.value }))}
                          className="h-8 text-sm rounded-md"
                          placeholder="Jean Dupont"
                        />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs text-muted-foreground">Courriel</Label>
                        <Input
                          type="email"
                          value={invite.email}
                          onChange={(e) => setInvite((p) => ({ ...p, email: e.target.value }))}
                          className="h-8 text-sm rounded-md"
                          placeholder="jean@atelier.ca"
                        />
                      </div>
                      <div className="space-y-1 sm:col-span-2">
                        <Label className="text-xs text-muted-foreground">R\u00f4le</Label>
                        <select
                          value={invite.role}
                          onChange={(e) => setInvite((p) => ({ ...p, role: e.target.value }))}
                          className="w-full h-8 text-sm rounded-md border border-border bg-background px-2 text-foreground"
                        >
                          {ROLES.map((r) => (
                            <option key={r} value={r}>{r}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div className="flex gap-2 justify-end">
                      <button
                        onClick={() => setInviteOpen(false)}
                        className="px-3 py-1.5 rounded-lg text-xs border border-border text-muted-foreground hover:bg-muted transition-colors"
                      >
                        Annuler
                      </button>
                      <button
                        onClick={() => {
                          if (!invite.name.trim() || !invite.email.trim()) return;
                          const newMember: TeamMember = {
                            id: Date.now(),
                            name: invite.name.trim(),
                            email: invite.email.trim(),
                            role: invite.role,
                            initials: getInitials(invite.name),
                            active: true,
                          };
                          setDraftMembers((p) => [...p, newMember]);
                          setInviteOpen(false);
                        }}
                        className="px-3 py-1.5 rounded-lg text-xs bg-primary text-primary-foreground hover:opacity-90 transition-opacity"
                      >
                        Ajouter
                      </button>
                    </div>
                  </div>
                )}

                <div className="space-y-2">
                  {draftMembers.map((u) => (
                    <div
                      key={u.id}
                      className="flex items-center gap-3 p-3 rounded-xl border border-border bg-background hover:bg-muted/30 transition-colors group"
                    >
                      <div className="w-9 h-9 rounded-full bg-primary/15 flex items-center justify-center shrink-0">
                        <span className="text-xs font-bold text-primary">{u.initials}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-foreground">{u.name}</p>
                        <p className="text-xs text-muted-foreground">{u.email}</p>
                      </div>
                      <Badge
                        className={`text-[10px] px-2 py-0 rounded-full border-0 shrink-0 ${
                          u.role === "Admin"
                            ? "bg-primary/10 text-primary"
                            : "bg-muted text-muted-foreground"
                        }`}
                      >
                        {u.role}
                      </Badge>
                      <Badge
                        className={`text-[10px] px-2 py-0 rounded-full border-0 shrink-0 ${
                          u.active
                            ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400"
                            : "bg-muted text-muted-foreground"
                        }`}
                      >
                        {u.active ? "Actif" : "Inactif"}
                      </Badge>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => setEditingMember({ ...u })}
                          className="w-7 h-7 flex items-center justify-center rounded-md text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors"
                          title="Modifier"
                        >
                          <PencilSimple size={13} weight="duotone" />
                        </button>
                        <button
                          onClick={() => setDeleteConfirm(u.id)}
                          className="w-7 h-7 flex items-center justify-center rounded-md text-muted-foreground hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                          title="Supprimer"
                        >
                          <Trash size={13} weight="duotone" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Edit member modal */}
                {editingMember && (
                  <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
                    <div className="absolute inset-0 bg-black/40" onClick={() => setEditingMember(null)} />
                    <div className="relative z-10 w-full max-w-sm bg-card border border-border rounded-2xl shadow-2xl p-5 space-y-4">
                      <div className="flex items-center justify-between">
                        <h3 className="text-sm font-semibold text-foreground">Modifier le membre</h3>
                        <button
                          onClick={() => setEditingMember(null)}
                          className="w-7 h-7 flex items-center justify-center rounded-md text-muted-foreground hover:bg-muted transition-colors"
                        >
                          <X size={13} weight="bold" />
                        </button>
                      </div>
                      <div className="space-y-3">
                        <div className="space-y-1">
                          <Label className="text-xs text-muted-foreground">Nom complet</Label>
                          <Input
                            value={editingMember.name}
                            onChange={(e) =>
                              setEditingMember((p) =>
                                p ? { ...p, name: e.target.value, initials: getInitials(e.target.value) } : p
                              )
                            }
                            className="h-9 text-sm rounded-lg"
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs text-muted-foreground">Courriel</Label>
                          <Input
                            type="email"
                            value={editingMember.email}
                            onChange={(e) =>
                              setEditingMember((p) => p ? { ...p, email: e.target.value } : p)
                            }
                            className="h-9 text-sm rounded-lg"
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs text-muted-foreground">R\u00f4le</Label>
                          <select
                            value={editingMember.role}
                            onChange={(e) =>
                              setEditingMember((p) => p ? { ...p, role: e.target.value } : p)
                            }
                            className="w-full h-9 text-sm rounded-lg border border-border bg-background px-3 text-foreground"
                          >
                            {ROLES.map((r) => (
                              <option key={r} value={r}>{r}</option>
                            ))}
                          </select>
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs text-muted-foreground">Statut</Label>
                          <select
                            value={editingMember.active ? "actif" : "inactif"}
                            onChange={(e) =>
                              setEditingMember((p) =>
                                p ? { ...p, active: e.target.value === "actif" } : p
                              )
                            }
                            className="w-full h-9 text-sm rounded-lg border border-border bg-background px-3 text-foreground"
                          >
                            <option value="actif">Actif</option>
                            <option value="inactif">Inactif</option>
                          </select>
                        </div>
                      </div>
                      <div className="flex gap-2 justify-end pt-1">
                        <button
                          onClick={() => setEditingMember(null)}
                          className="px-4 py-2 rounded-lg text-sm border border-border text-muted-foreground hover:bg-muted transition-colors"
                        >
                          Annuler
                        </button>
                        <button
                          onClick={() => {
                            if (!editingMember) return;
                            setDraftMembers((p) =>
                              p.map((m) => m.id === editingMember.id ? editingMember : m)
                            );
                            setEditingMember(null);
                          }}
                          className="px-4 py-2 rounded-lg text-sm bg-primary text-primary-foreground hover:opacity-90 transition-opacity flex items-center gap-1.5"
                        >
                          <CheckCircle size={13} weight="fill" /> Enregistrer
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* Delete confirm */}
                {deleteConfirm !== null && (
                  <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
                    <div className="absolute inset-0 bg-black/40" onClick={() => setDeleteConfirm(null)} />
                    <div className="relative z-10 w-full max-w-xs bg-card border border-border rounded-2xl shadow-2xl p-5 space-y-4">
                      <div className="text-center space-y-2">
                        <div className="w-11 h-11 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center mx-auto">
                          <Trash size={18} weight="duotone" className="text-red-500" />
                        </div>
                        <h3 className="text-sm font-semibold text-foreground">Supprimer ce membre&#160;?</h3>
                        <p className="text-xs text-muted-foreground">
                          {draftMembers.find((m) => m.id === deleteConfirm)?.name} sera retir\u00e9 de l&#39;\u00e9quipe. Cette action est irr\u00e9versible.
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => setDeleteConfirm(null)}
                          className="flex-1 px-3 py-2 rounded-lg text-sm border border-border text-muted-foreground hover:bg-muted transition-colors"
                        >
                          Annuler
                        </button>
                        <button
                          onClick={() => {
                            setDraftMembers((p) => p.filter((m) => m.id !== deleteConfirm));
                            setDeleteConfirm(null);
                          }}
                          className="flex-1 px-3 py-2 rounded-lg text-sm bg-red-500 text-white hover:bg-red-600 transition-colors"
                        >
                          Supprimer
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-border flex items-center justify-between gap-3 bg-muted/20 shrink-0">
          {saved ? (
            <span className="flex items-center gap-1.5 text-xs text-green-600 font-medium">
              <CheckCircle size={13} weight="fill" /> Param\u00e8tres enregistr\u00e9s
            </span>
          ) : (
            <span />
          )}
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={onClose} className="text-sm rounded-lg">
              Annuler
            </Button>
            <Button
              size="sm"
              onClick={handleSave}
              className="text-sm rounded-lg bg-primary text-primary-foreground gap-1.5"
            >
              <FloppyDisk size={13} weight="duotone" /> Enregistrer
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
