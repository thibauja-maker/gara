import { useState, useEffect } from "react";
import { Lock, Timer, SignIn, ShieldWarning } from "@phosphor-icons/react";
import type { WorkstationSession } from "./WorkstationLogin";

type Props = {
  session: WorkstationSession;
  warningSecsLeft: number | null; // null = pas en avertissement, nombre = secondes restantes
  onUnlock: (password: string) => boolean;
  onSwitchUser: () => void;
};

export default function IdleLockScreen({
  session,
  warningSecsLeft,
  onUnlock,
  onSwitchUser,
}: Props) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [attempts, setAttempts] = useState(0);
  const [lockedSecs, setLockedSecs] = useState(0);

  const MAX_UNLOCK_ATTEMPTS = 3;
  const UNLOCK_LOCKOUT_SECS = 30;

  const isLocked = lockedSecs > 0;

  // Compte à rebours du blocage
  useEffect(() => {
    if (lockedSecs <= 0) return;
    const t = setTimeout(() => setLockedSecs((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [lockedSecs]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLocked) return;

    const success = onUnlock(password);
    if (success) {
      setPassword("");
      setError("");
      setAttempts(0);
    } else {
      const next = attempts + 1;
      setAttempts(next);
      setPassword("");
      if (next >= MAX_UNLOCK_ATTEMPTS) {
        setLockedSecs(UNLOCK_LOCKOUT_SECS);
        setError(`Trop de tentatives — accès bloqué ${UNLOCK_LOCKOUT_SECS}s.`);
      } else {
        setError(
          `Mot de passe incorrect. ${MAX_UNLOCK_ATTEMPTS - next} tentative${MAX_UNLOCK_ATTEMPTS - next > 1 ? "s" : ""} restante${MAX_UNLOCK_ATTEMPTS - next > 1 ? "s" : ""}.`,
        );
      }
    }
  };

  // Avertissement (avant verrouillage complet)
  if (warningSecsLeft !== null) {
    return (
      <div className="fixed inset-0 z-[9999] bg-black/60 backdrop-blur-sm flex items-center justify-center p-6">
        <div className="bg-card border border-amber-500/40 rounded-2xl shadow-2xl w-full max-w-sm p-7 text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center mx-auto">
            <Timer size={26} weight="duotone" className="text-amber-500" />
          </div>
          <div>
            <h2 className="text-base font-bold text-foreground">
              Session sur le point d&#39;expirer
            </h2>
            <p className="text-xs text-muted-foreground mt-1">
              Inactivité détectée — verrouillage dans
            </p>
            <p className="text-5xl font-black tabular-nums text-amber-500 mt-3 mb-1">
              {warningSecsLeft}
            </p>
            <p className="text-xs text-muted-foreground">secondes</p>
          </div>
          <p className="text-[11px] text-muted-foreground/70">
            Bougez votre souris ou appuyez sur une touche pour rester connecté.
          </p>
          <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-amber-500 rounded-full transition-all duration-1000"
              style={{ width: `${(warningSecsLeft / 60) * 100}%` }}
            />
          </div>
        </div>
      </div>
    );
  }

  // Écran verrouillé
  return (
    <div className="fixed inset-0 z-[9999] bg-background/95 backdrop-blur-md flex flex-col items-center justify-center p-6">
      <div className="w-full max-w-sm space-y-6">
        {/* Icon + titre */}
        <div className="text-center space-y-2">
          <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto">
            <Lock size={28} weight="duotone" className="text-primary" />
          </div>
          <h1 className="text-xl font-bold text-foreground">
            Session verrouillée
          </h1>
          <p className="text-xs text-muted-foreground">
            Session verrouillée par inactivité
          </p>
        </div>

        {/* Info utilisateur */}
        <div className="flex items-center gap-3 bg-muted/40 border border-border rounded-xl px-4 py-3">
          <div className="w-9 h-9 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold text-sm shrink-0">
            {session.userInitials}
          </div>
          <div className="min-w-0">
            <p className="text-sm font-semibold text-foreground truncate">
              {session.userName}
            </p>
            <p className="text-xs text-muted-foreground">
              {session.userRole} · {session.workstationName}
            </p>
          </div>
        </div>

        {/* Formulaire déverrouillage */}
        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="relative">
            <Lock
              size={14}
              weight="duotone"
              className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
            />
            <input
              type="password"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setError("");
              }}
              placeholder="Mot de passe pour déverrouiller"
              className="w-full h-11 pl-9 pr-4 rounded-xl border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 disabled:opacity-50"
              disabled={isLocked}
              autoFocus
            />
          </div>

          {error && (
            <div className="flex items-center gap-2 text-xs text-red-500 bg-red-50 dark:bg-red-900/20 rounded-xl px-3 py-2 border border-red-200 dark:border-red-800">
              <ShieldWarning size={13} weight="fill" className="shrink-0" />
              {error}
              {isLocked && lockedSecs > 0 && (
                <span className="font-semibold ml-auto">{lockedSecs}s</span>
              )}
            </div>
          )}

          <button
            type="submit"
            disabled={isLocked || !password}
            className="w-full h-11 rounded-xl bg-primary text-primary-foreground text-sm font-semibold flex items-center justify-center gap-2 hover:opacity-90 disabled:opacity-40 transition-all"
          >
            <SignIn size={15} weight="duotone" />
            {isLocked ? `Bloqué (${lockedSecs}s)` : "Déverrouiller"}
          </button>
        </form>

        {/* Changer de session */}
        <div className="text-center pt-1">
          <div className="flex items-center gap-3 mb-3">
            <div className="flex-1 h-px bg-border" />
            <span className="text-[10px] text-muted-foreground/60 uppercase tracking-wider">
              ou
            </span>
            <div className="flex-1 h-px bg-border" />
          </div>
          <button
            onClick={onSwitchUser}
            className="text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center justify-center gap-1.5 mx-auto"
          >
            <Lock size={11} weight="duotone" />
            Changer d&#39;utilisateur (déconnexion totale)
          </button>
        </div>
      </div>
    </div>
  );
}
