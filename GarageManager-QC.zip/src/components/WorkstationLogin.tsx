import { useState } from "react";
import AppLogo from "@/components/AppLogo";
import {
  Lock,
  Eye,
  EyeSlash,
  SignIn,
  Buildings,
  ArrowLeft,
  User,
  WarningCircle,
  Keyhole,
  UserPlus,
  CheckCircle,
  Wrench,
  IdentificationCard } from
"@phosphor-icons/react";
import { useSecureLocalStorage } from "@/hooks/use-secure-local-storage";
import { useMutation } from "@animaapp/playground-react-sdk";
import type { Customer, RepairOrder, RepairOrderItem, Appointment, InventoryItem } from "@/lib/anima-sdk-stub";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

// ── Types ─────────────────────────────────────────────────────────────────────
export type Workstation = {
  id: number;
  name: string;
  description: string;
  icon: string;
  color: string;
  users: WorkstationUser[];
};

export type WorkstationUser = {
  id: number;
  name: string;
  initials: string;
  role: string;
  pin: string;
  username?: string;
  password?: string;
  color: string;
};

export type Organization = {
  id: string;
  name: string;
  subtitle: string;
  icon: string;
  color: string;
  accentClass: string;
};

// ── Organizations ─────────────────────────────────────────────────────────────
export const ORGANIZATIONS: Organization[] = [
{
  id: "jbl",
  name: "Shop Auto J.B.L.",
  subtitle: "Postes atelier & réception",
  icon: "🔧",
  color: "bg-orange-500",
  accentClass: "bg-orange-500"
},
{
  id: "admin",
  name: "Tiboyan Management",
  subtitle: "Administration hors-heures",
  icon: "📊",
  color: "bg-violet-600",
  accentClass: "bg-violet-600"
}];


// ── Default workstations per org ──────────────────────────────────────────────
export const DEFAULT_WORKSTATIONS_JBL: Workstation[] = [
{
  id: 101,
  name: "Réception",
  description: "Accueil clients — Shop Auto J.B.L.",
  icon: "🖥️",
  color: "bg-blue-500",
  users: [
  {
    id: 1,
    name: "Marc Gagnon",
    initials: "MG",
    role: "Admin",
    pin: "1234",
    username: "marc.gagnon",
    password: "Garage2024!",
    color: "bg-primary"
  },
  {
    id: 4,
    name: "Sophie Leblanc",
    initials: "SL",
    role: "Réceptionniste",
    pin: "4321",
    username: "sophie.leblanc",
    password: "Reception1!",
    color: "bg-pink-500"
  }]

},
{
  id: 102,
  name: "Atelier — Lift 1",
  description: "Poste technicien lift 1",
  icon: "🔧",
  color: "bg-orange-500",
  users: [
  {
    id: 2,
    name: "Julie Gagnon",
    initials: "JG",
    role: "Mécanicien",
    pin: "2222",
    username: "julie.gagnon",
    password: "Mecanik22!",
    color: "bg-orange-500"
  }]

},
{
  id: 103,
  name: "Atelier — Lift 2",
  description: "Poste technicien lift 2",
  icon: "⚙️",
  color: "bg-emerald-500",
  users: [
  {
    id: 3,
    name: "Marc Tremblay",
    initials: "MT",
    role: "Mécanicien",
    pin: "3333",
    username: "marc.tremblay",
    password: "Mecanik33!",
    color: "bg-emerald-500"
  }]

},
{
  id: 104,
  name: "Bureau du gérant",
  description: "Gestion et rapports",
  icon: "📋",
  color: "bg-purple-500",
  users: [
  {
    id: 1,
    name: "Marc Gagnon",
    initials: "MG",
    role: "Admin",
    pin: "1234",
    username: "marc.gagnon",
    password: "Garage2024!",
    color: "bg-primary"
  }]

}];


export const DEFAULT_WORKSTATIONS_ADMIN: Workstation[] = [
{
  id: 201,
  name: "Administration",
  description: "Tiboyan Management — hors-heures",
  icon: "📊",
  color: "bg-violet-600",
  users: [
  {
    id: 10,
    name: "Administrateur",
    initials: "AD",
    role: "Admin",
    pin: "0000",
    username: "admin",
    password: "Admin2024!",
    color: "bg-violet-600"
  }]

},
{
  id: 202,
  name: "Comptabilité",
  description: "Facturation et finances",
  icon: "💼",
  color: "bg-indigo-500",
  users: [
  {
    id: 11,
    name: "Comptable",
    initials: "CP",
    role: "Comptable",
    pin: "9999",
    username: "comptable",
    password: "Compta99!",
    color: "bg-indigo-500"
  }]

}];


// ── Session ───────────────────────────────────────────────────────────────────
const SESSION_KEY = "garagemanager_workstation_session";

export type WorkstationSession = {
  orgId: string;
  orgName: string;
  workstationId: number;
  workstationName: string;
  userId: number;
  userName: string;
  userEmail?: string;
  userRole: string;
  userInitials: string;
};

export function getWorkstationSession(): WorkstationSession | null {
  try {
    // Try localStorage first (persistent across browser closes)
    const raw = localStorage.getItem(SESSION_KEY);
    if (raw) return JSON.parse(raw);
    // Fallback: migrate from sessionStorage if present
    const legacy = sessionStorage.getItem(SESSION_KEY);
    if (legacy) {
      localStorage.setItem(SESSION_KEY, legacy);
      sessionStorage.removeItem(SESSION_KEY);
      return JSON.parse(legacy);
    }
    return null;
  } catch {
    return null;
  }
}

export function saveWorkstationSession(session: WorkstationSession) {
  // Always persist to localStorage so session survives tab/browser closes
  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  // Clean up any old sessionStorage entry
  try {
    sessionStorage.removeItem(SESSION_KEY);
  } catch {

    /* noop */}
}

export function clearWorkstationSession() {
  localStorage.removeItem(SESSION_KEY);
  try {
    sessionStorage.removeItem(SESSION_KEY);
  } catch {

    /* noop */}
}

// ── New org registration ──────────────────────────────────────────────────────
export type RegisteredOrg = {
  id: string;
  name: string;
  subtitle: string;
  icon: string;
  adminUsername: string;
  adminPassword: string;
  adminName: string;
  createdAt: string;
};

const REGISTERED_ORGS_KEY = "garagemanager_registered_orgs";

export function getRegisteredOrgs(): RegisteredOrg[] {
  try {
    const raw = localStorage.getItem(REGISTERED_ORGS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveRegisteredOrg(org: RegisteredOrg) {
  const orgs = getRegisteredOrgs();
  orgs.push(org);
  localStorage.setItem(REGISTERED_ORGS_KEY, JSON.stringify(orgs));
}

// orgId slug from shop name
function toOrgSlug(name: string): string {
  return name.
  toLowerCase().
  normalize("NFD").
  replace(/[\u0300-\u036f]/g, "").
  replace(/[^a-z0-9]+/g, "_").
  replace(/^_|_$/g, "").
  slice(0, 20);
}

// ── MAX failed ─────────────────────────────────────────────────────────────────
const MAX_ATTEMPTS = 5;
const LOCKOUT_SECONDS = 30;

// ── Component ─────────────────────────────────────────────────────────────────
type Props = {onLogin: (session: WorkstationSession) => void;};
type Mode = "credentials" | "pin" | "register";
type OrgStep = "choose-org" | "form";

// ── Registration form component ───────────────────────────────────────────────
function RegisterForm({
  onBack,
  onSuccess



}: {onBack: () => void;onSuccess: (session: WorkstationSession) => void;}) {
  const [shopName, setShopName] = useState("");
  const [adminName, setAdminName] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [passwordConfirm, setPasswordConfirm] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [step, setStep] = useState<"form" | "success">("form");
  const [errors, setErrors] = useState<Record<string, string>>({});

  const { create: createCustomer } = useMutation<Customer>("Customer");
  const { create: createRepairOrder } = useMutation<RepairOrder>("RepairOrder");
  const { create: createRepairOrderItem } = useMutation<RepairOrderItem>("RepairOrderItem");
  const { create: createAppointment } = useMutation<Appointment>("Appointment");
  const { create: createInventoryItem } = useMutation<InventoryItem>("InventoryItem");

  const [,] = useSecureLocalStorage<Workstation[]>(
    `garagemanager_workstations_${toOrgSlug(shopName) || "new"}`,
    []
  );

  function validate() {
    const e: Record<string, string> = {};
    if (!shopName.trim()) e.shopName = "Le nom de l&#39;atelier est requis.";
    if (!adminName.trim()) e.adminName = "Votre nom complet est requis.";
    if (!username.trim()) e.username = "L&#39;identifiant est requis.";else
    if (!/^[a-z0-9._-]{3,30}$/.test(username))
    e.username =
    "3 à 30 caractères : lettres minuscules, chiffres, point, tiret.";
    if (password.length < 8) e.password = "Minimum 8 caractères.";
    if (password !== passwordConfirm)
    e.passwordConfirm = "Les mots de passe ne correspondent pas.";
    // Check username uniqueness across existing orgs
    const existing = getRegisteredOrgs();
    if (existing.some((o) => o.adminUsername === username)) {
      e.username = "Cet identifiant est déjà utilisé.";
    }
    // Check orgId uniqueness
    const slug = toOrgSlug(shopName);
    const builtinIds = ORGANIZATIONS.map((o) => o.id);
    if (builtinIds.includes(slug) || existing.some((o) => o.id === slug)) {
      e.shopName =
      "Un atelier avec ce nom existe déjà. Choisissez un nom légèrement différent.";
    }
    return e;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }

    const orgId = toOrgSlug(shopName);
    const nameParts = adminName.trim().split(/\s+/);
    const initials = nameParts.
    map((p) => p[0] ?? "").
    join("").
    toUpperCase().
    slice(0, 2);

    // Create default workstation + admin user for the new org
    const adminUser: WorkstationUser = {
      id: 1,
      name: adminName.trim(),
      initials,
      role: "Admin",
      pin: "0000",
      username: username.trim().toLowerCase(),
      password,
      color: "bg-primary"
    };
    const defaultWs: Workstation = {
      id: Date.now(),
      name: "Réception",
      description: `Accueil clients — ${shopName.trim()}`,
      icon: "🖥️",
      color: "bg-blue-500",
      users: [adminUser]
    };

    // Save workstations for this new org
    localStorage.setItem(
      `garagemanager_workstations_${orgId}`,
      JSON.stringify([defaultWs])
    );

    // Register org
    const newOrg: RegisteredOrg = {
      id: orgId,
      name: shopName.trim(),
      subtitle: "Atelier enregistré",
      icon: "🔧",
      adminUsername: username.trim().toLowerCase(),
      adminPassword: password,
      adminName: adminName.trim(),
      createdAt: new Date().toISOString()
    };
    saveRegisteredOrg(newOrg);

    setStep("success");

    // Seed demo data for the new org
    const seedAndLogin = async () => {
      try {
        const today = new Date();
        const tomorrow = new Date(today);
        tomorrow.setDate(today.getDate() + 1);

        // Demo customer
        const customer = await createCustomer({
          orgId,
          name: "Jean Tremblay",
          phone: "514-555-0100",
          email: "jean.tremblay@exemple.ca",
          vehicleInfo: "Honda Civic 2019",
          vehicles: JSON.stringify(["Honda Civic 2019", "Toyota RAV4 2021"])
        });

        // Demo repair order
        const ro = await createRepairOrder({
          orgId,
          orderNumber: "RO-0001",
          customerName: customer.name,
          vehicleInfo: "Honda Civic 2019",
          status: "En cours",
          subtotal: 280.0,
          tpsAmount: 14.0,
          tvqAmount: 27.93,
          total: 321.93,
          date: today
        });

        // Line items for the repair order
        await createRepairOrderItem({
          orgId,
          repairOrderId: ro.id,
          description: "Vidange d&#39;huile synthétique 5W-30",
          quantity: 1,
          rate: 89.99
        });
        await createRepairOrderItem({
          orgId,
          repairOrderId: ro.id,
          description: "Filtre à huile",
          quantity: 1,
          rate: 24.99
        });
        await createRepairOrderItem({
          orgId,
          repairOrderId: ro.id,
          description: "Main-d&#39;œuvre — vidange complète",
          quantity: 1,
          rate: 165.02
        });

        // Demo appointment
        await createAppointment({
          orgId,
          title: "Inspection freins avant",
          customerName: "Jean Tremblay",
          mechanicName: adminName.trim(),
          bay: "Lift 1",
          date: tomorrow,
          startHour: 9,
          durationH: 1.5,
          status: "scheduled",
          color: "#3b82f6"
        });

        // Demo inventory items
        await createInventoryItem({
          orgId,
          name: "Huile synthétique 5W-30 (L)",
          unit: "litre",
          price: 12.99,
          category: "Huile & Fluides"
        });
        await createInventoryItem({
          orgId,
          name: "Filtre à huile standard",
          unit: "unité",
          price: 14.99,
          category: "Filtres"
        });
        await createInventoryItem({
          orgId,
          name: "Plaquettes de frein avant",
          unit: "jeu",
          price: 64.99,
          category: "Freins"
        });
      } catch {


        // Seed failure is non-blocking — still log in
      }const session: WorkstationSession = {
        orgId,
        orgName: shopName.trim(),
        workstationId: defaultWs.id,
        workstationName: defaultWs.name,
        userId: adminUser.id,
        userName: adminUser.name,
        userRole: "Admin",
        userInitials: initials
      };
      saveWorkstationSession(session);
      onSuccess(session);
    };

    setTimeout(() => {
      seedAndLogin();
    }, 1800);
  };

  if (step === "success") {
    return (
      <div className="bg-card border border-border rounded-2xl shadow-xl p-8 text-center space-y-4">
        <div className="w-14 h-14 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center mx-auto">
          <CheckCircle size={28} weight="fill" className="text-green-500" />
        </div>
        <h2 className="text-base font-bold text-foreground">
          Compte créé avec succès&#160;!
        </h2>
        <p className="text-sm text-muted-foreground">
          Bienvenue dans GarageManager,{" "}
          <span className="font-semibold text-foreground">{adminName}</span>.
          <br />
          Votre atelier{" "}
          <span className="font-semibold text-foreground">{shopName}</span> est
          prêt.
        </p>
        <p className="text-xs text-muted-foreground/70">
          Connexion automatique en cours…
        </p>
      </div>);

  }

  return (
    <div className="bg-card border border-border rounded-2xl shadow-xl p-7 space-y-5">
      <div className="flex items-center gap-2 mb-1">
        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
          <UserPlus size={14} weight="duotone" className="text-primary" />
        </div>
        <div>
          <p className="text-[13px] font-semibold text-foreground">
            Créer un nouveau compte
          </p>
          <p className="text-[11px] text-muted-foreground">
            Enregistrez votre atelier en moins de 2 minutes
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-3">
        {/* Shop name */}
        <div className="space-y-1.5">
          <Label
            htmlFor="reg-shop"
            className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
            
            Nom de l&#39;atelier
          </Label>
          <div className="relative">
            <Wrench
              size={14}
              weight="duotone"
              className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            
            <Input
              id="reg-shop"
              value={shopName}
              onChange={(e) => {
                setShopName(e.target.value);
                setErrors((p) => ({ ...p, shopName: "" }));
              }}
              placeholder="Garage Dupont Montréal"
              className={`pl-9 h-11 text-sm rounded-xl bg-background ${errors.shopName ? "border-red-400" : ""}`} />
            
          </div>
          {errors.shopName &&
          <p className="text-xs text-red-500">{errors.shopName}</p>
          }
        </div>

        {/* Admin full name */}
        <div className="space-y-1.5">
          <Label
            htmlFor="reg-name"
            className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
            
            Votre nom complet
          </Label>
          <div className="relative">
            <IdentificationCard
              size={14}
              weight="duotone"
              className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            
            <Input
              id="reg-name"
              value={adminName}
              onChange={(e) => {
                setAdminName(e.target.value);
                setErrors((p) => ({ ...p, adminName: "" }));
              }}
              placeholder="Jean Dupont"
              className={`pl-9 h-11 text-sm rounded-xl bg-background ${errors.adminName ? "border-red-400" : ""}`} />
            
          </div>
          {errors.adminName &&
          <p className="text-xs text-red-500">{errors.adminName}</p>
          }
        </div>

        {/* Username */}
        <div className="space-y-1.5">
          <Label
            htmlFor="reg-username"
            className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
            
            Identifiant de connexion
          </Label>
          <div className="relative">
            <User
              size={14}
              weight="duotone"
              className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            
            <Input
              id="reg-username"
              value={username}
              onChange={(e) => {
                setUsername(e.target.value.toLowerCase().replace(/\s/g, "."));
                setErrors((p) => ({ ...p, username: "" }));
              }}
              placeholder="jean.dupont"
              className={`pl-9 h-11 text-sm rounded-xl bg-background font-mono ${errors.username ? "border-red-400" : ""}`} />
            
          </div>
          {errors.username &&
          <p className="text-xs text-red-500">{errors.username}</p>
          }
        </div>

        {/* Password */}
        <div className="space-y-1.5">
          <Label
            htmlFor="reg-password"
            className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
            
            Mot de passe
          </Label>
          <div className="relative">
            <Lock
              size={14}
              weight="duotone"
              className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            
            <Input
              id="reg-password"
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setErrors((p) => ({ ...p, password: "", passwordConfirm: "" }));
              }}
              placeholder="Minimum 8 caractères"
              className={`pl-9 pr-10 h-11 text-sm rounded-xl bg-background ${errors.password ? "border-red-400" : ""}`} />
            
            <button
              type="button"
              onClick={() => setShowPassword((v) => !v)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              tabIndex={-1}>
              
              {showPassword ? <EyeSlash size={15} /> : <Eye size={15} />}
            </button>
          </div>
          {errors.password &&
          <p className="text-xs text-red-500">{errors.password}</p>
          }
        </div>

        {/* Password confirm */}
        <div className="space-y-1.5">
          <Label
            htmlFor="reg-confirm"
            className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
            
            Confirmer le mot de passe
          </Label>
          <div className="relative">
            <Lock
              size={14}
              weight="duotone"
              className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            
            <Input
              id="reg-confirm"
              type={showConfirm ? "text" : "password"}
              value={passwordConfirm}
              onChange={(e) => {
                setPasswordConfirm(e.target.value);
                setErrors((p) => ({ ...p, passwordConfirm: "" }));
              }}
              placeholder="••••••••"
              className={`pl-9 pr-10 h-11 text-sm rounded-xl bg-background ${errors.passwordConfirm ? "border-red-400" : ""}`} />
            
            <button
              type="button"
              onClick={() => setShowConfirm((v) => !v)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              tabIndex={-1}>
              
              {showConfirm ? <EyeSlash size={15} /> : <Eye size={15} />}
            </button>
          </div>
          {errors.passwordConfirm &&
          <p className="text-xs text-red-500">{errors.passwordConfirm}</p>
          }
        </div>

        <button
          type="submit"
          disabled={
          !shopName.trim() ||
          !adminName.trim() ||
          !username.trim() ||
          password.length < 8 ||
          password !== passwordConfirm
          }
          className="w-full h-11 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 transition-all bg-primary text-primary-foreground hover:opacity-90 disabled:opacity-40 mt-1">
          
          <UserPlus size={16} weight="duotone" />
          Créer mon compte
        </button>
      </form>

      <div className="pt-1 text-center">
        <button
          onClick={onBack}
          className="flex items-center justify-center gap-1.5 mx-auto text-xs text-muted-foreground hover:text-foreground transition-colors py-1">
          
          <ArrowLeft size={11} /> Retour à la connexion
        </button>
      </div>
    </div>);

}

export default function WorkstationLogin({ onLogin }: Props) {
  // Dynamic orgs from registered accounts
  const [registeredOrgs] = useState<RegisteredOrg[]>(() => getRegisteredOrgs());

  // ── Steps
  const [_orgStep, _setOrgStep] = useState<OrgStep>("choose-org");
  const [_selectedOrg, _setSelectedOrg] = useState<Organization | null>(null);
  const [mode, setMode] = useState<Mode>("credentials");

  // ── Credentials form
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  // ── PIN mode
  const [selectedOrgForPin, setSelectedOrgForPin] =
  useState<Organization | null>(null);
  const [pin, setPin] = useState("");
  const [showPin, setShowPin] = useState(false);
  const [pinOrgStep, setPinOrgStep] = useState<"choose-org" | "enter-pin">(
    "choose-org"
  );

  // ── Error & lockout
  const [error, setError] = useState("");
  const [attempts, setAttempts] = useState(0);
  const [lockedUntil, setLockedUntil] = useState<number | null>(null);
  const [lockedSecsLeft, setLockedSecsLeft] = useState(0);

  const allWorkstations = (orgId: string): Workstation[] => {
    // Always read from localStorage for full isolation per org
    try {
      const raw = localStorage.getItem(`garagemanager_workstations_${orgId}`);
      if (raw) return JSON.parse(raw) as Workstation[];
    } catch {
      // fall through
    }
    // Fallback defaults for built-in demo orgs
    if (orgId === "jbl") return DEFAULT_WORKSTATIONS_JBL;
    if (orgId === "admin") return DEFAULT_WORKSTATIONS_ADMIN;
    return [];
  };

  const getAllOrgs = (): Organization[] => {
    const dynamic: Organization[] = registeredOrgs.map((r) => ({
      id: r.id,
      name: r.name,
      subtitle: r.subtitle,
      icon: r.icon,
      color: "bg-primary",
      accentClass: "bg-primary"
    }));
    return [...ORGANIZATIONS, ...dynamic];
  };

  const getAllUsers = (
  orgId: string)
  : Array<{user: WorkstationUser;ws: Workstation;org: Organization;}> => {
    const allOrgs = getAllOrgs();
    const org = allOrgs.find((o) => o.id === orgId);
    if (!org) return [];
    return allWorkstations(orgId).flatMap((ws) =>
    ws.users.map((user) => ({ user, ws, org }))
    );
  };

  // ── Lockout tick
  const startLockout = () => {
    const until = Date.now() + LOCKOUT_SECONDS * 1000;
    setLockedUntil(until);
    setLockedSecsLeft(LOCKOUT_SECONDS);
    const interval = setInterval(() => {
      const remaining = Math.ceil((until - Date.now()) / 1000);
      if (remaining <= 0) {
        clearInterval(interval);
        setLockedUntil(null);
        setLockedSecsLeft(0);
        setAttempts(0);
        setError("");
      } else {
        setLockedSecsLeft(remaining);
      }
    }, 500);
  };

  const isLocked = lockedUntil !== null && Date.now() < lockedUntil;

  // ── Credentials login
  const handleCredentialsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLocked) return;

    const usernameClean = username.trim().toLowerCase();
    const passwordClean = password;

    // Search through all orgs (built-in + registered)
    for (const org of getAllOrgs()) {
      const matches = getAllUsers(org.id).filter(({ user }) => {
        const uMatch = (user.username ?? "").toLowerCase() === usernameClean;
        const pMatch = (user.password ?? "") === passwordClean;
        return uMatch && pMatch;
      });
      if (matches.length > 0) {
        const { user, ws } = matches[0];
        const session: WorkstationSession = {
          orgId: org.id,
          orgName: org.name,
          workstationId: ws.id,
          workstationName: ws.name,
          userId: user.id,
          userName: user.name,
          userRole: user.role,
          userInitials: user.initials
        };
        saveWorkstationSession(session);
        onLogin(session);
        return;
      }
    }

    // Failed
    const nextAttempts = attempts + 1;
    setAttempts(nextAttempts);
    if (nextAttempts >= MAX_ATTEMPTS) {
      startLockout();
      setError(`Trop de tentatives. Accès bloqué ${LOCKOUT_SECONDS} secondes.`);
    } else {
      setError("Identifiant ou mot de passe incorrect.");
    }
    setPassword("");
  };

  // ── PIN helpers
  const handlePinInput = (digit: string) => {
    if (pin.length >= 4) return;
    const next = pin + digit;
    setPin(next);
    setError("");
    if (next.length === 4) {
      setTimeout(() => validatePin(next), 120);
    }
  };

  const handlePinBackspace = () => {
    setPin((p) => p.slice(0, -1));
    setError("");
  };

  const validatePin = (enteredPin: string) => {
    if (!selectedOrgForPin) return;
    const allUsers = getAllUsers(selectedOrgForPin.id);
    const match = allUsers.find(({ user }) => user.pin === enteredPin);
    if (match) {
      const { user, ws, org } = match;
      const session: WorkstationSession = {
        orgId: org.id,
        orgName: org.name,
        workstationId: ws.id,
        workstationName: ws.name,
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        userInitials: user.initials
      };
      saveWorkstationSession(session);
      onLogin(session);
    } else {
      setPin("");
      setError("NIP incorrect. Veuillez réessayer.");
    }
  };

  // ── Accent helpers
  const btnPrimary =
  "bg-primary text-primary-foreground hover:opacity-90 disabled:opacity-40";
  const adminBtn =
  "bg-violet-600 hover:bg-violet-700 text-white disabled:opacity-40";
  const pinActiveClass =
  selectedOrgForPin?.id === "admin" ?
  "border-violet-500 bg-violet-500/10" :
  "border-primary bg-primary/10";
  const pinDotClass =
  selectedOrgForPin?.id === "admin" ? "bg-violet-500" : "bg-primary";

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-6">
      {/* Header */}
      <div className="mb-8 text-center">
        <AppLogo className="h-28 w-auto object-contain mx-auto mb-2" />
        <p className="text-sm text-muted-foreground mt-1">
          {mode === "pin" ?
          "Accès rapide — NIP" :
          mode === "register" ?
          "Créer un nouveau compte" :
          "Connexion sécurisée"}
        </p>
      </div>

      <div className="w-full max-w-md">
        {/* ══════════════════════ REGISTER MODE ══════════════════════ */}
        {mode === "register" &&
        <RegisterForm
          onBack={() => setMode("credentials")}
          onSuccess={(session) => {
            onLogin(session);
          }} />

        }

        {/* ══════════════════════ CREDENTIALS MODE ══════════════════════ */}
        {mode === "credentials" &&
        <div className="bg-card border border-border rounded-2xl shadow-xl p-7 space-y-5">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                <Lock size={14} weight="duotone" className="text-primary" />
              </div>
              <div>
                <p className="text-[13px] font-semibold text-foreground">
                  Accès au système
                </p>
                <p className="text-[11px] text-muted-foreground">
                  Entrez vos identifiants de connexion
                </p>
              </div>
            </div>

            <form onSubmit={handleCredentialsSubmit} className="space-y-4">
              {/* Username */}
              <div className="space-y-1.5">
                <Label
                htmlFor="username"
                className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                
                  Identifiant
                </Label>
                <div className="relative">
                  <User
                  size={14}
                  weight="duotone"
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                
                  <Input
                  id="username"
                  type="text"
                  autoComplete="username"
                  value={username}
                  onChange={(e) => {
                    setUsername(e.target.value);
                    setError("");
                  }}
                  placeholder="prenom.nom"
                  className="pl-9 h-11 text-sm rounded-xl bg-background"
                  disabled={isLocked} />
                
                </div>
              </div>

              {/* Password */}
              <div className="space-y-1.5">
                <Label
                htmlFor="password"
                className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                
                  Mot de passe
                </Label>
                <div className="relative">
                  <Lock
                  size={14}
                  weight="duotone"
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                
                  <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setError("");
                  }}
                  placeholder="••••••••"
                  className="pl-9 pr-10 h-11 text-sm rounded-xl bg-background"
                  disabled={isLocked} />
                
                  <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  tabIndex={-1}>
                  
                    {showPassword ? <EyeSlash size={15} /> : <Eye size={15} />}
                  </button>
                </div>
              </div>

              {/* Error */}
              {error &&
            <div className="flex items-start gap-2 text-xs text-red-500 bg-red-50 dark:bg-red-900/20 rounded-xl px-3 py-2.5 border border-red-200 dark:border-red-800">
                  <WarningCircle
                size={14}
                weight="fill"
                className="mt-0.5 shrink-0" />
              
                  <span>
                    {error}
                    {isLocked && lockedSecsLeft > 0 &&
                <span className="font-semibold">
                        {" "}
                        ({lockedSecsLeft}s)
                      </span>
                }
                  </span>
                </div>
            }

              {/* Attempts warning */}
              {attempts > 0 && attempts < MAX_ATTEMPTS && !isLocked &&
            <p className="text-[11px] text-amber-500 text-center">
                  {MAX_ATTEMPTS - attempts} tentative
                  {MAX_ATTEMPTS - attempts > 1 ? "s" : ""} restante
                  {MAX_ATTEMPTS - attempts > 1 ? "s" : ""} avant blocage
                  temporaire.
                </p>
            }

              <button
              type="submit"
              disabled={isLocked || !username.trim() || !password}
              className={`w-full h-11 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 transition-all ${btnPrimary}`}>
              
                <SignIn size={16} weight="duotone" />
                {isLocked ? `Bloqué (${lockedSecsLeft}s)` : "Se connecter"}
              </button>
            </form>

            {/* Divider + links */}
            <div className="pt-1 text-center space-y-2">
              <div className="flex items-center gap-3">
                <div className="flex-1 h-px bg-border" />
                <span className="text-[10px] text-muted-foreground/60 uppercase tracking-wider">
                  ou
                </span>
                <div className="flex-1 h-px bg-border" />
              </div>
              <button
              onClick={() => {
                setMode("pin");
                setPinOrgStep("choose-org");
                setError("");
                setPin("");
              }}
              className="flex items-center justify-center gap-1.5 mx-auto text-xs text-muted-foreground hover:text-foreground transition-colors py-1">
              
                <Keyhole size={12} weight="duotone" />
                Accès rapide NIP (tablette atelier)
              </button>
              <button
              onClick={() => {
                setMode("register");
                setError("");
              }}
              className="flex items-center justify-center gap-1.5 mx-auto text-xs text-primary hover:text-primary/80 transition-colors py-1 font-medium">
              
                <UserPlus size={12} weight="duotone" />
                Créer un nouveau compte atelier
              </button>
            </div>
          </div>
        }

        {/* ══════════════════════ PIN MODE ══════════════════════ */}
        {mode === "pin" &&
        <>
            {/* Step A — choose org */}
            {pinOrgStep === "choose-org" &&
          <div className="space-y-4">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide text-center mb-2">
                  Sélectionnez votre organisation
                </p>
                {getAllOrgs().map((org) =>
            <button
              key={org.id}
              onClick={() => {
                setSelectedOrgForPin(org);
                setPin("");
                setError("");
                setPinOrgStep("enter-pin");
              }}
              className="w-full flex items-center gap-4 p-5 rounded-2xl border border-border bg-card hover:bg-muted/40 hover:border-primary/40 transition-all text-left group shadow-sm">
              
                    <div
                className={`w-14 h-14 rounded-2xl flex items-center justify-center text-3xl shrink-0 ${org.color} bg-opacity-15`}>
                
                      {org.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-base font-bold text-foreground">
                        {org.name}
                      </p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {org.subtitle}
                      </p>
                    </div>
                    <Buildings
                size={22}
                className="text-muted-foreground group-hover:text-primary transition-colors shrink-0"
                weight="duotone" />
              
                  </button>
            )}
                <button
              onClick={() => {
                setMode("credentials");
                setError("");
              }}
              className="w-full text-center text-xs text-muted-foreground hover:text-foreground mt-2 py-2 transition-colors flex items-center justify-center gap-1">
              
                  <ArrowLeft size={11} /> Retour à la connexion
                </button>
              </div>
          }

            {/* Step B — enter PIN */}
            {pinOrgStep === "enter-pin" && selectedOrgForPin &&
          <div className="bg-card border border-border rounded-2xl shadow-xl p-6 text-center space-y-5">
                {/* Org badge */}
                <div
              className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${selectedOrgForPin.color} bg-opacity-15 text-foreground`}>
              
                  <span>{selectedOrgForPin.icon}</span> {selectedOrgForPin.name}
                </div>

                <div>
                  <p className="text-xs text-muted-foreground mb-1 flex items-center justify-center gap-1">
                    <Lock size={11} weight="fill" /> Entrez votre NIP à 4
                    chiffres
                  </p>
                  <p className="text-[10px] text-muted-foreground/60">
                    NIP automatiquement associé à votre compte
                  </p>
                </div>

                {/* PIN dots */}
                <div className="flex items-center justify-center gap-3 mb-2">
                  {[0, 1, 2, 3].map((i) =>
              <div
                key={i}
                className={`w-10 h-10 rounded-xl border-2 flex items-center justify-center transition-all ${
                i < pin.length ?
                pinActiveClass :
                "border-border bg-muted/30"}`
                }>
                
                      {showPin && pin[i] ?
                <span className="text-sm font-bold text-foreground">
                          {pin[i]}
                        </span> :
                i < pin.length ?
                <div
                  className={`w-2.5 h-2.5 rounded-full ${pinDotClass}`} /> :

                null}
                    </div>
              )}
                  <button
                onClick={() => setShowPin((v) => !v)}
                className="ml-2 text-muted-foreground hover:text-foreground transition-colors">
                
                    {showPin ? <EyeSlash size={16} /> : <Eye size={16} />}
                  </button>
                </div>

                {error &&
            <div className="flex items-center gap-2 text-xs text-red-500 bg-red-50 dark:bg-red-900/20 rounded-xl px-3 py-2 border border-red-200 dark:border-red-800">
                    <WarningCircle
                size={13}
                weight="fill"
                className="shrink-0" />
              
                    {error}
                  </div>
            }

                {/* Numpad */}
                <div className="grid grid-cols-3 gap-2 max-w-[220px] mx-auto">
                  {[
              "1",
              "2",
              "3",
              "4",
              "5",
              "6",
              "7",
              "8",
              "9",
              "",
              "0",
              "⌫"].
              map((digit, i) => {
                if (digit === "") return <div key={i} />;
                return (
                  <button
                    key={i}
                    onClick={() =>
                    digit === "⌫" ?
                    handlePinBackspace() :
                    handlePinInput(digit)
                    }
                    className={`h-12 rounded-xl text-base font-semibold border transition-all active:scale-95 ${
                    digit === "⌫" ?
                    "border-border text-muted-foreground hover:bg-muted/50" :
                    "border-border text-foreground bg-card hover:bg-primary hover:text-primary-foreground hover:border-primary shadow-sm"}`
                    }>
                    
                        {digit}
                      </button>);

              })}
                </div>

                <button
              onClick={() => pin.length === 4 && validatePin(pin)}
              disabled={pin.length !== 4}
              className={`w-full py-2.5 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 transition-all ${
              selectedOrgForPin.id === "admin" ? adminBtn : btnPrimary}`
              }>
              
                  <SignIn size={15} weight="duotone" /> Connexion
                </button>

                <button
              onClick={() => {
                setPinOrgStep("choose-org");
                setPin("");
                setError("");
              }}
              className="w-full text-center text-xs text-muted-foreground hover:text-foreground transition-colors py-1 flex items-center justify-center gap-1">
              
                  <ArrowLeft size={11} /> Retour aux organisations
                </button>
              </div>
          }
          </>
        }
      </div>

      <p className="mt-10 text-[11px] text-muted-foreground/50">
        GarageManager — Système de gestion d&#39;atelier
      </p>
    </div>);

}