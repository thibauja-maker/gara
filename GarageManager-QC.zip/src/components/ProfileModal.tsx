import { useState } from "react";
import { X, User, Camera, FloppyDisk, CheckCircle } from "@phosphor-icons/react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useLocalStorage } from "@/hooks/use-local-storage";

type Props = { onClose: () => void };

export type ProfileData = {
  name: string;
  email: string;
  phone: string;
  role: string;
  notifWorkOrder: boolean;
  notifInvoice: boolean;
  notifAppt: boolean;
};

const DEFAULT_PROFILE: ProfileData = {
  name: "Marc Gagnon",
  email: "marc@garagemanager.ca",
  phone: "(418) 555-0192",
  role: "Gestionnaire",
  notifWorkOrder: true,
  notifInvoice: true,
  notifAppt: true,
};

export default function ProfileModal({ onClose, orgId }: Props & { orgId?: string }) {
  const [saved, setSaved] = useState(false);
  const storageKey = orgId ? `garagemanager_${orgId}_profile` : "garagemanager_profile";
  const [profile, setProfile] = useLocalStorage<ProfileData>(storageKey, DEFAULT_PROFILE);

  // Local draft — only committed to storage on Save
  const [form, setForm] = useState({ ...profile });
  const [pwError, setPwError] = useState("");
  const [passwords, setPasswords] = useState({ current: "", next: "", confirm: "" });

  // Initials computed from stored name
  const initials = profile.name.split(" ").map((w) => w[0] ?? "").join("").toUpperCase().slice(0, 2);

  const field = (key: keyof Omit<ProfileData, "notifWorkOrder" | "notifInvoice" | "notifAppt" | "role">) => ({
    value: form[key],
    onChange: (e: React.ChangeEvent<HTMLInputElement>) =>
      setForm((p) => ({ ...p, [key]: e.target.value })),
  });

  const handleSave = () => {
    setPwError("");
    if (passwords.next) {
      if (passwords.next.length < 8) {
        setPwError("Le mot de passe doit comporter au moins 8 caractères.");
        return;
      }
      if (passwords.next !== passwords.confirm) {
        setPwError("Les mots de passe ne correspondent pas.");
        return;
      }
    }
    // Persist to localStorage
    setProfile({ ...form });
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 w-full max-w-lg bg-card border border-border rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
              <User size={15} weight="duotone" className="text-primary" />
            </div>
            <div>
              <h2 className="text-[15px] font-semibold text-foreground leading-tight">Mon profil</h2>
              <p className="text-[11px] text-muted-foreground">Informations personnelles &amp; sécurité</p>
            </div>
          </div>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-md text-muted-foreground hover:bg-muted transition-colors">
            <X size={15} weight="bold" />
          </button>
        </div>

        <div className="overflow-y-auto max-h-[75vh]">
          <div className="px-6 py-5 space-y-6">
            {/* Avatar */}
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center shadow-md">
                  <span className="text-white text-xl font-bold">{initials}</span>
                </div>
                <button className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-primary flex items-center justify-center shadow-sm border-2 border-card hover:opacity-90 transition-opacity">
                  <Camera size={10} weight="bold" className="text-primary-foreground" />
                </button>
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">{form.name}</p>
                <p className="text-xs text-muted-foreground">{form.role}</p>
                <button className="text-xs text-primary hover:underline mt-1">Changer la photo</button>
              </div>
            </div>

            <Separator />

            {/* Personal Info */}
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Informations personnelles</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label className="text-xs text-muted-foreground">Nom complet</Label>
                  <Input {...field("name")} className="h-9 text-sm rounded-lg border-border" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs text-muted-foreground">Rôle</Label>
                  <Input value={form.role} className="h-9 text-sm rounded-lg border-border" readOnly disabled />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs text-muted-foreground">Courriel</Label>
                  <Input {...field("email")} type="email" className="h-9 text-sm rounded-lg border-border" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs text-muted-foreground">Téléphone</Label>
                  <Input {...field("phone")} type="tel" className="h-9 text-sm rounded-lg border-border" />
                </div>
              </div>
            </div>

            <Separator />

            {/* Password */}
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Changer le mot de passe</p>
              <div className="space-y-3">
                <div className="space-y-1.5">
                  <Label className="text-xs text-muted-foreground">Mot de passe actuel</Label>
                  <Input
                    type="password"
                    placeholder="••••••••"
                    value={passwords.current}
                    onChange={(e) => setPasswords((p) => ({ ...p, current: e.target.value }))}
                    className="h-9 text-sm rounded-lg border-border"
                  />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label className="text-xs text-muted-foreground">Nouveau mot de passe</Label>
                    <Input
                      type="password"
                      placeholder="••••••••"
                      value={passwords.next}
                      onChange={(e) => setPasswords((p) => ({ ...p, next: e.target.value }))}
                      className="h-9 text-sm rounded-lg border-border"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs text-muted-foreground">Confirmer</Label>
                    <Input
                      type="password"
                      placeholder="••••••••"
                      value={passwords.confirm}
                      onChange={(e) => setPasswords((p) => ({ ...p, confirm: e.target.value }))}
                      className="h-9 text-sm rounded-lg border-border"
                    />
                  </div>
                </div>
                {pwError && <p className="text-xs text-red-500">{pwError}</p>}
              </div>
            </div>

            <Separator />

            {/* Notifications prefs */}
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Préférences de notification</p>
              <div className="space-y-2">
                {([
                  { key: "notifWorkOrder" as const, label: "Ordres de travail complétés", desc: "Recevoir une alerte quand un ordre est terminé" },
                  { key: "notifInvoice"   as const, label: "Factures en attente",          desc: "Rappel quotidien des factures non payées"    },
                  { key: "notifAppt"      as const, label: "Rendez-vous du jour",           desc: "Résumé matinal des rendez-vous"             },
                ] as const).map((pref) => (
                  <label key={pref.key} className="flex items-start gap-3 p-3 rounded-lg hover:bg-muted/50 cursor-pointer transition-colors">
                    <input
                      type="checkbox"
                      checked={form[pref.key]}
                      onChange={(e) => setForm((p) => ({ ...p, [pref.key]: e.target.checked }))}
                      className="mt-0.5 rounded border-border accent-primary"
                    />
                    <div>
                      <p className="text-sm text-foreground font-medium">{pref.label}</p>
                      <p className="text-xs text-muted-foreground">{pref.desc}</p>
                    </div>
                  </label>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-border flex items-center justify-between gap-3 bg-muted/20">
          {saved ? (
            <span className="flex items-center gap-1.5 text-xs text-green-600 font-medium">
              <CheckCircle size={13} weight="fill" /> Profil enregistré
            </span>
          ) : <span />}
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={onClose} className="text-sm rounded-lg">Annuler</Button>
            <Button size="sm" onClick={handleSave} className="text-sm rounded-lg bg-primary text-primary-foreground gap-1.5">
              <FloppyDisk size={13} weight="duotone" /> Enregistrer
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
