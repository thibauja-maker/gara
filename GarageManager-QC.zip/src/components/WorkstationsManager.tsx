import { useState } from "react";
import {
  X,
  Monitor,
  Plus,
  Trash,
  PencilSimple,
  Users,
  Lock,
  CheckCircle,
  Eye,
  EyeSlash,
  FloppyDisk,
  Buildings,
} from "@phosphor-icons/react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useSecureLocalStorage } from "@/hooks/use-secure-local-storage";
import {
  type Workstation,
  type WorkstationUser,
  ORGANIZATIONS,
  DEFAULT_WORKSTATIONS_JBL,
} from "./WorkstationLogin";

const ROLE_OPTIONS = [
  "Admin",
  "Chef mécanicien",
  "Mécanicien",
  "Réceptionniste",
  "Gérant",
  "Apprenti",
  "Comptable",
];

const USER_COLORS = [
  "bg-primary",
  "bg-blue-500",
  "bg-purple-500",
  "bg-pink-500",
  "bg-orange-500",
  "bg-amber-500",
  "bg-emerald-500",
  "bg-teal-500",
  "bg-red-500",
  "bg-violet-600",
  "bg-indigo-500",
];
const WS_ICONS = [
  "🖥️",
  "🔧",
  "⚙️",
  "📊",
  "🏁",
  "🚗",
  "🛻",
  "📋",
  "🔑",
  "💼",
  "🏢",
  "📈",
];

function getInitials(name: string) {
  return name
    .split(" ")
    .map((w) => w[0] ?? "")
    .join("")
    .toUpperCase()
    .slice(0, 2);
}

type Props = { onClose: () => void; orgId?: string };

export default function WorkstationsManager({ onClose, orgId = "default" }: Props) {
  const [workstations, setWorkstations] = useSecureLocalStorage<Workstation[]>(
    `garagemanager_workstations_${orgId}`,
    DEFAULT_WORKSTATIONS_JBL,
  );

  const activeDraft = workstations;
  const setActiveDraft = setWorkstations;

  const [draft, setDraft] = useState<Workstation[]>(activeDraft);
  const [saved, setSaved] = useState(false);

  const [editingWs, setEditingWs] = useState<Workstation | null>(null);
  const [editingUser, setEditingUser] = useState<WorkstationUser | null>(null);
  const [editingUserWsId, setEditingUserWsId] = useState<number | null>(null);
  const [showPins, setShowPins] = useState<Record<number, boolean>>({});
  const [addUserWsId, setAddUserWsId] = useState<number | null>(null);
  const [newUser, setNewUser] = useState<Omit<WorkstationUser, "id">>({
    name: "",
    initials: "",
    role: "Mécanicien",
    pin: "",
    username: "",
    password: "",
    color: "bg-primary",
  });
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showEditPassword, setShowEditPassword] = useState(false);
  const [deleteWsId, setDeleteWsId] = useState<number | null>(null);

  const handleSave = () => {
    setActiveDraft(draft);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleAddWorkstation = () => {
    const newWs: Workstation = {
      id: Date.now(),
      name: "Nouveau poste",
      description: "Description du poste",
      icon: "🖥️",
      color: "bg-blue-500",
      users: [],
    };
    setDraft((p) => [...p, newWs]);
    setEditingWs(newWs);
  };

  const handleSaveWs = () => {
    if (!editingWs) return;
    setDraft((p) => p.map((w) => (w.id === editingWs.id ? editingWs : w)));
    setEditingWs(null);
  };

  const handleDeleteWs = (id: number) => {
    setDraft((p) => p.filter((w) => w.id !== id));
    setDeleteWsId(null);
  };

  const handleSaveUser = () => {
    if (!editingUser || editingUserWsId === null) return;
    setDraft((p) =>
      p.map((w) =>
        w.id === editingUserWsId
          ? {
              ...w,
              users: w.users.map((u) =>
                u.id === editingUser.id ? editingUser : u,
              ),
            }
          : w,
      ),
    );
    setEditingUser(null);
    setEditingUserWsId(null);
  };

  const handleAddUser = (wsId: number) => {
    if (!newUser.name.trim() || newUser.pin.length !== 4) return;
    const user: WorkstationUser = {
      id: Date.now(),
      ...newUser,
      initials: getInitials(newUser.name),
    };
    setDraft((p) =>
      p.map((w) => (w.id === wsId ? { ...w, users: [...w.users, user] } : w)),
    );
    setAddUserWsId(null);
    setNewUser({
      name: "",
      initials: "",
      role: "Mécanicien",
      pin: "",
      username: "",
      password: "",
      color: "bg-primary",
    });
  };

  const handleDeleteUser = (wsId: number, userId: number) => {
    setDraft((p) =>
      p.map((w) =>
        w.id === wsId
          ? { ...w, users: w.users.filter((u) => u.id !== userId) }
          : w,
      ),
    );
  };

  const activeOrgInfo = ORGANIZATIONS.find((o) => o.id === orgId) ?? {
    id: orgId,
    name: orgId,
    subtitle: "Postes de travail",
    icon: "🔧",
    color: "bg-primary",
    accentClass: "bg-primary",
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-black/40 backdrop-blur-sm"
        onClick={onClose}
      />
      <div
        className="relative z-10 w-full max-w-2xl bg-card border border-border rounded-2xl shadow-2xl flex flex-col"
        style={{ maxHeight: "90vh" }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
              <Monitor size={15} weight="duotone" className="text-primary" />
            </div>
            <div>
              <h2 className="text-[15px] font-semibold text-foreground">
                Postes de travail
              </h2>
              <p className="text-[11px] text-muted-foreground">
                Gérer les postes et leurs utilisateurs par organisation
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-md text-muted-foreground hover:bg-muted transition-colors"
          >
            <X size={15} weight="bold" />
          </button>
        </div>

        {/* Org info */}
        <div className="px-6 pt-4 pb-2 shrink-0">
          <div
            className={`flex items-center gap-2 px-3 py-2 rounded-xl border border-border ${activeOrgInfo.color} bg-opacity-5`}
          >
            <Buildings
              size={14}
              weight="duotone"
              className="text-muted-foreground"
            />
            <span className="text-xs text-muted-foreground">
              {activeOrgInfo.subtitle}
            </span>
            <span className="ml-auto text-[10px] text-muted-foreground/60">
              Indépendant des autres organisations
            </span>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto px-6 py-3 space-y-4">
          {draft.map((ws) => (
            <div
              key={ws.id}
              className="border border-border rounded-2xl bg-background overflow-hidden"
            >
              {/* Workstation header */}
              <div className="flex items-center gap-3 px-4 py-3 bg-muted/30 border-b border-border">
                <span className="text-xl">{ws.icon}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground">
                    {ws.name}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {ws.description}
                  </p>
                </div>
                <div className="flex gap-1">
                  <button
                    onClick={() => setEditingWs({ ...ws })}
                    className="w-7 h-7 flex items-center justify-center rounded-md text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors"
                    title="Modifier le poste"
                  >
                    <PencilSimple size={13} weight="duotone" />
                  </button>
                  <button
                    onClick={() => setDeleteWsId(ws.id)}
                    className="w-7 h-7 flex items-center justify-center rounded-md text-muted-foreground hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                    title="Supprimer le poste"
                  >
                    <Trash size={13} weight="duotone" />
                  </button>
                </div>
              </div>

              {/* Users list */}
              <div className="divide-y divide-border">
                {ws.users.map((user) => (
                  <div
                    key={user.id}
                    className="flex items-center gap-3 px-4 py-2.5 group hover:bg-muted/20 transition-colors"
                  >
                    <div
                      className={`w-8 h-8 rounded-full ${user.color} flex items-center justify-center shrink-0`}
                    >
                      <span className="text-[10px] font-bold text-white">
                        {user.initials}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground">
                        {user.name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {user.role}
                      </p>
                    </div>
                    <div className="flex flex-col items-end gap-0.5">
                      {user.username && (
                        <span className="text-[10px] text-muted-foreground font-mono">
                          @{user.username}
                        </span>
                      )}
                      <div className="flex items-center gap-1 text-xs text-muted-foreground font-mono">
                        <Lock size={10} weight="fill" />
                        <span>{showPins[user.id] ? user.pin : "••••"}</span>
                        <button
                          onClick={() =>
                            setShowPins((p) => ({
                              ...p,
                              [user.id]: !p[user.id],
                            }))
                          }
                          className="text-muted-foreground hover:text-foreground"
                        >
                          {showPins[user.id] ? (
                            <EyeSlash size={11} />
                          ) : (
                            <Eye size={11} />
                          )}
                        </button>
                      </div>
                    </div>
                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => {
                          setEditingUser({ ...user });
                          setEditingUserWsId(ws.id);
                        }}
                        className="w-6 h-6 flex items-center justify-center rounded-md text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors"
                      >
                        <PencilSimple size={11} weight="duotone" />
                      </button>
                      <button
                        onClick={() => handleDeleteUser(ws.id, user.id)}
                        className="w-6 h-6 flex items-center justify-center rounded-md text-muted-foreground hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                      >
                        <Trash size={11} weight="duotone" />
                      </button>
                    </div>
                  </div>
                ))}

                {/* Add user inline */}
                {addUserWsId === ws.id ? (
                  <div className="px-4 py-3 bg-primary/5 border-t border-primary/20 space-y-3">
                    <p className="text-xs font-semibold text-foreground">
                      Ajouter un utilisateur
                    </p>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <Label className="text-xs text-muted-foreground">
                          Nom
                        </Label>
                        <Input
                          value={newUser.name}
                          onChange={(e) =>
                            setNewUser((p) => ({
                              ...p,
                              name: e.target.value,
                              initials: getInitials(e.target.value),
                            }))
                          }
                          className="h-8 text-sm rounded-md"
                          placeholder="Jean Dupont"
                        />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs text-muted-foreground">
                          Rôle
                        </Label>
                        <select
                          value={newUser.role}
                          onChange={(e) =>
                            setNewUser((p) => ({ ...p, role: e.target.value }))
                          }
                          className="w-full h-8 text-sm rounded-md border border-border bg-background px-2 text-foreground"
                        >
                          {ROLE_OPTIONS.map((r) => (
                            <option key={r} value={r}>
                              {r}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs text-muted-foreground">
                          Identifiant
                        </Label>
                        <Input
                          value={newUser.username ?? ""}
                          onChange={(e) =>
                            setNewUser((p) => ({
                              ...p,
                              username: e.target.value
                                .toLowerCase()
                                .replace(/\s/g, "."),
                            }))
                          }
                          className="h-8 text-sm rounded-lg font-mono"
                          placeholder="prenom.nom"
                        />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs text-muted-foreground">
                          Mot de passe
                        </Label>
                        <div className="relative">
                          <Input
                            value={newUser.password ?? ""}
                            type={showNewPassword ? "text" : "password"}
                            onChange={(e) =>
                              setNewUser((p) => ({
                                ...p,
                                password: e.target.value,
                              }))
                            }
                            className="h-8 text-sm rounded-lg pr-8"
                            placeholder="••••••••"
                          />
                          <button
                            type="button"
                            onClick={() => setShowNewPassword((v) => !v)}
                            className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                            tabIndex={-1}
                          >
                            {showNewPassword ? (
                              <EyeSlash size={12} />
                            ) : (
                              <Eye size={12} />
                            )}
                          </button>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs text-muted-foreground">
                          NIP (4 chiffres — accès rapide)
                        </Label>
                        <Input
                          value={newUser.pin}
                          onChange={(e) =>
                            setNewUser((p) => ({
                              ...p,
                              pin: e.target.value
                                .replace(/\D/g, "")
                                .slice(0, 4),
                            }))
                          }
                          className="h-8 text-sm rounded-lg font-mono"
                          placeholder="1234"
                          maxLength={4}
                        />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs text-muted-foreground">
                          Couleur
                        </Label>
                        <div className="flex gap-1 flex-wrap pt-1">
                          {USER_COLORS.map((c) => (
                            <button
                              key={c}
                              onClick={() =>
                                setNewUser((p) => ({ ...p, color: c }))
                              }
                              className={`w-5 h-5 rounded-full ${c} ${newUser.color === c ? "ring-2 ring-offset-1 ring-foreground" : ""}`}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-2 justify-end">
                      <button
                        onClick={() => setAddUserWsId(null)}
                        className="px-3 py-1.5 text-xs rounded-lg border border-border text-muted-foreground hover:bg-muted transition-colors"
                      >
                        Annuler
                      </button>
                      <button
                        onClick={() => handleAddUser(ws.id)}
                        disabled={
                          !newUser.name.trim() ||
                          newUser.pin.length !== 4 ||
                          !newUser.username?.trim() ||
                          !newUser.password?.trim()
                        }
                        className="px-3 py-1.5 text-xs rounded-lg bg-primary text-primary-foreground hover:opacity-90 disabled:opacity-40 transition-opacity"
                      >
                        Ajouter
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={() => {
                      setAddUserWsId(ws.id);
                      setNewUser({
                        name: "",
                        initials: "",
                        role: "Mécanicien",
                        pin: "",
                        username: "",
                        password: "",
                        color: "bg-primary",
                      });
                    }}
                    className="w-full flex items-center gap-2 px-4 py-2.5 text-xs text-muted-foreground hover:text-primary hover:bg-muted/30 transition-colors"
                  >
                    <Users size={12} weight="duotone" />+ Ajouter un utilisateur
                    à ce poste
                  </button>
                )}
              </div>
            </div>
          ))}

          <button
            onClick={handleAddWorkstation}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-2xl border-2 border-dashed border-border text-sm text-muted-foreground hover:border-primary hover:text-primary transition-all"
          >
            <Plus size={14} weight="bold" /> Nouveau poste —{" "}
            {activeOrgInfo.name}
          </button>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-border flex items-center justify-between gap-3 bg-muted/20 shrink-0">
          {saved ? (
            <span className="flex items-center gap-1.5 text-xs text-green-600 font-medium">
              <CheckCircle size={13} weight="fill" /> Enregistré —{" "}
              {activeOrgInfo.name}
            </span>
          ) : (
            <span />
          )}
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={onClose}
              className="text-sm rounded-lg"
            >
              Fermer
            </Button>
            <Button
              size="sm"
              onClick={handleSave}
              className="text-sm rounded-lg bg-primary text-primary-foreground gap-1.5"
            >
              <FloppyDisk size={13} weight="duotone" /> Enregistrer
            </Button>
          </div>
        </div>
      </div>

      {/* Edit workstation modal */}
      {editingWs && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/40"
            onClick={() => setEditingWs(null)}
          />
          <div className="relative z-10 w-full max-w-sm bg-card border border-border rounded-2xl shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-foreground">
                Modifier le poste
              </h3>
              <button
                onClick={() => setEditingWs(null)}
                className="w-7 h-7 flex items-center justify-center rounded-md text-muted-foreground hover:bg-muted transition-colors"
              >
                <X size={13} weight="bold" />
              </button>
            </div>
            <div className="space-y-3">
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">
                  Nom du poste
                </Label>
                <Input
                  value={editingWs.name}
                  onChange={(e) =>
                    setEditingWs((p) =>
                      p ? { ...p, name: e.target.value } : p,
                    )
                  }
                  className="h-9 text-sm rounded-lg"
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">
                  Description
                </Label>
                <Input
                  value={editingWs.description}
                  onChange={(e) =>
                    setEditingWs((p) =>
                      p ? { ...p, description: e.target.value } : p,
                    )
                  }
                  className="h-9 text-sm rounded-lg"
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">Icône</Label>
                <div className="flex gap-2 flex-wrap">
                  {WS_ICONS.map((ic) => (
                    <button
                      key={ic}
                      onClick={() =>
                        setEditingWs((p) => (p ? { ...p, icon: ic } : p))
                      }
                      className={`w-9 h-9 rounded-xl text-lg flex items-center justify-center transition-all ${editingWs.icon === ic ? "bg-primary/20 ring-2 ring-primary" : "hover:bg-muted"}`}
                    >
                      {ic}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex gap-2 justify-end pt-1">
              <button
                onClick={() => setEditingWs(null)}
                className="px-4 py-2 rounded-lg text-sm border border-border text-muted-foreground hover:bg-muted transition-colors"
              >
                Annuler
              </button>
              <button
                onClick={handleSaveWs}
                className="px-4 py-2 rounded-lg text-sm bg-primary text-primary-foreground hover:opacity-90 transition-opacity flex items-center gap-1.5"
              >
                <CheckCircle size={13} weight="fill" /> Enregistrer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit user modal */}
      {editingUser && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/40"
            onClick={() => setEditingUser(null)}
          />
          <div className="relative z-10 w-full max-w-sm bg-card border border-border rounded-2xl shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-foreground">
                Modifier l&#39;utilisateur
              </h3>
              <button
                onClick={() => setEditingUser(null)}
                className="w-7 h-7 flex items-center justify-center rounded-md text-muted-foreground hover:bg-muted transition-colors"
              >
                <X size={13} weight="bold" />
              </button>
            </div>
            <div className="space-y-3">
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">Nom</Label>
                <Input
                  value={editingUser.name}
                  onChange={(e) =>
                    setEditingUser((p) =>
                      p
                        ? {
                            ...p,
                            name: e.target.value,
                            initials: getInitials(e.target.value),
                          }
                        : p,
                    )
                  }
                  className="h-9 text-sm rounded-lg"
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">Rôle</Label>
                <select
                  value={editingUser.role}
                  onChange={(e) =>
                    setEditingUser((p) =>
                      p ? { ...p, role: e.target.value } : p,
                    )
                  }
                  className="w-full h-9 text-sm rounded-lg border border-border bg-background px-3 text-foreground"
                >
                  {ROLE_OPTIONS.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">
                  Identifiant
                </Label>
                <Input
                  value={editingUser.username ?? ""}
                  onChange={(e) =>
                    setEditingUser((p) =>
                      p
                        ? {
                            ...p,
                            username: e.target.value
                              .toLowerCase()
                              .replace(/\s/g, "."),
                          }
                        : p,
                    )
                  }
                  className="h-9 text-sm rounded-lg font-mono"
                  placeholder="prenom.nom"
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">
                  Mot de passe
                </Label>
                <div className="relative">
                  <Input
                    value={editingUser.password ?? ""}
                    type={showEditPassword ? "text" : "password"}
                    onChange={(e) =>
                      setEditingUser((p) =>
                        p ? { ...p, password: e.target.value } : p,
                      )
                    }
                    className="h-9 text-sm rounded-lg pr-10"
                    placeholder="••••••••"
                  />
                  <button
                    type="button"
                    onClick={() => setShowEditPassword((v) => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    tabIndex={-1}
                  >
                    {showEditPassword ? (
                      <EyeSlash size={14} />
                    ) : (
                      <Eye size={14} />
                    )}
                  </button>
                </div>
              </div>
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">
                  NIP (4 chiffres — accès rapide)
                </Label>
                <Input
                  value={editingUser.pin}
                  onChange={(e) =>
                    setEditingUser((p) =>
                      p
                        ? {
                            ...p,
                            pin: e.target.value.replace(/\D/g, "").slice(0, 4),
                          }
                        : p,
                    )
                  }
                  className="h-9 text-sm rounded-lg font-mono"
                  placeholder="1234"
                  maxLength={4}
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">
                  Couleur avatar
                </Label>
                <div className="flex gap-1.5 flex-wrap">
                  {USER_COLORS.map((c) => (
                    <button
                      key={c}
                      onClick={() =>
                        setEditingUser((p) => (p ? { ...p, color: c } : p))
                      }
                      className={`w-6 h-6 rounded-full ${c} ${editingUser.color === c ? "ring-2 ring-offset-1 ring-foreground" : ""}`}
                    />
                  ))}
                </div>
              </div>
            </div>
            <div className="flex gap-2 justify-end pt-1">
              <button
                onClick={() => setEditingUser(null)}
                className="px-4 py-2 rounded-lg text-sm border border-border text-muted-foreground hover:bg-muted transition-colors"
              >
                Annuler
              </button>
              <button
                onClick={handleSaveUser}
                className="px-4 py-2 rounded-lg text-sm bg-primary text-primary-foreground hover:opacity-90 transition-opacity flex items-center gap-1.5"
              >
                <CheckCircle size={13} weight="fill" /> Enregistrer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete workstation confirm */}
      {deleteWsId !== null && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/40"
            onClick={() => setDeleteWsId(null)}
          />
          <div className="relative z-10 w-full max-w-xs bg-card border border-border rounded-2xl shadow-2xl p-5 space-y-4 text-center">
            <div className="w-11 h-11 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center mx-auto">
              <Trash size={18} weight="duotone" className="text-red-500" />
            </div>
            <h3 className="text-sm font-semibold text-foreground">
              Supprimer ce poste&#160;?
            </h3>
            <p className="text-xs text-muted-foreground">
              {draft.find((w) => w.id === deleteWsId)?.name} et tous ses
              utilisateurs seront supprimés.
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => setDeleteWsId(null)}
                className="flex-1 px-3 py-2 rounded-lg text-sm border border-border text-muted-foreground hover:bg-muted transition-colors"
              >
                Annuler
              </button>
              <button
                onClick={() => handleDeleteWs(deleteWsId)}
                className="flex-1 px-3 py-2 rounded-lg text-sm bg-red-500 text-white hover:bg-red-600 transition-colors"
              >
                Supprimer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
