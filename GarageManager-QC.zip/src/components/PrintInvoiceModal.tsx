import { useRef } from "react";
import { X, Printer, FilePdf } from "@phosphor-icons/react";

export type PrintInvoiceData = {
  orderNumber: string;
  date: string;
  customerName: string;
  phone?: string;
  vehicleInfo: string;
  plate?: string;
  mileage?: string;
  mechanic?: string;
  jobDesc?: string;
  parts: Array<{ description: string; partNumber?: string; qty: number; unitPrice: number }>;
  labor: Array<{ description: string; hours: number; rate: number }>;
  supplies: Array<{ description: string; amount: number }>;
  subtotal: number;
  tpsAmount: number;
  tvqAmount: number;
  total: number;
  paymentStatus: string;
  paymentMethod?: string;
  amountPaid?: number;
  shopName?: string;
  shopAddress?: string;
  shopPhone?: string;
  shopTps?: string;
  shopTvq?: string;
};

function fmt(n: number) {
  return n.toLocaleString("fr-CA", { style: "currency", currency: "CAD" });
}

export default function PrintInvoiceModal({
  data,
  onClose,
}: {
  data: PrintInvoiceData;
  onClose: () => void;
}) {
  const printRef = useRef<HTMLDivElement>(null);

  const printHTML = () => {
    const content = printRef.current;
    if (!content) return "";
    return `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <title>Facture ${data.orderNumber}</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Helvetica Neue', Arial, sans-serif; font-size: 12px; color: #111; background: #fff; }
    .page { max-width: 760px; margin: 0 auto; padding: 36px 40px; }
    .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 28px; border-bottom: 2px solid #111; padding-bottom: 20px; }
    .shop-name { font-size: 20px; font-weight: 800; letter-spacing: -0.5px; }
    .shop-info { font-size: 11px; color: #444; margin-top: 4px; line-height: 1.5; }
    .invoice-meta { text-align: right; }
    .invoice-meta .inv-number { font-size: 18px; font-weight: 700; color: #111; }
    .invoice-meta .inv-date { font-size: 11px; color: #555; margin-top: 4px; }
    .invoice-meta .badge { display: inline-block; margin-top: 8px; padding: 3px 10px; border-radius: 999px; font-size: 10px; font-weight: 700; letter-spacing: 0.5px; text-transform: uppercase; }
    .badge-paid { background: #dcfce7; color: #166534; }
    .badge-unpaid { background: #fef9c3; color: #854d0e; }
    .badge-partial { background: #e0f2fe; color: #075985; }
    .section { margin-bottom: 22px; }
    .section-title { font-size: 10px; text-transform: uppercase; letter-spacing: 1px; color: #666; font-weight: 700; margin-bottom: 8px; border-bottom: 1px solid #e5e7eb; padding-bottom: 4px; }
    .client-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 6px 20px; font-size: 12px; }
    .client-grid .label { color: #888; font-size: 10px; text-transform: uppercase; letter-spacing: 0.5px; }
    .client-grid .value { font-weight: 600; }
    table { width: 100%; border-collapse: collapse; font-size: 11.5px; }
    thead tr { background: #f3f4f6; }
    th { text-align: left; padding: 6px 8px; font-size: 10px; text-transform: uppercase; letter-spacing: 0.6px; color: #555; font-weight: 700; }
    td { padding: 6px 8px; border-bottom: 1px solid #f0f0f0; }
    .text-right { text-align: right; }
    .text-center { text-align: center; }
    .totals { width: 260px; margin-left: auto; margin-top: 12px; }
    .totals tr td { border: none; padding: 4px 8px; }
    .totals .grand-total td { font-size: 14px; font-weight: 800; border-top: 2px solid #111; padding-top: 8px; }
    .footer { margin-top: 28px; padding-top: 12px; border-top: 1px solid #e5e7eb; font-size: 10px; color: #888; display: flex; justify-content: space-between; }
    @media print {
      @page { margin: 15mm 15mm; size: letter; }
      body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    }
  </style>
</head>
<body>
${content.innerHTML}
</body>
</html>`;
  };

  // Ouvre le HTML dans un nouvel onglet Chrome → dialogue impression natif (choix imprimante + Enregistrer PDF)
  const openInChrome = (autoprint: boolean) => {
    const html = printHTML();
    if (!html) return;
    const blob = new Blob([html], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const win = window.open(url, "_blank");
    if (!win) { URL.revokeObjectURL(url); return; }
    if (autoprint) {
      win.addEventListener("load", () => {
        win.focus();
        win.print();
        setTimeout(() => URL.revokeObjectURL(url), 15000);
      });
    } else {
      setTimeout(() => URL.revokeObjectURL(url), 60000);
    }
  };

  const handlePrint = () => openInChrome(true);
  const handleSavePDF = () => openInChrome(true);

  const partsFiltered = data.parts.filter((p) => p.description.trim());
  const laborFiltered = data.labor.filter((l) => l.description.trim());
  const suppliesFiltered = data.supplies.filter((s) => s.description.trim());
  const balanceDue = Math.max(0, data.total - (data.amountPaid ?? 0));

  const statusBadgeClass =
    data.paymentStatus === "Payée" ? "badge-paid" :
    data.paymentStatus === "Partielle" ? "badge-partial" : "badge-unpaid";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-background rounded-2xl shadow-2xl border border-border w-full max-w-3xl max-h-[92vh] flex flex-col overflow-hidden">
        {/* Modal toolbar */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-border bg-muted/30 shrink-0">
          <div className="flex items-center gap-2 text-foreground font-semibold text-sm">
            <FilePdf size={18} weight="duotone" className="text-primary" />
            Aperçu avant impression — <span className="font-mono text-primary">{data.orderNumber}</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleSavePDF}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-muted hover:bg-muted/80 text-foreground text-xs font-medium border border-border transition-colors"
            >
              <FilePdf size={14} weight="duotone" className="text-primary" />
              Enregistrer PDF
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-primary hover:bg-primary/90 text-primary-foreground text-xs font-medium transition-colors"
            >
              <Printer size={14} weight="duotone" />
              Imprimer
            </button>
            <button
              onClick={onClose}
              className="ml-1 p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
            >
              <X size={16} weight="bold" />
            </button>
          </div>
        </div>

        {/* Preview area */}
        <div className="flex-1 overflow-y-auto bg-gray-100 dark:bg-gray-900 p-6">
          <div className="bg-white text-gray-900 rounded-lg shadow-lg mx-auto" style={{ maxWidth: 760, fontFamily: "'Helvetica Neue', Arial, sans-serif" }}>
            {/* Hidden printable content */}
            <div ref={printRef}>
              <div className="page" style={{ padding: "36px 40px" }}>
                {/* Header */}
                <div className="header" style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 28, borderBottom: "2px solid #111", paddingBottom: 20 }}>
                  <div>
                    <div className="shop-name" style={{ fontSize: 20, fontWeight: 800, letterSpacing: "-0.5px" }}>
                      {data.shopName || "Garage"}
                    </div>
                    <div className="shop-info" style={{ fontSize: 11, color: "#444", marginTop: 4, lineHeight: 1.6 }}>
                      {data.shopAddress && <div>{data.shopAddress}</div>}
                      {data.shopPhone && <div>Tél : {data.shopPhone}</div>}
                      {data.shopTps && <div>No. TPS : {data.shopTps}</div>}
                      {data.shopTvq && <div>No. TVQ : {data.shopTvq}</div>}
                    </div>
                  </div>
                  <div className="invoice-meta" style={{ textAlign: "right" }}>
                    <div className="inv-number" style={{ fontSize: 18, fontWeight: 700 }}>{data.orderNumber}</div>
                    <div className="inv-date" style={{ fontSize: 11, color: "#555", marginTop: 4 }}>Date : {data.date}</div>
                    <div>
                      <span className={`badge ${statusBadgeClass}`} style={{
                        display: "inline-block", marginTop: 8, padding: "3px 10px", borderRadius: 999,
                        fontSize: 10, fontWeight: 700, letterSpacing: "0.5px", textTransform: "uppercase",
                        background: data.paymentStatus === "Payée" ? "#dcfce7" : data.paymentStatus === "Partielle" ? "#e0f2fe" : "#fef9c3",
                        color: data.paymentStatus === "Payée" ? "#166534" : data.paymentStatus === "Partielle" ? "#075985" : "#854d0e",
                      }}>
                        {data.paymentStatus}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Client info */}
                <div className="section" style={{ marginBottom: 22 }}>
                  <div className="section-title" style={{ fontSize: 10, textTransform: "uppercase", letterSpacing: 1, color: "#666", fontWeight: 700, marginBottom: 8, borderBottom: "1px solid #e5e7eb", paddingBottom: 4 }}>
                    Informations client &amp; véhicule
                  </div>
                  <div className="client-grid" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "6px 20px", fontSize: 12 }}>
                    <div>
                      <div style={{ color: "#888", fontSize: 10, textTransform: "uppercase", letterSpacing: "0.5px" }}>Client</div>
                      <div style={{ fontWeight: 600 }}>{data.customerName}</div>
                    </div>
                    {data.phone && (
                      <div>
                        <div style={{ color: "#888", fontSize: 10, textTransform: "uppercase", letterSpacing: "0.5px" }}>Téléphone</div>
                        <div style={{ fontWeight: 600 }}>{data.phone}</div>
                      </div>
                    )}
                    <div>
                      <div style={{ color: "#888", fontSize: 10, textTransform: "uppercase", letterSpacing: "0.5px" }}>Véhicule</div>
                      <div style={{ fontWeight: 600 }}>{data.vehicleInfo || "—"}</div>
                    </div>
                    {data.plate && (
                      <div>
                        <div style={{ color: "#888", fontSize: 10, textTransform: "uppercase", letterSpacing: "0.5px" }}>Plaque / VIN</div>
                        <div style={{ fontWeight: 600 }}>{data.plate}</div>
                      </div>
                    )}
                    {data.mileage && (
                      <div>
                        <div style={{ color: "#888", fontSize: 10, textTransform: "uppercase", letterSpacing: "0.5px" }}>Kilométrage</div>
                        <div style={{ fontWeight: 600 }}>{data.mileage}</div>
                      </div>
                    )}
                    {data.mechanic && (
                      <div>
                        <div style={{ color: "#888", fontSize: 10, textTransform: "uppercase", letterSpacing: "0.5px" }}>Mécanicien</div>
                        <div style={{ fontWeight: 600 }}>{data.mechanic}</div>
                      </div>
                    )}
                    {data.jobDesc && (
                      <div style={{ gridColumn: "1 / -1" }}>
                        <div style={{ color: "#888", fontSize: 10, textTransform: "uppercase", letterSpacing: "0.5px" }}>Description des travaux</div>
                        <div style={{ fontWeight: 600 }}>{data.jobDesc}</div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Parts */}
                {partsFiltered.length > 0 && (
                  <div className="section" style={{ marginBottom: 22 }}>
                    <div className="section-title" style={{ fontSize: 10, textTransform: "uppercase", letterSpacing: 1, color: "#666", fontWeight: 700, marginBottom: 8, borderBottom: "1px solid #e5e7eb", paddingBottom: 4 }}>
                      Pièces
                    </div>
                    <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 11.5 }}>
                      <thead>
                        <tr style={{ background: "#f3f4f6" }}>
                          <th style={{ textAlign: "left", padding: "6px 8px", fontSize: 10, textTransform: "uppercase", letterSpacing: "0.6px", color: "#555", fontWeight: 700 }}>Description</th>
                          <th style={{ textAlign: "left", padding: "6px 8px", fontSize: 10, textTransform: "uppercase", letterSpacing: "0.6px", color: "#555", fontWeight: 700 }}>N° pièce</th>
                          <th style={{ textAlign: "center", padding: "6px 8px", fontSize: 10, textTransform: "uppercase", letterSpacing: "0.6px", color: "#555", fontWeight: 700 }}>Qté</th>
                          <th style={{ textAlign: "right", padding: "6px 8px", fontSize: 10, textTransform: "uppercase", letterSpacing: "0.6px", color: "#555", fontWeight: 700 }}>Prix unit.</th>
                          <th style={{ textAlign: "right", padding: "6px 8px", fontSize: 10, textTransform: "uppercase", letterSpacing: "0.6px", color: "#555", fontWeight: 700 }}>Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        {partsFiltered.map((p, i) => (
                          <tr key={i}>
                            <td style={{ padding: "6px 8px", borderBottom: "1px solid #f0f0f0" }}>{p.description}</td>
                            <td style={{ padding: "6px 8px", borderBottom: "1px solid #f0f0f0", color: "#666" }}>{p.partNumber || "—"}</td>
                            <td style={{ padding: "6px 8px", borderBottom: "1px solid #f0f0f0", textAlign: "center" }}>{p.qty}</td>
                            <td style={{ padding: "6px 8px", borderBottom: "1px solid #f0f0f0", textAlign: "right" }}>{fmt(p.unitPrice)}</td>
                            <td style={{ padding: "6px 8px", borderBottom: "1px solid #f0f0f0", textAlign: "right", fontWeight: 600 }}>{fmt(p.qty * p.unitPrice)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}

                {/* Labor */}
                {laborFiltered.length > 0 && (
                  <div className="section" style={{ marginBottom: 22 }}>
                    <div className="section-title" style={{ fontSize: 10, textTransform: "uppercase", letterSpacing: 1, color: "#666", fontWeight: 700, marginBottom: 8, borderBottom: "1px solid #e5e7eb", paddingBottom: 4 }}>
                      Main-d&#39;œuvre
                    </div>
                    <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 11.5 }}>
                      <thead>
                        <tr style={{ background: "#f3f4f6" }}>
                          <th style={{ textAlign: "left", padding: "6px 8px", fontSize: 10, textTransform: "uppercase", letterSpacing: "0.6px", color: "#555", fontWeight: 700 }}>Description</th>
                          <th style={{ textAlign: "center", padding: "6px 8px", fontSize: 10, textTransform: "uppercase", letterSpacing: "0.6px", color: "#555", fontWeight: 700 }}>Heures</th>
                          <th style={{ textAlign: "right", padding: "6px 8px", fontSize: 10, textTransform: "uppercase", letterSpacing: "0.6px", color: "#555", fontWeight: 700 }}>Taux/h</th>
                          <th style={{ textAlign: "right", padding: "6px 8px", fontSize: 10, textTransform: "uppercase", letterSpacing: "0.6px", color: "#555", fontWeight: 700 }}>Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        {laborFiltered.map((l, i) => (
                          <tr key={i}>
                            <td style={{ padding: "6px 8px", borderBottom: "1px solid #f0f0f0" }}>{l.description}</td>
                            <td style={{ padding: "6px 8px", borderBottom: "1px solid #f0f0f0", textAlign: "center" }}>{l.hours}</td>
                            <td style={{ padding: "6px 8px", borderBottom: "1px solid #f0f0f0", textAlign: "right" }}>{fmt(l.rate)}</td>
                            <td style={{ padding: "6px 8px", borderBottom: "1px solid #f0f0f0", textAlign: "right", fontWeight: 600 }}>{fmt(l.hours * l.rate)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}

                {/* Supplies */}
                {suppliesFiltered.length > 0 && (
                  <div className="section" style={{ marginBottom: 22 }}>
                    <div className="section-title" style={{ fontSize: 10, textTransform: "uppercase", letterSpacing: 1, color: "#666", fontWeight: 700, marginBottom: 8, borderBottom: "1px solid #e5e7eb", paddingBottom: 4 }}>
                      Fournitures d&#39;atelier
                    </div>
                    <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 11.5 }}>
                      <thead>
                        <tr style={{ background: "#f3f4f6" }}>
                          <th style={{ textAlign: "left", padding: "6px 8px", fontSize: 10, textTransform: "uppercase", letterSpacing: "0.6px", color: "#555", fontWeight: 700 }}>Description</th>
                          <th style={{ textAlign: "right", padding: "6px 8px", fontSize: 10, textTransform: "uppercase", letterSpacing: "0.6px", color: "#555", fontWeight: 700 }}>Montant</th>
                        </tr>
                      </thead>
                      <tbody>
                        {suppliesFiltered.map((s, i) => (
                          <tr key={i}>
                            <td style={{ padding: "6px 8px", borderBottom: "1px solid #f0f0f0" }}>{s.description}</td>
                            <td style={{ padding: "6px 8px", borderBottom: "1px solid #f0f0f0", textAlign: "right", fontWeight: 600 }}>{fmt(s.amount)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}

                {/* Totals */}
                <table className="totals" style={{ width: 260, marginLeft: "auto", marginTop: 12, borderCollapse: "collapse" }}>
                  <tbody>
                    <tr>
                      <td style={{ padding: "4px 8px", color: "#555", fontSize: 12 }}>Sous-total</td>
                      <td style={{ padding: "4px 8px", textAlign: "right", fontSize: 12 }}>{fmt(data.subtotal)}</td>
                    </tr>
                    <tr>
                      <td style={{ padding: "4px 8px", color: "#555", fontSize: 12 }}>TPS (5,00 %)</td>
                      <td style={{ padding: "4px 8px", textAlign: "right", fontSize: 12 }}>{fmt(data.tpsAmount)}</td>
                    </tr>
                    <tr>
                      <td style={{ padding: "4px 8px", color: "#555", fontSize: 12 }}>TVQ (9,975 %)</td>
                      <td style={{ padding: "4px 8px", textAlign: "right", fontSize: 12 }}>{fmt(data.tvqAmount)}</td>
                    </tr>
                    <tr className="grand-total" style={{ borderTop: "2px solid #111" }}>
                      <td style={{ padding: "8px 8px 4px", fontSize: 14, fontWeight: 800 }}>Total TTC</td>
                      <td style={{ padding: "8px 8px 4px", textAlign: "right", fontSize: 14, fontWeight: 800 }}>{fmt(data.total)}</td>
                    </tr>
                    {(data.amountPaid ?? 0) > 0 && (
                      <>
                        <tr>
                          <td style={{ padding: "4px 8px", color: "#555", fontSize: 12 }}>Montant reçu</td>
                          <td style={{ padding: "4px 8px", textAlign: "right", fontSize: 12, color: "#166534" }}>− {fmt(data.amountPaid ?? 0)}</td>
                        </tr>
                        <tr>
                          <td style={{ padding: "4px 8px", color: "#555", fontSize: 12, fontWeight: 700 }}>Solde dû</td>
                          <td style={{ padding: "4px 8px", textAlign: "right", fontSize: 12, fontWeight: 700 }}>{fmt(balanceDue)}</td>
                        </tr>
                      </>
                    )}
                    {data.paymentMethod && (
                      <tr>
                        <td style={{ padding: "4px 8px", color: "#888", fontSize: 11 }}>Mode de paiement</td>
                        <td style={{ padding: "4px 8px", textAlign: "right", fontSize: 11, color: "#888" }}>{data.paymentMethod}</td>
                      </tr>
                    )}
                  </tbody>
                </table>

                {/* Footer */}
                <div className="footer" style={{ marginTop: 28, paddingTop: 12, borderTop: "1px solid #e5e7eb", fontSize: 10, color: "#888", display: "flex", justifyContent: "space-between" }}>
                  <div>Merci de votre confiance !</div>
                  <div>Document généré par GarageManager</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
