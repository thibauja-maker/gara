import { useState } from "react";
import { X, Envelope, DeviceMobile, CheckCircle, Warning, Spinner } from "@phosphor-icons/react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";

export type SendInvoiceData = {
  orderNumber: string;
  customerName: string;
  vehicleInfo: string;
  total: number;
  phone?: string;
  email?: string;
};

type Props = {
  invoice: SendInvoiceData;
  onClose: () => void;
};

type SendMethod = "email" | "sms";
type SendStatus = "idle" | "sending" | "success" | "error";

export default function SendInvoiceModal({ invoice, onClose }: Props) {
  const [method, setMethod] = useState<SendMethod>("email");
  const [emailVal, setEmailVal] = useState(invoice.email ?? "");
  const [phoneVal, setPhoneVal] = useState(invoice.phone ?? "");
  const [message, setMessage] = useState(
    `Bonjour ${invoice.customerName},\n\nVotre facture ${invoice.orderNumber} d'un montant de ${invoice.total.toLocaleString("fr-CA", { style: "currency", currency: "CAD" })} est prête.\n\nMerci de votre confiance — GarageManager`
  );
  const [status, setStatus] = useState<SendStatus>("idle");
  const [errorMsg, setErrorMsg] = useState("");

  const fmt = (n: number) =>
    n.toLocaleString("fr-CA", { style: "currency", currency: "CAD" });

  const handleSend = () => {
    const target = method === "email" ? emailVal.trim() : phoneVal.trim();
    if (!target) {
      setErrorMsg(method === "email" ? "Entrez une adresse courriel." : "Entrez un numéro de téléphone.");
      return;
    }
    if (method === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(target)) {
      setErrorMsg("Adresse courriel invalide.");
      return;
    }
    if (method === "sms" && !/^[\d\s\(\)\-\+]{7,}$/.test(target)) {
      setErrorMsg("Numéro de téléphone invalide.");
      return;
    }
    setErrorMsg("");

    if (method === "email") {
      // Construit un lien mailto: avec sujet + corps pré-rempli
      // Le client de messagerie par défaut (Outlook, Gmail desktop, Thunderbird, etc.) s'ouvre directement
      const subject = encodeURIComponent(`Facture ${invoice.orderNumber} — GarageManager`);
      const body = encodeURIComponent(message);
      const mailtoLink = `mailto:${encodeURIComponent(target)}?subject=${subject}&body=${body}`;
      // Utilise un <a> invisible pour déclencher le client mail sans bloquer les popups
      const a = document.createElement("a");
      a.href = mailtoLink;
      a.style.display = "none";
      document.body.appendChild(a);
      a.click();
      setTimeout(() => document.body.removeChild(a), 500);
    } else {
      const body = encodeURIComponent(message);
      window.open(`sms:${target}?body=${body}`, "_blank");
    }

    setStatus("success");
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm px-4">
      <div className="bg-card border border-border rounded-2xl shadow-2xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-border bg-background">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center">
              <Envelope size={14} weight="duotone" className="text-primary" />
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground">Envoyer la facture</p>
              <p className="text-[11px] text-muted-foreground font-mono">{invoice.orderNumber}</p>
            </div>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors">
            <X size={16} weight="bold" />
          </button>
        </div>

        {status === "success" ? (
          /* ── Success state ── */
          <div className="px-6 py-10 flex flex-col items-center text-center gap-3">
            <div className="w-14 h-14 rounded-full bg-green-500/10 flex items-center justify-center mb-1">
              <CheckCircle size={30} weight="duotone" className="text-green-500" />
            </div>
            <p className="text-base font-semibold text-foreground">
              {method === "email" ? "Courriel envoyé !" : "SMS envoyé !"}
            </p>
            <p className="text-sm text-muted-foreground">
              La facture <span className="font-mono font-semibold text-foreground">{invoice.orderNumber}</span> a été transmise à{" "}
              <span className="font-medium text-foreground">{method === "email" ? emailVal : phoneVal}</span>.
            </p>
            <Button onClick={onClose} className="mt-2 bg-primary text-primary-foreground rounded-lg text-sm px-6">
              Fermer
            </Button>
          </div>
        ) : (
          /* ── Form state ── */
          <div className="px-5 py-5 space-y-5">
            {/* Invoice preview pill */}
            <div className="flex items-center gap-3 px-3 py-2.5 rounded-xl bg-muted/50 border border-border">
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-foreground truncate">{invoice.customerName}</p>
                <p className="text-[11px] text-muted-foreground truncate">{invoice.vehicleInfo}</p>
              </div>
              <div className="text-right shrink-0">
                <p className="text-xs font-bold font-mono text-foreground">{fmt(invoice.total)}</p>
                <p className="text-[10px] text-muted-foreground">Total TTC</p>
              </div>
            </div>

            {/* Method toggle */}
            <div>
              <Label className="text-[10px] uppercase tracking-widest text-muted-foreground block mb-2">
                Mode d&#39;envoi
              </Label>
              <div className="flex gap-2">
                <button
                  onClick={() => { setMethod("email"); setErrorMsg(""); }}
                  className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl border text-sm font-medium transition-all ${
                    method === "email"
                      ? "bg-primary text-primary-foreground border-primary shadow-sm"
                      : "bg-background text-muted-foreground border-border hover:bg-muted"
                  }`}
                >
                  <Envelope size={15} weight="duotone" /> Courriel
                </button>
                <button
                  onClick={() => { setMethod("sms"); setErrorMsg(""); }}
                  className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl border text-sm font-medium transition-all ${
                    method === "sms"
                      ? "bg-primary text-primary-foreground border-primary shadow-sm"
                      : "bg-background text-muted-foreground border-border hover:bg-muted"
                  }`}
                >
                  <DeviceMobile size={15} weight="duotone" /> SMS
                </button>
              </div>
            </div>

            {/* Destination */}
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                {method === "email" ? "Adresse courriel" : "Numéro de téléphone"}
              </Label>
              {method === "email" ? (
                <Input
                  type="email"
                  value={emailVal}
                  onChange={(e) => { setEmailVal(e.target.value); setErrorMsg(""); }}
                  placeholder="client@exemple.com"
                  className="rounded-lg border-border text-sm"
                />
              ) : (
                <Input
                  type="tel"
                  value={phoneVal}
                  onChange={(e) => { setPhoneVal(e.target.value); setErrorMsg(""); }}
                  placeholder="(418) 555-0000"
                  className="rounded-lg border-border text-sm"
                />
              )}
            </div>

            {/* Message */}
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                Message personnalisé
              </Label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows={5}
                className="w-full text-xs text-foreground bg-background border border-border rounded-lg p-3 resize-none focus:outline-none focus:ring-1 focus:ring-ring leading-relaxed"
              />
            </div>

            {errorMsg && (
              <div className="flex items-center gap-2 text-xs text-red-500">
                <Warning size={13} weight="duotone" />
                {errorMsg}
              </div>
            )}

            <Separator />

            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={onClose}
                className="flex-1 rounded-lg text-sm border-border"
                disabled={status === "sending"}
              >
                Annuler
              </Button>
              <Button
                onClick={handleSend}
                disabled={status === "sending"}
                className="flex-1 bg-primary text-primary-foreground rounded-lg text-sm gap-2 shadow-sm"
              >
                {status === "sending" ? (
                  <>
                    <Spinner size={14} weight="duotone" className="animate-spin" />
                    Envoi en cours…
                  </>
                ) : (
                  <>
                    {method === "email" ? (
                      <Envelope size={14} weight="duotone" />
                    ) : (
                      <DeviceMobile size={14} weight="duotone" />
                    )}
                    {method === "email" ? "Envoyer le courriel" : "Envoyer le SMS"}
                  </>
                )}
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
