import { useTheme, AccentColor, FontSize, ThemeMode } from "@/context/ThemeContext";
import { X, Sun, Moon, ArrowCounterClockwise, TextT, SidebarSimple } from "@phosphor-icons/react";

const ACCENT_OPTIONS: { value: AccentColor; label: string; swatch: string }[] = [
  { value: "blue",    label: "Bleu",    swatch: "bg-blue-500" },
  { value: "red",     label: "Rouge",   swatch: "bg-red-500" },
  { value: "emerald", label: "Vert",    swatch: "bg-emerald-500" },
  { value: "violet",  label: "Violet",  swatch: "bg-violet-500" },
  { value: "orange",  label: "Orange",  swatch: "bg-orange-500" },
];

const FONT_SIZES: { value: FontSize; label: string }[] = [
  { value: "sm", label: "Petit" },
  { value: "md", label: "Moyen" },
  { value: "lg", label: "Grand" },
];

export default function ThemeCustomizer({ onClose }: { onClose: () => void }) {
  const { theme, setMode, setAccent, setFontSize, setSidebarCompact, resetTheme } = useTheme();

  return (
    <div className="fixed right-0 top-0 bottom-0 w-72 z-50 flex flex-col shadow-2xl bg-card border-l border-border">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-border shrink-0">
        <div>
          <h2 className="text-[14px] font-bold text-foreground">Personnaliser</h2>
          <p className="text-[11px] text-muted-foreground mt-0.5">Thème &amp; affichage</p>
        </div>
        <button
          onClick={onClose}
          className="w-7 h-7 flex items-center justify-center rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
        >
          <X size={15} />
        </button>
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto px-5 py-5 space-y-7">

        {/* Mode */}
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground mb-3">Mode d&#39;affichage</p>
          <div className="grid grid-cols-2 gap-2">
            {([
              { value: "light" as ThemeMode, label: "Clair", icon: Sun },
              { value: "dark"  as ThemeMode, label: "Sombre", icon: Moon },
            ] as { value: ThemeMode; label: string; icon: React.ElementType }[]).map(({ value, label, icon: Icon }) => (
              <button
                key={value}
                onClick={() => setMode(value)}
                className={`flex flex-col items-center gap-2 py-4 rounded-xl border-2 transition-all duration-150 ${
                  theme.mode === value
                    ? "border-primary bg-primary/8 text-primary"
                    : "border-border text-muted-foreground hover:border-primary/40 hover:bg-muted/50"
                }`}
              >
                <Icon size={20} weight={theme.mode === value ? "fill" : "regular"} />
                <span className="text-[12px] font-semibold">{label}</span>
                {value === "dark" && (
                  <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-black/10 dark:bg-white/10 text-muted-foreground">Noir &amp; Rouge</span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Accent Color */}
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground mb-3">Couleur d&#39;accent</p>
          <div className="flex flex-wrap gap-2">
            {ACCENT_OPTIONS.map(({ value, label, swatch }) => (
              <button
                key={value}
                onClick={() => setAccent(value)}
                title={label}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-full border-2 transition-all duration-150 ${
                  theme.accent === value
                    ? "border-current text-primary font-semibold bg-primary/8"
                    : "border-border text-muted-foreground hover:border-primary/40"
                }`}
                style={theme.accent === value ? { borderColor: "hsl(var(--primary))", color: "hsl(var(--primary))" } : {}}
              >
                <span className={`w-3 h-3 rounded-full ${swatch} shrink-0`} />
                <span className="text-[11px]">{label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Font Size */}
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground mb-3 flex items-center gap-1.5">
            <TextT size={11} />Taille de police
          </p>
          <div className="grid grid-cols-3 gap-2">
            {FONT_SIZES.map(({ value, label }) => (
              <button
                key={value}
                onClick={() => setFontSize(value)}
                className={`py-2 rounded-lg border-2 transition-all duration-150 text-center ${
                  theme.fontSize === value
                    ? "border-primary bg-primary/8 text-primary font-semibold"
                    : "border-border text-muted-foreground hover:border-primary/40"
                }`}
              >
                <span className={`font-medium ${value === "sm" ? "text-[11px]" : value === "md" ? "text-[13px]" : "text-[15px]"}`}>{label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Sidebar */}
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground mb-3 flex items-center gap-1.5">
            <SidebarSimple size={11} />Barre latérale
          </p>
          <button
            onClick={() => setSidebarCompact(!theme.sidebarCompact)}
            className={`w-full flex items-center justify-between px-4 py-3 rounded-xl border-2 transition-all duration-150 ${
              theme.sidebarCompact
                ? "border-primary bg-primary/8"
                : "border-border hover:border-primary/40"
            }`}
          >
            <span className="text-[12px] font-medium text-foreground">Mode compact</span>
            <div className={`w-9 h-5 rounded-full transition-colors duration-200 relative ${theme.sidebarCompact ? "bg-primary" : "bg-muted-foreground/30"}`}>
              <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all duration-200 ${theme.sidebarCompact ? "left-4" : "left-0.5"}`} />
            </div>
          </button>
        </div>

        {/* Preview swatch */}
        <div className="rounded-xl border border-border bg-muted/30 p-4 space-y-2">
          <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold">Aperçu</p>
          <div className="flex gap-2 items-center">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: "hsl(var(--primary))" }}>
              <span className="text-white text-[10px] font-bold">G</span>
            </div>
            <div className="flex-1">
              <div className="h-2 rounded-full w-24 mb-1" style={{ background: "hsl(var(--primary))" }} />
              <div className="h-1.5 rounded-full w-16 bg-muted-foreground/20" />
            </div>
          </div>
          <div className="flex gap-1.5">
            <span className="text-[10px] px-2 py-1 rounded-full font-medium text-white" style={{ background: "hsl(var(--primary))" }}>Actif</span>
            <span className="text-[10px] px-2 py-1 rounded-full font-medium bg-muted text-muted-foreground">Inactif</span>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="shrink-0 border-t border-border px-5 py-4">
        <button
          onClick={resetTheme}
          className="w-full flex items-center justify-center gap-2 py-2 text-[12px] text-muted-foreground hover:text-foreground border border-border rounded-lg hover:bg-muted transition-colors"
        >
          <ArrowCounterClockwise size={13} />
          Réinitialiser les paramètres
        </button>
      </div>
    </div>
  );
}
