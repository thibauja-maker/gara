import { useState } from "react";
import { X, Receipt, CheckCircle, CreditCard, ArrowRight, Star, Lightning } from "@phosphor-icons/react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";

type Props = { onClose: () => void };

const INVOICES = [
  { id: "INV-2025-004", date: "2025-04-01", amount: 49.00, status: "Payée" },
  { id: "INV-2025-003", date: "2025-03-01", amount: 49.00, status: "Payée" },
  { id: "INV-2025-002", date: "2025-02-01", amount: 49.00, status: "Payée" },
  { id: "INV-2025-001", date: "2025-01-01", amount: 49.00, status: "Payée" },
];

const PLANS = [
  {
    id: "starter",
    name: "Démarrage",
    price: 0,
    features: ["1 utilisateur", "50 ordres/mois", "Factures de base", "Support courriel"],
    current: false,
    highlight: false,
  },
  {
    id: "pro",
    name: "Professionnel",
    price: 49,
    features: ["5 utilisateurs", "Ordres illimités", "TPS/TVQ auto", "Estimations", "Inventaire", "Support prioritaire"],
    current: true,
    highlight: true,
  },
  {
    id: "shop",
    name: "Atelier +",
    price: 99,
    features: ["Utilisateurs illimités", "Multi-succursales", "Rapports avancés", "API accès", "Support dédié 24/7"],
    current: false,
    highlight: false,
  },
];

export default function BillingModal({ onClose }: Props) {
  const [tab, setTab] = useState<"overview" | "plans" | "history">("overview");

  const fmt = (n: number) => n.toLocaleString("fr-CA", { style: "currency", currency: "CAD" });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 w-full max-w-xl bg-card border border-border rounded-2xl shadow-2xl overflow-hidden" style={{ maxHeight: "88vh" }}>
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
              <Receipt size={15} weight="duotone" className="text-primary" />
            </div>
            <div>
              <h2 className="text-[15px] font-semibold text-foreground">Facturation &amp; Abonnement</h2>
              <p className="text-[11px] text-muted-foreground">Gérez votre forfait et vos paiements</p>
            </div>
          </div>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-md text-muted-foreground hover:bg-muted transition-colors">
            <X size={15} weight="bold" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-border px-6 gap-0">
          {([ ["overview", "Aperçu"], ["plans", "Forfaits"], ["history", "Historique"] ] as const).map(([id, label]) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`px-4 py-3 text-[13px] font-medium border-b-2 transition-all ${
                tab === id ? "border-primary text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="overflow-y-auto" style={{ maxHeight: "calc(88vh - 160px)" }}>
          {/* OVERVIEW */}
          {tab === "overview" && (
            <div className="px-6 py-5 space-y-5">
              {/* Current plan */}
              <div className="p-4 rounded-xl bg-primary/5 border border-primary/20">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Star size={15} weight="fill" className="text-primary" />
                    <span className="text-sm font-bold text-foreground">Forfait Professionnel</span>
                  </div>
                  <Badge className="bg-primary text-primary-foreground text-[10px] px-2 py-0.5 border-0">Actif</Badge>
                </div>
                <p className="text-xs text-muted-foreground mb-3">Facturation mensuelle · prochain renouvellement le 1er mai 2025</p>
                <div className="flex items-end gap-1">
                  <span className="text-2xl font-bold text-foreground">49,00 $</span>
                  <span className="text-xs text-muted-foreground mb-1">/mois</span>
                </div>
              </div>

              {/* Payment method */}
              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Méthode de paiement</p>
                <div className="flex items-center gap-3 p-3 rounded-xl border border-border bg-background">
                  <div className="w-10 h-7 rounded-md bg-muted flex items-center justify-center shrink-0">
                    <CreditCard size={16} weight="duotone" className="text-muted-foreground" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground">Visa •••• 4242</p>
                    <p className="text-xs text-muted-foreground">Expire 12/2027</p>
                  </div>
                  <button className="text-xs text-primary hover:underline">Modifier</button>
                </div>
              </div>

              <Separator />

              {/* Usage */}
              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Utilisation ce mois</p>
                <div className="space-y-3">
                  {[
                    { label: "Ordres de travail", used: 34, max: null },
                    { label: "Utilisateurs actifs",  used: 3,  max: 5    },
                    { label: "Estimations créées",   used: 12, max: null },
                  ].map((u) => (
                    <div key={u.label}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-muted-foreground">{u.label}</span>
                        <span className="font-medium text-foreground">{u.used}{u.max ? ` / ${u.max}` : ""}</span>
                      </div>
                      {u.max && (
                        <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                          <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${(u.used / u.max) * 100}%` }} />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <Separator />

              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="flex-1 text-sm rounded-lg" onClick={() => setTab("plans")}>
                  Changer de forfait
                </Button>
                <Button variant="outline" size="sm" className="text-sm rounded-lg text-red-500 border-red-200 hover:bg-red-50 dark:border-red-900/40 dark:hover:bg-red-900/20">
                  Annuler l&#39;abonnement
                </Button>
              </div>
            </div>
          )}

          {/* PLANS */}
          {tab === "plans" && (
            <div className="px-6 py-5 space-y-4">
              <p className="text-xs text-muted-foreground">Comparez les forfaits et passez à un niveau supérieur à tout moment.</p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {PLANS.map((plan) => (
                  <div
                    key={plan.id}
                    className={`relative p-4 rounded-xl border transition-all ${
                      plan.highlight
                        ? "border-primary bg-primary/5 shadow-md"
                        : "border-border bg-background"
                    }`}
                  >
                    {plan.highlight && (
                      <div className="absolute -top-2.5 left-1/2 -translate-x-1/2">
                        <Badge className="bg-primary text-primary-foreground text-[10px] px-2.5 py-0.5 border-0 flex items-center gap-1">
                          <Lightning size={9} weight="fill" /> Actuel
                        </Badge>
                      </div>
                    )}
                    <p className="text-sm font-bold text-foreground mb-1">{plan.name}</p>
                    <div className="flex items-end gap-1 mb-3">
                      <span className="text-xl font-bold text-foreground">{plan.price === 0 ? "Gratuit" : `${plan.price} $`}</span>
                      {plan.price > 0 && <span className="text-xs text-muted-foreground mb-0.5">/mois</span>}
                    </div>
                    <ul className="space-y-1.5 mb-4">
                      {plan.features.map((f) => (
                        <li key={f} className="flex items-center gap-1.5 text-xs text-foreground">
                          <CheckCircle size={11} weight="fill" className="text-primary shrink-0" /> {f}
                        </li>
                      ))}
                    </ul>
                    <Button
                      size="sm"
                      disabled={plan.current}
                      className={`w-full text-xs rounded-lg ${plan.current ? "bg-muted text-muted-foreground cursor-default" : "bg-primary text-primary-foreground"}`}
                    >
                      {plan.current ? "Forfait actuel" : plan.price > 49 ? "Passer à +" : "Rétrograder"}
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* HISTORY */}
          {tab === "history" && (
            <div className="px-6 py-5 space-y-3">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Historique des paiements</p>
              <div className="space-y-2">
                {INVOICES.map((inv) => (
                  <div key={inv.id} className="flex items-center gap-3 p-3 rounded-xl border border-border bg-background hover:bg-muted/30 transition-colors">
                    <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <Receipt size={13} weight="duotone" className="text-primary" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-foreground">{inv.id}</p>
                      <p className="text-xs text-muted-foreground">{new Date(inv.date).toLocaleDateString("fr-CA", { year: "numeric", month: "long", day: "numeric" })}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-foreground">{fmt(inv.amount)}</p>
                      <Badge className="text-[10px] px-2 py-0 rounded-full border-0 bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400">
                        {inv.status}
                      </Badge>
                    </div>
                    <button className="text-muted-foreground hover:text-primary transition-colors ml-1">
                      <ArrowRight size={13} weight="duotone" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
