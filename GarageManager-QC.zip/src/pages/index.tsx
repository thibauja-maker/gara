import GarageApp from "@/GarageApp";

export default function HomePage() {
  return <GarageApp />;
}
