/**
 * Point d'entrée de l'application GarageManager.
 * Importé depuis la page d'accueil — remplace le contenu par défaut.
 */
import { useState, useCallback } from "react";
import { ThemeProvider } from "./context/ThemeContext";
import { PriceVisibilityProvider } from "./context/PriceVisibilityContext";
import MainNavigation from "./sections/MainNavigation";
import WorkspaceTopbar from "./sections/WorkspaceTopbar";
import Dashboard from "./sections/Dashboard";
import RepairOrders from "./sections/RepairOrders";
import BaysSchedule from "./sections/BaysSchedule";
import InvoicesTaxes from "./sections/InvoicesTaxes";
import Customers from "./sections/Customers";
import CalendarSection from "./sections/Calendar";
import Inventory from "./sections/Inventory";
import Estimation from "./sections/Estimation";
import PartsCatalog from "./sections/PartsCatalog";
import type { QuotePart } from "./sections/PartsCatalog";
import Integrations from "./sections/Integrations";
import Reports from "./sections/Reports";
import Suppliers from "./sections/Suppliers";
import WorkstationLogin, {
  getWorkstationSession,
  clearWorkstationSession,
  type WorkstationSession,
} from "./components/WorkstationLogin";
import IdleLockScreen from "./components/IdleLockScreen";
import { canAccess, type SectionId } from "./lib/permissions";
import { useIdleTimer } from "./hooks/use-idle-timer";
import { getIdleTimeout, IDLE_WARNING_MS } from "./lib/session-timeout";
import { Lock } from "@phosphor-icons/react";
import {
  DEFAULT_WORKSTATIONS_JBL,
} from "./components/WorkstationLogin";
import { useSecureLocalStorage } from "./hooks/use-secure-local-storage";

// ── Écran d'accès refusé ──────────────────────────────────────────────────────
function AccessDenied({ section, role }: { section: string; role: string }) {
  return (
    <div className="flex flex-col items-center justify-center h-full min-h-[60vh] gap-5 text-center px-6">
      <div className="w-16 h-16 rounded-2xl bg-red-100 dark:bg-red-900/30 flex items-center justify-center">
        <Lock size={28} weight="duotone" className="text-red-500" />
      </div>
      <div className="space-y-1.5 max-w-sm">
        <h2 className="text-lg font-semibold text-foreground">Accès refusé</h2>
        <p className="text-sm text-muted-foreground">
          Vous n&#39;avez pas accès à la section{" "}
          <span className="font-medium text-foreground">« {section} »</span>.
        </p>
        <p className="text-xs text-muted-foreground/70 mt-1">
          Rôle actuel&#160;:{" "}
          <span className="font-mono text-xs bg-muted px-1.5 py-0.5 rounded">
            {role}
          </span>
        </p>
        <p className="text-xs text-muted-foreground/60 mt-2">
          Contactez votre administrateur si vous pensez qu&#39;il s&#39;agit
          d&#39;une erreur.
        </p>
      </div>
    </div>
  );
}

export type InvoicePrefill = {
  customerName: string;
  phone: string;
  vehicleInfo: string;
  parts?: Array<{
    id: number;
    description: string;
    partNumber: string;
    qty: number;
    unitPrice: number;
  }>;
  labor?: Array<{
    id: number;
    description: string;
    hours: number;
    rate: number;
  }>;
  supplies?: Array<{ id: number; description: string; amount: number }>;
  sourceEstimateNumber?: string;
};

export type EstimationPrefill = {
  parts: QuotePart[];
};

export default function GarageApp() {
  const [activePanel, setActivePanel] = useState("dashboard");
  const [invoicePrefill, setInvoicePrefill] = useState<InvoicePrefill | null>(
    null,
  );
  const [estimationPrefill, setEstimationPrefill] =
    useState<EstimationPrefill | null>(null);
  const [session, setSession] = useState<WorkstationSession | null>(() =>
    getWorkstationSession(),
  );
  const [isLocked, setIsLocked] = useState(false);
  const [warningSecsLeft, setWarningSecsLeft] = useState<number | null>(null);

  const orgId = session?.orgId ?? "default";
  const [workstations] = useSecureLocalStorage(
    `garagemanager_workstations_${orgId}`,
    DEFAULT_WORKSTATIONS_JBL,
  );

  const handleIdle = useCallback(() => {
    setIsLocked(true);
    setWarningSecsLeft(null);
  }, []);

  const handleWarning = useCallback((secs: number) => {
    setWarningSecsLeft(secs);
  }, []);

  const handleResume = useCallback(() => {
    setWarningSecsLeft(null);
  }, []);

  useIdleTimer({
    timeoutMs: session ? getIdleTimeout(session.userRole) : 20 * 60 * 1000,
    warningMs: IDLE_WARNING_MS,
    onIdle: handleIdle,
    onWarning: handleWarning,
    onResume: handleResume,
    enabled: !!session && !isLocked,
  });

  const handleUnlock = useCallback(
    (password: string): boolean => {
      if (!session) return false;
      for (const ws of workstations) {
        const user = ws.users.find(
          (u) => u.id === session.userId && (u.password ?? "") === password,
        );
        if (user) {
          setIsLocked(false);
          setWarningSecsLeft(null);
          return true;
        }
      }
      return false;
    },
    [session, workstations],
  );

  const handleLogout = useCallback(() => {
    clearWorkstationSession();
    setSession(null);
    setIsLocked(false);
    setWarningSecsLeft(null);
  }, []);

  if (!session) {
    return (
      <ThemeProvider>
        <WorkstationLogin
          onLogin={(s) => {
            setSession(s);
            setIsLocked(false);
          }}
        />
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider>
      <PriceVisibilityProvider>
        {(isLocked || warningSecsLeft !== null) && (
          <IdleLockScreen
            session={session}
            warningSecsLeft={isLocked ? null : warningSecsLeft}
            onUnlock={handleUnlock}
            onSwitchUser={handleLogout}
          />
        )}
        <AppShell
          activePanel={activePanel}
          onNavigate={setActivePanel}
          invoicePrefill={invoicePrefill}
          setInvoicePrefill={setInvoicePrefill}
          estimationPrefill={estimationPrefill}
          setEstimationPrefill={setEstimationPrefill}
          session={session}
          onLogout={handleLogout}
        />
      </PriceVisibilityProvider>
    </ThemeProvider>
  );
}

function AppShell({
  activePanel,
  onNavigate,
  invoicePrefill,
  setInvoicePrefill,
  estimationPrefill,
  setEstimationPrefill,
  session,
  onLogout,
}: {
  activePanel: string;
  onNavigate: (p: string) => void;
  invoicePrefill: InvoicePrefill | null;
  setInvoicePrefill: (v: InvoicePrefill | null) => void;
  estimationPrefill: EstimationPrefill | null;
  setEstimationPrefill: (v: EstimationPrefill | null) => void;
  session: WorkstationSession;
  onLogout: () => void;
}) {
  const handleCreateInvoice = (prefill: InvoicePrefill) => {
    setInvoicePrefill(prefill);
    onNavigate("invoices-taxes");
  };

  return (
    <div className="h-screen bg-background text-foreground flex overflow-hidden">
      <MainNavigation
        activePanel={activePanel}
        onNavigate={onNavigate}
        session={session}
      />
      <div className="flex-1 flex flex-col overflow-hidden">
        <WorkspaceTopbar
          onNavigate={onNavigate}
          session={session}
          onLogout={onLogout}
        />
        <main className="flex-1 overflow-y-auto">
          {activePanel === "dashboard" && <Dashboard orgId={session.orgId} />}
          {activePanel === "repair-orders" &&
            (canAccess(session.userRole, "repair-orders" as SectionId) ? (
              <RepairOrders orgId={session.orgId} />
            ) : (
              <AccessDenied
                section="Ordres de travail"
                role={session.userRole}
              />
            ))}
          {activePanel === "bays-schedule" &&
            (canAccess(session.userRole, "bays-schedule" as SectionId) ? (
              <BaysSchedule />
            ) : (
              <AccessDenied
                section="Calendrier des Lifts"
                role={session.userRole}
              />
            ))}
          {activePanel === "calendar" &&
            (canAccess(session.userRole, "calendar" as SectionId) ? (
              <CalendarSection orgId={session.orgId} />
            ) : (
              <AccessDenied section="Calendrier" role={session.userRole} />
            ))}
          {activePanel === "invoices-taxes" &&
            (canAccess(session.userRole, "invoices-taxes" as SectionId) ? (
              <InvoicesTaxes
                prefill={invoicePrefill}
                onPrefillConsumed={() => setInvoicePrefill(null)}
                orgId={session.orgId}
              />
            ) : (
              <AccessDenied
                section="Factures & Taxes"
                role={session.userRole}
              />
            ))}
          {activePanel === "customers" &&
            (canAccess(session.userRole, "customers" as SectionId) ? (
              <Customers
                onCreateInvoice={handleCreateInvoice}
                orgId={session.orgId}
              />
            ) : (
              <AccessDenied section="Clients" role={session.userRole} />
            ))}
          {activePanel === "inventory" &&
            (canAccess(session.userRole, "inventory" as SectionId) ? (
              <Inventory orgId={session.orgId} />
            ) : (
              <AccessDenied section="Inventaire" role={session.userRole} />
            ))}
          {activePanel === "estimation" &&
            (canAccess(session.userRole, "estimation" as SectionId) ? (
              <Estimation
                prefillParts={estimationPrefill?.parts ?? null}
                onPrefillConsumed={() => setEstimationPrefill(null)}
                orgId={session.orgId}
                onCreateInvoice={(prefill) => {
                  setInvoicePrefill(prefill);
                  onNavigate("invoices-taxes");
                }}
              />
            ) : (
              <AccessDenied section="Estimations" role={session.userRole} />
            ))}
          {activePanel === "parts-catalog" &&
            (canAccess(session.userRole, "parts-catalog" as SectionId) ? (
              <PartsCatalog
                orgId={session.orgId}
                onCreateEstimate={(parts) => {
                  setEstimationPrefill({ parts });
                  onNavigate("estimation");
                }}
              />
            ) : (
              <AccessDenied
                section="Catalogue pièces"
                role={session.userRole}
              />
            ))}
          {activePanel === "suppliers" &&
            (canAccess(session.userRole, "suppliers" as SectionId) ? (
              <Suppliers orgId={session.orgId} />
            ) : (
              <AccessDenied section="Fournisseurs" role={session.userRole} />
            ))}
          {activePanel === "integrations" &&
            (canAccess(session.userRole, "integrations" as SectionId) ? (
              <Integrations orgId={session.orgId} />
            ) : (
              <AccessDenied section="Intégrations" role={session.userRole} />
            ))}
          {activePanel === "reports" &&
            (canAccess(session.userRole, "reports" as SectionId) ? (
              <Reports orgId={session.orgId} />
            ) : (
              <AccessDenied section="Rapports" role={session.userRole} />
            ))}
        </main>
      </div>
    </div>
  );
}
