import { createContext, useContext, useEffect, useState, ReactNode } from "react";

export type ThemeMode = "light" | "dark";
export type AccentColor = "blue" | "red" | "emerald" | "violet" | "orange";
export type FontSize = "sm" | "md" | "lg";

export interface ThemeSettings {
  mode: ThemeMode;
  accent: AccentColor;
  fontSize: FontSize;
  sidebarCompact: boolean;
}

interface ThemeContextValue {
  theme: ThemeSettings;
  setMode: (m: ThemeMode) => void;
  setAccent: (a: AccentColor) => void;
  setFontSize: (s: FontSize) => void;
  setSidebarCompact: (v: boolean) => void;
  resetTheme: () => void;
}

const DEFAULT: ThemeSettings = {
  mode: "light",
  accent: "blue",
  fontSize: "md",
  sidebarCompact: false,
};

const ThemeContext = createContext<ThemeContextValue | null>(null);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<ThemeSettings>(() => {
    try {
      const saved = localStorage.getItem("garagemanager-theme");
      return saved ? { ...DEFAULT, ...JSON.parse(saved) } : DEFAULT;
    } catch {
      return DEFAULT;
    }
  });

  useEffect(() => {
    localStorage.setItem("garagemanager-theme", JSON.stringify(theme));
    const root = document.documentElement;

    // Mode
    root.classList.toggle("dark", theme.mode === "dark");

    // Font size
    const fontSizeMap: Record<FontSize, string> = { sm: "13px", md: "14px", lg: "15px" };
    root.style.setProperty("--app-font-size", fontSizeMap[theme.fontSize]);

    // Accent color CSS vars (hsl)
    const accentMap: Record<AccentColor, { primary: string; primaryFg: string }> = {
      blue:    { primary: "221 83% 53%",  primaryFg: "0 0% 100%" },
      red:     { primary: "0 84% 50%",    primaryFg: "0 0% 100%" },
      emerald: { primary: "160 60% 40%",  primaryFg: "0 0% 100%" },
      violet:  { primary: "262 83% 58%",  primaryFg: "0 0% 100%" },
      orange:  { primary: "25 95% 53%",   primaryFg: "0 0% 100%" },
    };
    root.style.setProperty("--primary", accentMap[theme.accent].primary);
    root.style.setProperty("--primary-foreground", accentMap[theme.accent].primaryFg);
    root.style.setProperty("--ring", accentMap[theme.accent].primary);
  }, [theme]);

  const setMode = (mode: ThemeMode) => setTheme((p) => ({ ...p, mode }));
  const setAccent = (accent: AccentColor) => setTheme((p) => ({ ...p, accent }));
  const setFontSize = (fontSize: FontSize) => setTheme((p) => ({ ...p, fontSize }));
  const setSidebarCompact = (sidebarCompact: boolean) => setTheme((p) => ({ ...p, sidebarCompact }));
  const resetTheme = () => setTheme(DEFAULT);

  return (
    <ThemeContext.Provider value={{ theme, setMode, setAccent, setFontSize, setSidebarCompact, resetTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme must be used inside ThemeProvider");
  return ctx;
}
