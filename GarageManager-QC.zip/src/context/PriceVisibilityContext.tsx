import { createContext, useContext, useState } from "react";

type PriceVisibilityContextType = {
  pricesVisible: boolean;
  togglePrices: () => void;
};

const PriceVisibilityContext = createContext<PriceVisibilityContextType>({
  pricesVisible: true,
  togglePrices: () => {},
});

export function PriceVisibilityProvider({ children }: { children: React.ReactNode }) {
  const [pricesVisible, setPricesVisible] = useState(true);
  const togglePrices = () => setPricesVisible((v) => !v);
  return (
    <PriceVisibilityContext.Provider value={{ pricesVisible, togglePrices }}>
      {children}
    </PriceVisibilityContext.Provider>
  );
}

export function usePriceVisibility() {
  return useContext(PriceVisibilityContext);
}
