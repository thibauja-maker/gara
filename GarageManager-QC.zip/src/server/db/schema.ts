import {
  mysqlTable,
  int,
  varchar,
  text,
  decimal,
  timestamp,
  boolean,
  json,
} from 'drizzle-orm/mysql-core';

// ── Organisations ─────────────────────────────────────────────────────────────
export const organisations = mysqlTable('organisations', {
  id: varchar('id', { length: 36 }).primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  phone: varchar('phone', { length: 50 }),
  email: varchar('email', { length: 255 }),
  address: varchar('address', { length: 500 }),
  city: varchar('city', { length: 100 }),
  postalCode: varchar('postal_code', { length: 20 }),
  province: varchar('province', { length: 50 }),
  taxNumber: varchar('tax_number', { length: 100 }),
  logoUrl: varchar('logo_url', { length: 500 }),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow().onUpdateNow(),
});

// ── Customers ─────────────────────────────────────────────────────────────────
export const customers = mysqlTable('customers', {
  id: varchar('id', { length: 36 }).primaryKey(),
  orgId: varchar('org_id', { length: 36 }).notNull(),
  name: varchar('name', { length: 255 }).notNull(),
  phone: varchar('phone', { length: 50 }),
  email: varchar('email', { length: 255 }),
  address: varchar('address', { length: 500 }),
  city: varchar('city', { length: 100 }),
  postalCode: varchar('postal_code', { length: 20 }),
  vehicleInfo: varchar('vehicle_info', { length: 500 }),
  vehicles: json('vehicles'),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow().onUpdateNow(),
});

// ── Repair Orders ─────────────────────────────────────────────────────────────
export const repairOrders = mysqlTable('repair_orders', {
  id: varchar('id', { length: 36 }).primaryKey(),
  orgId: varchar('org_id', { length: 36 }).notNull(),
  orderNumber: varchar('order_number', { length: 50 }).notNull(),
  customerId: varchar('customer_id', { length: 36 }),
  customerName: varchar('customer_name', { length: 255 }).notNull(),
  vehicleInfo: varchar('vehicle_info', { length: 500 }),
  plate: varchar('plate', { length: 20 }),
  mileage: varchar('mileage', { length: 20 }),
  mechanic: varchar('mechanic', { length: 255 }),
  jobDescription: text('job_description'),
  status: varchar('status', { length: 50 }).notNull().default('En cours'),
  subtotal: decimal('subtotal', { precision: 10, scale: 2 }).notNull().default('0.00'),
  tpsAmount: decimal('tps_amount', { precision: 10, scale: 2 }).notNull().default('0.00'),
  tvqAmount: decimal('tvq_amount', { precision: 10, scale: 2 }).notNull().default('0.00'),
  total: decimal('total', { precision: 10, scale: 2 }).notNull().default('0.00'),
  amountPaid: decimal('amount_paid', { precision: 10, scale: 2 }).notNull().default('0.00'),
  date: varchar('date', { length: 20 }),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow().onUpdateNow(),
});

// ── Repair Order Items ────────────────────────────────────────────────────────
export const repairOrderItems = mysqlTable('repair_order_items', {
  id: varchar('id', { length: 36 }).primaryKey(),
  orgId: varchar('org_id', { length: 36 }).notNull(),
  repairOrderId: varchar('repair_order_id', { length: 36 }).notNull(),
  type: varchar('type', { length: 20 }).notNull().default('part'), // part | labor | supply
  description: varchar('description', { length: 500 }).notNull(),
  partNumber: varchar('part_number', { length: 100 }),
  qty: decimal('qty', { precision: 10, scale: 2 }).default('1.00'),
  unitPrice: decimal('unit_price', { precision: 10, scale: 2 }).default('0.00'),
  hours: decimal('hours', { precision: 10, scale: 2 }),
  rate: decimal('rate', { precision: 10, scale: 2 }),
  amount: decimal('amount', { precision: 10, scale: 2 }).default('0.00'),
  createdAt: timestamp('created_at').defaultNow(),
});

// ── Appointments ──────────────────────────────────────────────────────────────
export const appointments = mysqlTable('appointments', {
  id: varchar('id', { length: 36 }).primaryKey(),
  orgId: varchar('org_id', { length: 36 }).notNull(),
  customerId: varchar('customer_id', { length: 36 }),
  customerName: varchar('customer_name', { length: 255 }).notNull(),
  phone: varchar('phone', { length: 50 }),
  vehicleInfo: varchar('vehicle_info', { length: 500 }),
  service: varchar('service', { length: 255 }),
  date: varchar('date', { length: 20 }).notNull(),
  time: varchar('time', { length: 10 }),
  duration: int('duration').default(60),
  mechanic: varchar('mechanic', { length: 255 }),
  status: varchar('status', { length: 50 }).notNull().default('Confirmé'),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow().onUpdateNow(),
});

// ── Inventory Items ───────────────────────────────────────────────────────────
export const inventoryItems = mysqlTable('inventory_items', {
  id: varchar('id', { length: 36 }).primaryKey(),
  orgId: varchar('org_id', { length: 36 }).notNull(),
  name: varchar('name', { length: 255 }).notNull(),
  partNumber: varchar('part_number', { length: 100 }),
  category: varchar('category', { length: 100 }),
  brand: varchar('brand', { length: 100 }),
  unit: varchar('unit', { length: 50 }),
  price: decimal('price', { precision: 10, scale: 2 }).default('0.00'),
  unitCost: decimal('unit_cost', { precision: 10, scale: 2 }).notNull().default('0.00'),
  unitPrice: decimal('unit_price', { precision: 10, scale: 2 }).notNull().default('0.00'),
  qty: int('qty').notNull().default(0),
  minQty: int('min_qty').default(0),
  supplier: varchar('supplier', { length: 255 }),
  location: varchar('location', { length: 100 }),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow().onUpdateNow(),
});

// ── Suppliers ─────────────────────────────────────────────────────────────────
export const suppliers = mysqlTable('suppliers', {
  id: varchar('id', { length: 36 }).primaryKey(),
  orgId: varchar('org_id', { length: 36 }).notNull(),
  name: varchar('name', { length: 255 }).notNull(),
  companyName: varchar('company_name', { length: 255 }).notNull(),
  contactName: varchar('contact_name', { length: 255 }),
  phone: varchar('phone', { length: 50 }),
  email: varchar('email', { length: 255 }),
  address: varchar('address', { length: 500 }),
  city: varchar('city', { length: 100 }),
  postalCode: varchar('postal_code', { length: 20 }),
  website: varchar('website', { length: 500 }),
  accountNumber: varchar('account_number', { length: 100 }),
  cardImageUrl: varchar('card_image_url', { length: 500 }),
  tags: varchar('tags', { length: 500 }),
  category: varchar('category', { length: 100 }),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow().onUpdateNow(),
});

// ── Workstation Users ─────────────────────────────────────────────────────────
export const workstationUsers = mysqlTable('workstation_users', {
  id: varchar('id', { length: 36 }).primaryKey(),
  orgId: varchar('org_id', { length: 36 }).notNull(),
  username: varchar('username', { length: 100 }).notNull(),
  displayName: varchar('display_name', { length: 255 }).notNull(),
  role: varchar('role', { length: 50 }).notNull().default('technician'),
  pin: varchar('pin', { length: 255 }),
  color: varchar('color', { length: 50 }),
  isActive: boolean('is_active').notNull().default(true),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow().onUpdateNow(),
});
