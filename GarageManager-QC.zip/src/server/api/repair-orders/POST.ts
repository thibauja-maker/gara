import type { Request, Response } from 'express';
import { db } from '../../db/client.js';
import { repairOrders } from '../../db/schema.js';
import { eq } from 'drizzle-orm';
import { randomUUID } from 'crypto';

export default async function handler(req: Request, res: Response) {
  try {
    const data = req.body;
    if (!data.orgId || !data.orderNumber || !data.customerName) {
      return res.status(400).json({ error: 'Champs requis manquants' });
    }
    const id = randomUUID();
    await db.insert(repairOrders).values({ id, ...data });
    const [row] = await db.select().from(repairOrders).where(eq(repairOrders.id, id));
    res.status(201).json(row);
  } catch (error) {
    res.status(500).json({ error: 'Erreur serveur', message: String(error) });
  }
}
