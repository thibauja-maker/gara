import type { Request, Response } from 'express';
import { db } from '../../../db/client.js';
import { repairOrders } from '../../../db/schema.js';
import { eq } from 'drizzle-orm';

export default async function handler(req: Request, res: Response) {
  try {
    const id = String(req.params.id);
    const { id: _id, orgId: _orgId, ...data } = req.body as Record<string, string>;
    await db.update(repairOrders).set(data).where(eq(repairOrders.id, id));
    const [row] = await db.select().from(repairOrders).where(eq(repairOrders.id, id));
    res.json(row);
  } catch (error) {
    res.status(500).json({ error: 'Erreur serveur', message: String(error) });
  }
}
