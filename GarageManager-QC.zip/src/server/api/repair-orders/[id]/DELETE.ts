import type { Request, Response } from 'express';
import { db } from '../../../db/client.js';
import { repairOrders } from '../../../db/schema.js';
import { eq } from 'drizzle-orm';

export default async function handler(req: Request, res: Response) {
  try {
    const id = String(req.params.id);
    await db.delete(repairOrders).where(eq(repairOrders.id, id));
    res.json({ ok: true });
  } catch (error) {
    res.status(500).json({ error: 'Erreur serveur', message: String(error) });
  }
}
