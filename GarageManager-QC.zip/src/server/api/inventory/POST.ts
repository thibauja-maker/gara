import type { Request, Response } from 'express';
import { db } from '../../db/client.js';
import { inventoryItems } from '../../db/schema.js';
import { eq } from 'drizzle-orm';
import { randomUUID } from 'crypto';

export default async function handler(req: Request, res: Response) {
  try {
    const data = req.body;
    if (!data.orgId || !data.name) return res.status(400).json({ error: 'orgId et name requis' });
    const id = randomUUID();
    await db.insert(inventoryItems).values({ id, ...data });
    const [row] = await db.select().from(inventoryItems).where(eq(inventoryItems.id, id));
    res.status(201).json(row);
  } catch (error) {
    res.status(500).json({ error: 'Erreur serveur', message: String(error) });
  }
}
