import type { Request, Response } from 'express';
import { db } from '../../db/client.js';
import { appointments } from '../../db/schema.js';
import { eq } from 'drizzle-orm';

export default async function handler(req: Request, res: Response) {
  try {
    const { orgId } = req.query;
    if (!orgId) return res.status(400).json({ error: 'orgId requis' });
    const rows = await db.select().from(appointments).where(eq(appointments.orgId, String(orgId)));
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: 'Erreur serveur', message: String(error) });
  }
}
