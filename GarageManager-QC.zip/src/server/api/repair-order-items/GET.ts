import type { Request, Response } from 'express';
import { db } from '../../db/client.js';
import { repairOrderItems } from '../../db/schema.js';
import { eq } from 'drizzle-orm';

export default async function handler(req: Request, res: Response) {
  try {
    const { repairOrderId } = req.query;
    if (!repairOrderId) return res.status(400).json({ error: 'repairOrderId requis' });
    const rows = await db.select().from(repairOrderItems).where(eq(repairOrderItems.repairOrderId, String(repairOrderId)));
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: 'Erreur serveur', message: String(error) });
  }
}
