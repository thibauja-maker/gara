import type { Request, Response } from 'express';
import { db } from '../../db/client.js';
import { suppliers } from '../../db/schema.js';
import { eq } from 'drizzle-orm';
import { randomUUID } from 'crypto';

export default async function handler(req: Request, res: Response) {
  try {
    const data = req.body;
    if (!data.orgId || !data.companyName) return res.status(400).json({ error: 'orgId et companyName requis' });
    const id = randomUUID();
    await db.insert(suppliers).values({ id, name: data.companyName, ...data });
    const [row] = await db.select().from(suppliers).where(eq(suppliers.id, id));
    res.status(201).json(row);
  } catch (error) {
    res.status(500).json({ error: 'Erreur serveur', message: String(error) });
  }
}
