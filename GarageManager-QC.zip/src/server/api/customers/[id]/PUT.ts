import type { Request, Response } from 'express';
import { db } from '../../../db/client.js';
import { customers } from '../../../db/schema.js';
import { eq } from 'drizzle-orm';

export default async function handler(req: Request, res: Response) {
  try {
    const id = String(req.params.id);
    const { name, phone, email, address, city, postalCode, vehicleInfo, notes } = req.body as {
      name?: string; phone?: string; email?: string; address?: string;
      city?: string; postalCode?: string; vehicleInfo?: string; notes?: string;
    };
    await db.update(customers).set({ name, phone, email, address, city, postalCode, vehicleInfo, notes }).where(eq(customers.id, id));
    const [row] = await db.select().from(customers).where(eq(customers.id, id));
    res.json(row);
  } catch (error) {
    res.status(500).json({ error: 'Erreur serveur', message: String(error) });
  }
}
