import type { Request, Response } from 'express';
import { db } from '../../db/client.js';
import { customers } from '../../db/schema.js';
import { eq } from 'drizzle-orm';
import { randomUUID } from 'crypto';

export default async function handler(req: Request, res: Response) {
  try {
    const { orgId, name, phone, email, address, city, postalCode, vehicleInfo, vehicles, notes } = req.body;
    if (!orgId || !name) return res.status(400).json({ error: 'orgId et name requis' });
    const id = randomUUID();
    await db.insert(customers).values({ id, orgId, name, phone, email, address, city, postalCode, vehicleInfo, vehicles, notes });
    const [row] = await db.select().from(customers).where(eq(customers.id, id));
    res.status(201).json(row);
  } catch (error) {
    res.status(500).json({ error: 'Erreur serveur', message: String(error) });
  }
}
