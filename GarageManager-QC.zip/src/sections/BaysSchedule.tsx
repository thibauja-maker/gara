import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Wrench,
  Car,
  User,
  Clock,
  CalendarBlank,
  ArrowsLeftRight,
  Warning,
  Receipt,
  CheckCircle,
  Circle,
  Hourglass,
  MapPin,
  PencilSimple,
  Trash,
  X,
  FloppyDisk,
  DotsThreeVertical,
} from "@phosphor-icons/react";

const STAFF = {
  marc: { name: "Marc Tremblay", role: "Technicien", initials: "MT" },
  julie: { name: "Julie Côté", role: "Technicien", initials: "JC" },
  pierre: { name: "Pierre Gagnon", role: "Gestionnaire", initials: "PG" },
};

const TAX_RATES = { gst: 0.05, qst: 0.09975 };

type Job = {
  id: string;
  customer: string;
  vehicle: string;
  service: string;
  serviceEn: string;
  start: string;
  end: string;
  duration: number;
  status: string;
  mechanic: string;
  labor: number;
  parts: number;
  notes: string;
  conflict?: boolean;
  managerNote?: string;
};

const INITIAL_BAY_JOBS: { bay: number; jobs: Job[] }[] = [
  {
    bay: 1,
    jobs: [
      {
        id: "WO-2401",
        customer: "Alain Bouchard",
        vehicle: "2019 Honda Civic",
        service: "Vidange d'huile & filtre",
        serviceEn: "Oil Change & Filter",
        start: "08:00",
        end: "09:30",
        duration: 1.5,
        status: "completed",
        mechanic: "marc",
        labor: 85,
        parts: 42.5,
        notes: "Huile synthétique 5W-30",
      },
      {
        id: "WO-2402",
        customer: "Sylvie Lapointe",
        vehicle: "2021 Toyota RAV4",
        service: "Freins avant — remplacement",
        serviceEn: "Front Brake Replacement",
        start: "10:00",
        end: "12:30",
        duration: 2.5,
        status: "in-progress",
        mechanic: "marc",
        labor: 175,
        parts: 210,
        notes: "Plaquettes et disques avant",
      },
      {
        id: "WO-2403",
        customer: "François Bergeron",
        vehicle: "2017 Ford F-150",
        service: "Inspection pré-hivernale",
        serviceEn: "Pre-Winter Inspection",
        start: "13:30",
        end: "15:00",
        duration: 1.5,
        status: "scheduled",
        mechanic: "marc",
        labor: 95,
        parts: 0,
        notes: "Vérification complète 30 points",
      },
    ],
  },
  {
    bay: 2,
    jobs: [
      {
        id: "WO-2404",
        customer: "Martine Ouellet",
        vehicle: "2020 Subaru Outback",
        service: "Pneus — changement saisonnier",
        serviceEn: "Seasonal Tire Swap",
        start: "08:30",
        end: "10:00",
        duration: 1.5,
        status: "completed",
        mechanic: "julie",
        labor: 80,
        parts: 0,
        notes: "Entreposage inclus",
      },
      {
        id: "WO-2405",
        customer: "Robert Simard",
        vehicle: "2018 Mazda CX-5",
        service: "Diagnostic électronique",
        serviceEn: "Electronic Diagnostic",
        start: "10:30",
        end: "12:00",
        duration: 1.5,
        status: "in-progress",
        mechanic: "julie",
        labor: 120,
        parts: 0,
        notes: "Témoin moteur allumé — code P0420",
        conflict: true,
      },
      {
        id: "WO-2406",
        customer: "Nathalie Côté",
        vehicle: "2022 Hyundai Tucson",
        service: "Courroie de distribution",
        serviceEn: "Timing Belt",
        start: "13:00",
        end: "16:30",
        duration: 3.5,
        status: "scheduled",
        mechanic: "julie",
        labor: 320,
        parts: 185,
        notes: "Kit complet avec pompe à eau",
        managerNote: "Approuver devis avant début",
      },
    ],
  },
];

const TIME_SLOTS = ["08:00","09:00","10:00","11:00","12:00","13:00","14:00","15:00","16:00","17:00"];
const DAY_START = 8;
const DAY_HOURS = 9;

function timeToPercent(time: string) {
  const [h, m] = time.split(":").map(Number);
  return ((h - DAY_START + m / 60) / DAY_HOURS) * 100;
}

function calcTaxes(labor: number, parts: number) {
  const subtotal = labor + parts;
  const gst = subtotal * TAX_RATES.gst;
  const qst = subtotal * TAX_RATES.qst;
  return { subtotal, gst, qst, total: subtotal + gst + qst };
}

function fmt(n: number) {
  return n.toLocaleString("fr-CA", { style: "currency", currency: "CAD" });
}

const statusConfig: Record<string, { label: string; color: string; icon: React.ElementType }> = {
  completed:   { label: "Terminé",  color: "bg-muted text-muted-foreground",        icon: CheckCircle },
  "in-progress":{ label: "En cours", color: "bg-primary text-primary-foreground",    icon: Hourglass  },
  scheduled:   { label: "Planifié", color: "bg-accent text-accent-foreground",       icon: Circle     },
};

const blockColor: Record<string, string> = {
  completed:    "bg-muted border-border",
  "in-progress":"bg-primary/10 border-primary",
  scheduled:    "bg-accent/30 border-accent",
};

// ── Edit Job Modal ──────────────────────────────────────────────────────────
function EditJobModal({ job, onSave, onClose }: {
  job: Job;
  onSave: (updated: Job) => void;
  onClose: () => void;
}) {
  const [form, setForm] = useState({ ...job });
  const set = (k: keyof Job, v: string | number) => setForm(f => ({ ...f, [k]: v }));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm" onClick={onClose}>
      <div
        className="bg-card border border-border rounded-2xl shadow-2xl w-full max-w-md mx-4 max-h-[90vh] overflow-y-auto animate-slide-in"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-5 py-4 border-b border-border">
          <h3 className="font-heading text-base font-semibold text-foreground">Modifier l&#39;ordre — {job.id}</h3>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors">
            <X size={18} />
          </button>
        </div>
        <div className="px-5 py-4 space-y-3">
          {([
            ["client",  "customer", "text"],
            ["véhicule","vehicle",  "text"],
            ["service", "service",  "text"],
            ["début",   "start",    "text"],
            ["fin",     "end",      "text"],
          ] as [string, keyof Job, string][]).map(([lbl, key, type]) => (
            <div key={key}>
              <Label className="text-xs text-muted-foreground capitalize mb-1 block">{lbl}</Label>
              <Input
                type={type}
                value={String(form[key] ?? "")}
                onChange={e => set(key, e.target.value)}
                className="h-8 text-sm"
              />
            </div>
          ))}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs text-muted-foreground mb-1 block">Main-d&#39;œuvre ($)</Label>
              <Input type="number" value={form.labor} onChange={e => set("labor", parseFloat(e.target.value) || 0)} className="h-8 text-sm" />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground mb-1 block">Pièces ($)</Label>
              <Input type="number" value={form.parts} onChange={e => set("parts", parseFloat(e.target.value) || 0)} className="h-8 text-sm" />
            </div>
          </div>
          <div>
            <Label className="text-xs text-muted-foreground mb-1 block">Statut</Label>
            <select
              value={form.status}
              onChange={e => set("status", e.target.value)}
              className="w-full h-8 text-sm rounded-md border border-border bg-background px-2 text-foreground"
            >
              <option value="scheduled">Planifié</option>
              <option value="in-progress">En cours</option>
              <option value="completed">Terminé</option>
            </select>
          </div>
          <div>
            <Label className="text-xs text-muted-foreground mb-1 block">Note technique</Label>
            <Input value={form.notes} onChange={e => set("notes", e.target.value)} className="h-8 text-sm" />
          </div>
        </div>
        <div className="flex gap-2 px-5 pb-5">
          <Button variant="outline" size="sm" className="flex-1 text-xs rounded-lg" onClick={onClose}>Annuler</Button>
          <Button size="sm" className="flex-1 text-xs rounded-lg bg-primary text-primary-foreground hover:opacity-90" onClick={() => onSave(form)}>
            <FloppyDisk weight="duotone" size={13} className="mr-1.5" />Sauvegarder
          </Button>
        </div>
      </div>
    </div>
  );
}

// ── Delete Confirm Modal ────────────────────────────────────────────────────
function DeleteConfirmModal({ job, onConfirm, onClose }: {
  job: Job;
  onConfirm: () => void;
  onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm" onClick={onClose}>
      <div
        className="bg-card border border-border rounded-2xl shadow-2xl w-full max-w-sm mx-4 animate-slide-in"
        onClick={e => e.stopPropagation()}
      >
        <div className="px-5 py-5 text-center space-y-3">
          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
            <Trash weight="duotone" size={22} className="text-primary" />
          </div>
          <h3 className="font-heading text-base font-semibold text-foreground">Supprimer l&#39;ordre ?</h3>
          <p className="text-sm text-muted-foreground">
            <span className="font-semibold text-foreground">{job.id}</span> — {job.customer} · {job.vehicle}
          </p>
          <p className="text-xs text-muted-foreground">Cette action est irréversible.</p>
        </div>
        <div className="flex gap-2 px-5 pb-5">
          <Button variant="outline" size="sm" className="flex-1 text-xs rounded-lg" onClick={onClose}>Annuler</Button>
          <Button size="sm" className="flex-1 text-xs rounded-lg bg-primary text-primary-foreground hover:opacity-90" onClick={onConfirm}>
            Supprimer
          </Button>
        </div>
      </div>
    </div>
  );
}

// ── Main Component ──────────────────────────────────────────────────────────
export default function BaysSchedule() {
  const [bayJobs, setBayJobs] = useState(INITIAL_BAY_JOBS);
  const [selectedJob, setSelectedJob] = useState<Job | null>(INITIAL_BAY_JOBS[0].jobs[1]);
  const [moveMode, setMoveMode] = useState(false);
  const [editJob, setEditJob] = useState<Job | null>(null);
  const [deleteJob, setDeleteJob] = useState<Job | null>(null);
  // Slide state: which job id has options visible
  const [slideOpen, setSlideOpen] = useState<string | null>(null);

  const taxes = selectedJob ? calcTaxes(selectedJob.labor, selectedJob.parts) : null;
  const StatusIcon = selectedJob ? statusConfig[selectedJob.status].icon : null;
  const mechanic = selectedJob ? STAFF[selectedJob.mechanic as keyof typeof STAFF] : null;

  function handleSaveEdit(updated: Job) {
    setBayJobs(prev =>
      prev.map(b => ({ ...b, jobs: b.jobs.map(j => j.id === updated.id ? updated : j) }))
    );
    if (selectedJob?.id === updated.id) setSelectedJob(updated);
    setEditJob(null);
  }

  function handleDelete(jobId: string) {
    setBayJobs(prev =>
      prev.map(b => ({ ...b, jobs: b.jobs.filter(j => j.id !== jobId) }))
    );
    if (selectedJob?.id === jobId) setSelectedJob(null);
    setDeleteJob(null);
    setSlideOpen(null);
  }

  function toggleSlide(jobId: string) {
    setSlideOpen(prev => prev === jobId ? null : jobId);
  }

  return (
    <section id="bays-schedule" className="bg-background min-h-screen py-10 px-4 md:px-8">

      {/* Modals */}
      {editJob && (
        <EditJobModal
          job={editJob}
          onSave={handleSaveEdit}
          onClose={() => setEditJob(null)}
        />
      )}
      {deleteJob && (
        <DeleteConfirmModal
          job={deleteJob}
          onConfirm={() => handleDelete(deleteJob.id)}
          onClose={() => setDeleteJob(null)}
        />
      )}

      {/* Section Header */}
      <div className="max-w-7xl mx-auto mb-6">
        <div className="flex items-center gap-3 mb-1">
          <CalendarBlank weight="duotone" size={22} className="text-primary" />
          <h2 className="font-heading text-2xl font-semibold text-foreground tracking-tight">
            Lift Schedule
          </h2>
          <Badge className="ml-2 bg-muted text-muted-foreground text-xs font-normal rounded-full px-2 py-0.5">
            Aujourd&#39;hui — Lundi 18 nov. 2024
          </Badge>
        </div>
        <p className="text-sm text-muted-foreground ml-9">
          2 lifts · 2 techniciens · supervision gestionnaire
        </p>
      </div>

      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row gap-6">

        {/* LEFT PANE — Bay Timeline */}
        <div className="flex-1 min-w-0 space-y-5">
          {bayJobs.map((bay) => (
            <Card key={bay.bay} className="rounded-xl shadow-sm border border-border bg-card overflow-hidden">

              {/* Bay Header */}
              <CardHeader className="py-3 px-5 border-b border-border bg-card">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <MapPin weight="duotone" size={16} className="text-primary" />
                    <CardTitle className="font-heading text-base font-semibold text-foreground">
                      Lift {bay.bay}
                    </CardTitle>
                    <Separator orientation="vertical" className="h-4 mx-1" />
                    <span className="text-xs text-muted-foreground">
                      {STAFF[bay.jobs[0]?.mechanic as keyof typeof STAFF]?.name ?? "—"}
                    </span>
                  </div>
                  <div className="flex gap-1.5">
                    {bay.jobs.map((j) => (
                      <div
                        key={j.id}
                        className={`w-2 h-2 rounded-full ${
                          j.status === "completed" ? "bg-muted-foreground"
                          : j.status === "in-progress" ? "bg-primary"
                          : "bg-accent"
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </CardHeader>

              <CardContent className="px-5 pt-4 pb-5">
                {/* Time ruler */}
                <div className="relative mb-2">
                  <div className="flex justify-between">
                    {TIME_SLOTS.map((t) => (
                      <span key={t} className="text-[10px] text-muted-foreground w-0 text-center">{t}</span>
                    ))}
                  </div>
                </div>

                {/* Timeline bar */}
                <div className="relative h-14 bg-muted/40 rounded-lg border border-border overflow-hidden mb-4">
                  {TIME_SLOTS.slice(1, -1).map((_, i) => (
                    <div
                      key={i}
                      className="absolute top-0 bottom-0 w-px bg-border/60"
                      style={{ left: `${((i + 1) / (TIME_SLOTS.length - 1)) * 100}%` }}
                    />
                  ))}
                  {bay.jobs.map((job) => {
                    const left = timeToPercent(job.start);
                    const width = (job.duration / DAY_HOURS) * 100;
                    const isSelected = selectedJob?.id === job.id;
                    return (
                      <button
                        key={job.id}
                        onClick={() => { setSelectedJob(job); setSlideOpen(null); }}
                        className={`absolute top-1.5 bottom-1.5 rounded-md border-2 px-2 flex flex-col justify-center cursor-pointer transition-all duration-150
                          ${blockColor[job.status]}
                          ${isSelected ? "ring-2 ring-primary ring-offset-1 shadow-md -translate-y-0.5" : "hover:-translate-y-0.5 hover:shadow-md hover:border-primary/60"}
                          ${job.conflict ? "border-dashed" : ""}
                        `}
                        style={{ left: `${left}%`, width: `${width}%` }}
                      >
                        <span className="text-[10px] font-semibold text-foreground truncate leading-tight">
                          {job.vehicle.split(" ").slice(1).join(" ")}
                        </span>
                        <span className="text-[9px] text-muted-foreground truncate leading-tight">
                          {job.start}–{job.end}
                        </span>
                        {job.conflict && (
                          <Warning weight="duotone" size={10} className="text-primary absolute top-1 right-1" />
                        )}
                      </button>
                    );
                  })}
                </div>

                {/* Job list rows */}
                <div className="space-y-1">
                  {bay.jobs.map((job, idx) => {
                    const cfg = statusConfig[job.status];
                    const Icon = cfg.icon;
                    const isSelected = selectedJob?.id === job.id;
                    const isMenuOpen = slideOpen === job.id;

                    return (
                      <div key={job.id}>
                        <div
                          onClick={() => setSelectedJob(job)}
                          className={`relative flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer transition-all duration-150
                            ${isSelected ? "bg-primary/10 ring-1 ring-primary shadow-sm" : "hover:bg-muted/60 hover:shadow-sm hover:ring-1 hover:ring-border"}
                          `}
                        >
                          <Icon
                            weight="duotone"
                            size={15}
                            className={isSelected ? "text-primary" : "text-muted-foreground"}
                          />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-xs font-semibold text-foreground">{job.id}</span>
                              <span className="text-xs text-muted-foreground truncate">{job.vehicle}</span>
                              {job.conflict && (
                                <Badge className="text-[9px] px-1.5 py-0 bg-primary/10 text-primary rounded-full">Conflit</Badge>
                              )}
                            </div>
                            <div className="flex items-center gap-2 mt-0.5">
                              <span className="text-[11px] text-muted-foreground truncate">{job.service}</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-2 shrink-0">
                            <span className="text-[10px] text-muted-foreground">{job.start}–{job.end}</span>
                            <Badge className={`text-[9px] px-2 py-0.5 rounded-full ${cfg.color}`}>{cfg.label}</Badge>

                            {/* ⋮ Menu trigger */}
                            <div className="relative">
                              <button
                                onClick={e => { e.stopPropagation(); toggleSlide(job.id); }}
                                className={`p-1 rounded transition-colors ${isMenuOpen ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground hover:bg-muted"}`}
                                title="Actions"
                              >
                                <DotsThreeVertical weight="bold" size={14} />
                              </button>

                              {/* Dropdown popover */}
                              {isMenuOpen && (
                                <>
                                  {/* invisible backdrop to close on outside click */}
                                  <div
                                    className="fixed inset-0 z-20"
                                    onClick={e => { e.stopPropagation(); setSlideOpen(null); }}
                                  />
                                  <div className="absolute right-0 top-full mt-1 z-30 bg-card border border-border rounded-xl shadow-lg overflow-hidden min-w-[130px]">
                                    <button
                                      onClick={e => { e.stopPropagation(); setEditJob(job); setSlideOpen(null); }}
                                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-foreground hover:bg-muted transition-colors"
                                    >
                                      <PencilSimple weight="duotone" size={13} className="text-blue-500" />
                                      Modifier
                                    </button>
                                    <div className="border-t border-border/60" />
                                    <button
                                      onClick={e => { e.stopPropagation(); setDeleteJob(job); setSlideOpen(null); }}
                                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors"
                                    >
                                      <Trash weight="duotone" size={13} />
                                      Supprimer
                                    </button>
                                  </div>
                                </>
                              )}
                            </div>
                          </div>
                        </div>

                        {idx < bay.jobs.length - 1 && (
                          <div className="ml-3 border-b border-border/50" />
                        )}
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          ))}

        </div>

        {/* RIGHT PANE — Job Detail */}
        <div className="w-full lg:w-80 xl:w-96 shrink-0">
          {selectedJob && taxes && mechanic && StatusIcon ? (
            <Card className="rounded-xl shadow-sm border border-border bg-card sticky top-6">
              {/* Detail header */}
              <CardHeader className="px-5 py-4 border-b border-border">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-medium mb-0.5">Ordre de travail</p>
                    <CardTitle className="font-heading text-lg font-semibold text-foreground">{selectedJob.id}</CardTitle>
                  </div>
                  <div className="flex items-center gap-1.5 mt-1">
                    <button
                      onClick={() => setEditJob(selectedJob)}
                      className="p-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-600 transition-colors"
                      title="Modifier"
                    >
                      <PencilSimple weight="duotone" size={14} />
                    </button>
                    <button
                      onClick={() => setDeleteJob(selectedJob)}
                      className="p-1.5 rounded-lg bg-primary/10 hover:bg-primary/20 text-primary transition-colors"
                      title="Supprimer"
                    >
                      <Trash weight="duotone" size={14} />
                    </button>
                    <Badge className={`text-xs px-2.5 py-1 rounded-full ${statusConfig[selectedJob.status].color}`}>
                      <StatusIcon weight="duotone" size={11} className="mr-1 inline" />
                      {statusConfig[selectedJob.status].label}
                    </Badge>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="px-5 py-4 space-y-4">
                {/* Vehicle & Customer */}
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Car weight="duotone" size={15} className="text-primary shrink-0" />
                    <div>
                      <p className="text-xs font-semibold text-foreground">{selectedJob.vehicle}</p>
                      <p className="text-[11px] text-muted-foreground">{selectedJob.customer}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Wrench weight="duotone" size={15} className="text-primary shrink-0" />
                    <p className="text-xs text-foreground">{selectedJob.service}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock weight="duotone" size={15} className="text-primary shrink-0" />
                    <p className="text-xs text-muted-foreground">
                      {selectedJob.start} – {selectedJob.end} &nbsp;·&nbsp; {selectedJob.duration}h
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <User weight="duotone" size={15} className="text-primary shrink-0" />
                    <div>
                      <p className="text-[10px] text-muted-foreground uppercase tracking-wide font-semibold">Travail exécuté par</p>
                      <p className="text-xs text-foreground">{mechanic.name}</p>
                    </div>
                  </div>
                </div>

                {/* Notes */}
                {(selectedJob.notes || selectedJob.managerNote) && (
                  <>
                    <Separator />
                    <div className="space-y-1.5">
                      {selectedJob.notes && (
                        <div className="bg-muted/50 rounded-lg px-3 py-2 border border-border">
                          <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-medium mb-0.5">Note technique</p>
                          <p className="text-xs text-foreground">{selectedJob.notes}</p>
                        </div>
                      )}
                      {selectedJob.managerNote && (
                        <div className="bg-primary/5 rounded-lg px-3 py-2 border border-primary/20">
                          <p className="text-[10px] uppercase tracking-widest text-primary font-medium mb-0.5">Note gestionnaire</p>
                          <p className="text-xs text-foreground">{selectedJob.managerNote}</p>
                        </div>
                      )}
                    </div>
                  </>
                )}

                {/* Conflict warning */}
                {selectedJob.conflict && (
                  <div className="flex items-start gap-2 bg-primary/5 border border-primary/20 rounded-lg px-3 py-2">
                    <Warning weight="duotone" size={15} className="text-primary mt-0.5 shrink-0" />
                    <p className="text-xs text-foreground">
                      Chevauchement détecté avec un autre travail. Vérifier la disponibilité du lift.
                    </p>
                  </div>
                )}

                {/* Reschedule */}
                <Separator />
                <div>
                  <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-medium mb-2">Reprogrammer</p>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className={`flex-1 text-xs rounded-lg border-border transition-all duration-150 ${moveMode ? "bg-primary text-primary-foreground border-primary" : "hover:bg-muted"}`}
                      onClick={() => setMoveMode(!moveMode)}
                    >
                      <ArrowsLeftRight weight="duotone" size={13} className="mr-1.5" />
                      {moveMode ? "Annuler déplacement" : "Déplacer"}
                    </Button>
                    <Button size="sm" className="flex-1 text-xs rounded-lg bg-primary text-primary-foreground hover:opacity-90 transition-opacity">
                      Confirmer
                    </Button>
                  </div>
                  {moveMode && (
                    <div className="mt-2 border-2 border-dashed border-primary/40 rounded-lg px-3 py-3 text-center bg-primary/5">
                      <p className="text-xs text-primary font-medium">Sélectionner un créneau cible</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">Cliquer sur un bloc libre dans le calendrier</p>
                    </div>
                  )}
                </div>

                {/* Invoice preview */}
                <Separator />
                <div>
                  <div className="flex items-center gap-1.5 mb-3">
                    <Receipt weight="duotone" size={14} className="text-primary" />
                    <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-medium">Aperçu facture — Québec</p>
                  </div>
                  <div className="space-y-1.5 text-xs">
                    <div className="flex justify-between text-muted-foreground">
                      <span>Main-d&#39;œuvre</span>
                      <span className="font-medium text-foreground">{fmt(selectedJob.labor)}</span>
                    </div>
                    {selectedJob.parts > 0 && (
                      <div className="flex justify-between text-muted-foreground">
                        <span>Pièces</span>
                        <span className="font-medium text-foreground">{fmt(selectedJob.parts)}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-muted-foreground border-t border-border pt-1.5 mt-1">
                      <span>Sous-total</span>
                      <span className="font-medium text-foreground">{fmt(taxes.subtotal)}</span>
                    </div>
                    <div className="flex justify-between text-muted-foreground">
                      <span>TPS (5 %)</span>
                      <span>{fmt(taxes.gst)}</span>
                    </div>
                    <div className="flex justify-between text-muted-foreground">
                      <span>TVQ (9,975 %)</span>
                      <span>{fmt(taxes.qst)}</span>
                    </div>
                    <div className="flex justify-between font-semibold text-foreground border-t border-border pt-2 mt-1">
                      <span>Total</span>
                      <span className="text-primary">{fmt(taxes.total)}</span>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" className="w-full mt-3 text-xs rounded-lg border-border hover:bg-muted transition-colors">
                    Voir la facture complète
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card className="rounded-xl shadow-sm border border-border bg-card">
              <CardContent className="px-5 py-12 text-center">
                <CalendarBlank weight="duotone" size={32} className="text-muted-foreground mx-auto mb-3" />
                <p className="text-sm text-muted-foreground">Sélectionner un travail pour voir les détails</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </section>
  );
}
