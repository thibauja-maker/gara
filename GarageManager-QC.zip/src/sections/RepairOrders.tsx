import { useState, useCallback } from "react";
import { useQuery, useMutation } from "@animaapp/playground-react-sdk";
import type { Customer } from "@/lib/anima-sdk-stub";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import {
  MagnifyingGlass,
  CaretUpDown,
  CaretUp,
  CaretDown,
  X,
  Wrench,
  Car,
  Clock,
  Receipt,
  Package,
  Note,
  Garage,
  CheckCircle,
  HourglassMedium,
  CalendarBlank,
  ArrowRight,
  CurrencyDollar,
  UserCircle,
  Plus,
  Trash,
  User,
  FloppyDisk,
  Warning,
  PencilSimple,
} from "@phosphor-icons/react";
import { ContextMenu, type ContextMenuItem } from "@/components/ui/context-menu-portal";

// ─── Static sample data (display only — real orders come from DB) ────────────
const sampleOrders = [
  {
    id: "RO-2024-0041",
    customer: "Martin Tremblay",
    vehicle: "2019 Honda Civic",
    plate: "ABC-1234",
    bay: "Lift 1",
    technicien: "Luc Gagnon",
    status: "En cours",
    promised: "2024-01-15 17:00",
    complaint:
      "Bruit de craquement à l'avant lors des virages. Client mentionne que le problème empire par temps froid.",
    parts: [
      { name: "Rotule de direction (G)", partNo: "MO-55046", qty: 1, unitPrice: 89.95 },
      { name: "Rotule de direction (D)", partNo: "MO-55047", qty: 1, unitPrice: 89.95 },
      { name: "Graisse de montage",       partNo: "LU-0012",  qty: 1, unitPrice: 12.5  },
    ],
    labor: [
      { description: "Diagnostic suspension avant",   hours: 0.5, rate: 120.0 },
      { description: "Remplacement rotules (x2)",     hours: 2.5, rate: 120.0 },
      { description: "Alignement des roues",          hours: 0.5, rate: 120.0 },
    ],
    notes: "Vérifier aussi l'état des soufflets de direction.",
  },
  {
    id: "RO-2024-0042",
    customer: "Sophie Bouchard",
    vehicle: "2021 Toyota RAV4",
    plate: "XYZ-5678",
    bay: "Lift 2",
    technicien: "Pierre Lavoie",
    status: "En attente",
    promised: "2024-01-15 15:30",
    complaint: "Voyant moteur allumé. Perte de puissance occasionnelle à haute vitesse.",
    parts: [
      { name: "Bougie d'allumage NGK (x4)", partNo: "NG-4469", qty: 4, unitPrice: 18.75 },
      { name: "Filtre à air moteur",         partNo: "FA-2201", qty: 1, unitPrice: 24.99 },
    ],
    labor: [
      { description: "Lecture des codes défauts", hours: 0.5, rate: 120.0 },
      { description: "Remplacement bougies",      hours: 1.0, rate: 120.0 },
    ],
    notes: "Code P0301 — raté d'allumage cylindre 1. Vérifier bobine d'allumage.",
  },
  {
    id: "RO-2024-0043",
    customer: "Jean-François Côté",
    vehicle: "2017 Ford F-150",
    plate: "LMN-9012",
    bay: "—",
    technicien: "",
    status: "Planifié",
    promised: "2024-01-16 09:00",
    complaint: "Changement d'huile et inspection 12 mois. Vérification des freins demandée.",
    parts: [
      { name: "Huile moteur 5W-30 (5L)",    partNo: "HU-5W30-5", qty: 1, unitPrice: 42.0  },
      { name: "Filtre à huile",              partNo: "FH-3614",   qty: 1, unitPrice: 14.5  },
      { name: "Plaquettes de frein avant",  partNo: "FR-8821",   qty: 1, unitPrice: 68.0  },
    ],
    labor: [
      { description: "Vidange et filtre huile",          hours: 0.5, rate: 120.0 },
      { description: "Inspection 12 mois",               hours: 1.0, rate: 120.0 },
      { description: "Remplacement plaquettes avant",   hours: 1.5, rate: 120.0 },
    ],
    notes: "Client demande rapport d'inspection complet par courriel.",
  },
  {
    id: "RO-2024-0040",
    customer: "Isabelle Roy",
    vehicle: "2020 Mazda CX-5",
    plate: "DEF-3456",
    bay: "Lift 1",
    technicien: "Pierre Lavoie",
    status: "Terminé",
    promised: "2024-01-14 16:00",
    complaint: "Climatisation ne refroidit plus. Compresseur bruyant.",
    parts: [
      { name: "Réfrigérant R-134a (1kg)", partNo: "AC-R134", qty: 2, unitPrice: 35.0 },
      { name: "Joint torique compresseur", partNo: "JT-0044", qty: 1, unitPrice: 8.25  },
    ],
    labor: [
      { description: "Diagnostic système A/C", hours: 0.5, rate: 120.0 },
      { description: "Recharge réfrigérant",   hours: 1.0, rate: 120.0 },
    ],
    notes: "Fuite mineure détectée au joint — réparé. Système testé OK.",
  },
];

type LocalOrder = typeof sampleOrders[0];

const statusOptions = ["Tous", "En cours", "En attente", "Planifié", "Terminé"];
const bayOptions    = ["Tous", "Lift 1", "Lift 2", "—"];
const BAY_OPTS      = ["—", "Lift 1", "Lift 2"];
const STATUS_OPTS   = ["En cours", "En attente", "Planifié", "Terminé"];

const GST_RATE = 0.05;
const QST_RATE = 0.09975;

const statusConfig: Record<string, { color: string; icon: React.ReactNode }> = {
  "En cours":    { color: "bg-primary text-primary-foreground",    icon: <Wrench size={11} weight="duotone" /> },
  "En attente":  { color: "bg-accent text-accent-foreground",      icon: <HourglassMedium size={11} weight="duotone" /> },
  "Planifié":    { color: "bg-muted text-muted-foreground",        icon: <CalendarBlank size={11} weight="duotone" /> },
  "Terminé":     { color: "bg-muted text-foreground",              icon: <CheckCircle size={11} weight="duotone" /> },
};

function formatDateTime(dt: string) {
  const d = new Date(dt);
  return d.toLocaleString("fr-CA", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

function calcTotals(ro: LocalOrder) {
  const partsSub  = ro.parts.reduce((s, p) => s + p.qty * p.unitPrice, 0);
  const laborSub  = ro.labor.reduce((s, l) => s + l.hours * l.rate, 0);
  const subtotal  = partsSub + laborSub;
  const gst       = subtotal * GST_RATE;
  const qst       = subtotal * QST_RATE;
  const total     = subtotal + gst + qst;
  return { partsSub, laborSub, subtotal, gst, qst, total };
}

// ─── Types for the create-order form ────────────────────────────────────────
type PartLine  = { id: number; name: string; partNo: string; qty: number; unitPrice: number };
type LaborLine = { id: number; description: string; hours: number; rate: number };

function parseVehicles(raw: string | undefined, primary: string): string[] {
  if (raw) {
    try {
      const arr = JSON.parse(raw);
      if (Array.isArray(arr) && arr.length > 0) {
        return arr.map((item: unknown) => {
          if (typeof item === "string") return item;
          if (item && typeof item === "object") {
            const o = item as Record<string, string>;
            if (o.label) return o.label;
            const parts: string[] = [];
            if (o.annee) parts.push(o.annee);
            if (o.marque) parts.push(o.marque);
            if (o.modele) parts.push(o.modele);
            return parts.length ? parts.join(" ") : o.vehicleInfo || primary;
          }
          return primary;
        });
      }
    } catch { /* */ }
  }
  return primary ? [primary] : [];
}

// ─── Create-Order Modal ───────────────────────────────────────────────────────
function NewOrderModal({ onClose, onCreated, orgId }: { onClose: () => void; onCreated: (o: LocalOrder) => void; orgId: string }) {
  const { data: allCustomers } = useQuery<Customer>("Customer", { where: { orgId }, orderBy: { name: "asc" } });
  const { create: createRO } = useMutation("RepairOrder");

  const [customerName, setCustomerName] = useState("");
  const [vehicleInfo,  setVehicleInfo]  = useState("");
  const [plate,        setPlate]        = useState("");
  const [bay,          setBay]          = useState("—");
  const [orderStatus,  setOrderStatus]  = useState("Planifié");
  const [promised,     setPromised]     = useState(() => {
    const d = new Date(); d.setHours(17, 0, 0, 0);
    return d.toISOString().slice(0, 16);
  });
  const [complaint,    setComplaint]    = useState("");
  const [notes,        setNotes]        = useState("");

  const [parts,  setParts]  = useState<PartLine[]>([{ id: 1, name: "", partNo: "", qty: 1, unitPrice: 0 }]);
  const [labor,  setLabor]  = useState<LaborLine[]>([{ id: 1, description: "", hours: 1, rate: 120 }]);

  const [showPicker, setShowPicker]  = useState(false);
  const [pickerQ,    setPickerQ]     = useState("");
  const [saveMsg,    setSaveMsg]     = useState("");
  const [saving,     setSaving]      = useState(false);

  const filteredC = (allCustomers ?? []).filter((c) => {
    if (!pickerQ) return true;
    const q = pickerQ.toLowerCase();
    return c.name.toLowerCase().includes(q) || (c.vehicleInfo ?? "").toLowerCase().includes(q);
  });

  const selectCustomer = (id: string) => {
    const c = allCustomers?.find((x) => x.id === id);
    if (!c) return;
    setCustomerName(c.name);
    const veh = parseVehicles(c.vehicles as string | undefined, c.vehicleInfo ?? "");
    setVehicleInfo(veh[0] ?? c.vehicleInfo ?? "");
    setShowPicker(false);
    setPickerQ("");
  };

  // parts helpers
  const addPart    = () => setParts((p) => [...p, { id: Date.now(), name: "", partNo: "", qty: 1, unitPrice: 0 }]);
  const removePart = (id: number) => setParts((p) => p.filter((x) => x.id !== id));
  const upPart     = (id: number, f: string, v: string | number) =>
    setParts((p) => p.map((x) => x.id === id ? { ...x, [f]: v } : x));

  // labor helpers
  const addLabor    = () => setLabor((l) => [...l, { id: Date.now(), description: "", hours: 1, rate: 120 }]);
  const removeLabor = (id: number) => setLabor((l) => l.filter((x) => x.id !== id));
  const upLabor     = (id: number, f: string, v: string | number) =>
    setLabor((l) => l.map((x) => x.id === id ? { ...x, [f]: v } : x));

  const partsSub  = parts.reduce((s, p) => s + p.qty * p.unitPrice, 0);
  const laborSub  = labor.reduce((s, l) => s + l.hours * l.rate, 0);
  const subtotal  = partsSub + laborSub;
  const gst       = subtotal * GST_RATE;
  const qst       = subtotal * QST_RATE;
  const total     = subtotal + gst + qst;
  const fmt       = (n: number) => n.toLocaleString("fr-CA", { style: "currency", currency: "CAD" });

  const handleSave = async () => {
    if (!customerName.trim()) { setSaveMsg("⚠ Entrez le nom du client."); return; }
    if (!vehicleInfo.trim())  { setSaveMsg("⚠ Entrez le véhicule."); return; }
    setSaving(true);
    const y   = new Date().getFullYear();
    const num = `RO-${y}-${String(Math.floor(Math.random() * 9000) + 1000)}`;
    try {
      await createRO({
        orgId,
        orderNumber:  num,
        customerName: customerName.trim(),
        vehicleInfo:  vehicleInfo.trim(),
        status:       orderStatus,
        subtotal,
        tpsAmount:    gst,
        tvqAmount:    qst,
        total,
        date:         new Date(promised),
      });
    } catch { /* silent — we still create the local order */ }

    const newOrder: LocalOrder = {
      id:         num,
      customer:   customerName.trim(),
      vehicle:    vehicleInfo.trim(),
      plate:      plate.trim() || "—",
      bay,
      technicien: "",
      status:     orderStatus,
      promised,
      complaint:  complaint.trim() || "—",
      parts:      parts.filter((p) => p.name.trim()).map((p) => ({ name: p.name, partNo: p.partNo, qty: p.qty, unitPrice: p.unitPrice })),
      labor:      labor.filter((l) => l.description.trim()).map((l) => ({ description: l.description, hours: l.hours, rate: l.rate })),
      notes:      notes.trim(),
    };
    setSaving(false);
    onCreated(newOrder);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-end">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />

      {/* Drawer */}
      <div className="relative z-10 w-full max-w-lg h-full bg-background border-l border-border shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="px-5 py-4 border-b border-border flex items-center justify-between gap-3 bg-background sticky top-0 z-10">
          <div className="flex items-center gap-2">
            <Wrench size={16} weight="duotone" className="text-primary" />
            <h2 className="font-heading text-sm font-semibold text-foreground">Nouvel ordre de réparation</h2>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors">
            <X size={16} weight="duotone" />
          </button>
        </div>

        {/* Scrollable body */}
        <div className="flex-1 overflow-y-auto px-5 py-5 space-y-6">
          {/* ── Client ── */}
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground mb-3">Client &amp; Véhicule</p>

            {/* Customer picker */}
            <div className="mb-3">
              <button
                type="button"
                onClick={() => setShowPicker((v) => !v)}
                className="w-full flex items-center justify-between px-3 py-2 rounded-lg border border-dashed border-border bg-background hover:bg-muted text-xs text-muted-foreground transition-all"
              >
                <span className="flex items-center gap-2">
                  <User size={13} weight="duotone" />
                  {customerName || "Sélectionner un client existant…"}
                </span>
                <CaretDown size={12} weight="duotone" />
              </button>
              {showPicker && (
                <div className="mt-1 rounded-xl border border-border bg-card shadow-lg overflow-hidden">
                  <div className="p-2 border-b border-border">
                    <Input
                      value={pickerQ}
                      onChange={(e) => setPickerQ(e.target.value)}
                      placeholder="Rechercher…"
                      className="h-7 text-xs rounded-md"
                      autoFocus
                    />
                  </div>
                  <div className="max-h-44 overflow-y-auto">
                    {filteredC.length === 0 ? (
                      <p className="text-xs text-muted-foreground text-center py-4">Aucun client trouvé.</p>
                    ) : filteredC.map((c) => (
                      <button
                        key={c.id}
                        type="button"
                        onClick={() => selectCustomer(c.id)}
                        className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-muted text-left transition-colors"
                      >
                        <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                          <User size={11} weight="duotone" className="text-primary" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-medium text-foreground truncate">{c.name}</p>
                          <p className="text-[10px] text-muted-foreground truncate">{c.vehicleInfo ?? ""}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5 col-span-2">
                <Label className="text-[10px] uppercase tracking-widest text-muted-foreground">Nom du client *</Label>
                <Input value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder="Martin Tremblay" className="h-8 text-sm rounded-md border-border" />
              </div>
              <div className="space-y-1.5 col-span-2">
                <Label className="text-[10px] uppercase tracking-widest text-muted-foreground">Véhicule *</Label>
                <Input value={vehicleInfo} onChange={(e) => setVehicleInfo(e.target.value)} placeholder="2019 Honda Civic EX" className="h-8 text-sm rounded-md border-border" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-[10px] uppercase tracking-widest text-muted-foreground">Plaque</Label>
                <Input value={plate} onChange={(e) => setPlate(e.target.value)} placeholder="ABC-1234" className="h-8 text-sm rounded-md border-border" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-[10px] uppercase tracking-widest text-muted-foreground">Lift</Label>
                <div className="flex gap-1 flex-wrap">
                  {BAY_OPTS.map((b) => (
                    <button
                      key={b}
                      type="button"
                      onClick={() => setBay(b)}
                      className={`px-2 py-1 rounded-md text-xs font-medium border transition-all ${bay === b ? "bg-primary text-primary-foreground border-primary" : "bg-background text-muted-foreground border-border hover:border-primary"}`}
                    >
                      {b}
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-[10px] uppercase tracking-widest text-muted-foreground">Statut</Label>
                <div className="flex gap-1 flex-wrap">
                  {STATUS_OPTS.map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setOrderStatus(s)}
                      className={`px-2 py-1 rounded-md text-xs font-medium border transition-all ${orderStatus === s ? "bg-primary text-primary-foreground border-primary" : "bg-background text-muted-foreground border-border hover:border-primary"}`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-[10px] uppercase tracking-widest text-muted-foreground">Promis le</Label>
                <Input type="datetime-local" value={promised} onChange={(e) => setPromised(e.target.value)} className="h-8 text-xs rounded-md border-border" />
              </div>
            </div>
          </div>

          {/* ── Plainte ── */}
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground mb-2">Plainte / Description</p>
            <textarea
              value={complaint}
              onChange={(e) => setComplaint(e.target.value)}
              placeholder="Décrivez le problème rapporté par le client…"
              rows={3}
              className="w-full text-xs text-foreground bg-background border border-border rounded-lg p-2.5 resize-none focus:outline-none focus:ring-1 focus:ring-ring"
            />
          </div>

          {/* ── Pièces ── */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground flex items-center gap-1.5">
                <Package size={13} weight="duotone" /> Pièces
              </p>
              <span className="text-xs font-mono text-muted-foreground">{fmt(partsSub)}</span>
            </div>
            <div className="space-y-2">
              {parts.map((part) => (
                <div key={part.id} className="grid grid-cols-12 gap-1.5 items-center group">
                  <div className="col-span-5">
                    <Input value={part.name} onChange={(e) => upPart(part.id, "name", e.target.value)} placeholder="Description" className="h-7 text-xs rounded-md border-border" />
                  </div>
                  <div className="col-span-2">
                    <Input value={part.partNo} onChange={(e) => upPart(part.id, "partNo", e.target.value)} placeholder="N° pièce" className="h-7 text-xs rounded-md border-border" />
                  </div>
                  <div className="col-span-2">
                    <Input type="number" value={part.qty} onChange={(e) => upPart(part.id, "qty", parseFloat(e.target.value) || 0)} className="h-7 text-xs rounded-md border-border text-center" />
                  </div>
                  <div className="col-span-2">
                    <Input type="number" value={part.unitPrice} onChange={(e) => upPart(part.id, "unitPrice", parseFloat(e.target.value) || 0)} className="h-7 text-xs rounded-md border-border text-right" />
                  </div>
                  <div className="col-span-1 flex justify-end">
                    <button onClick={() => removePart(part.id)} className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-red-500 transition-all">
                      <Trash size={13} weight="duotone" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
            <button onClick={addPart} className="mt-2 flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors">
              <Plus size={12} weight="duotone" /> Ajouter une pièce
            </button>
          </div>

          {/* ── Main-d'œuvre ── */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground flex items-center gap-1.5">
                <Wrench size={13} weight="duotone" /> Main-d&#39;œuvre
              </p>
              <span className="text-xs font-mono text-muted-foreground">{fmt(laborSub)}</span>
            </div>
            <div className="space-y-2">
              {labor.map((entry) => (
                <div key={entry.id} className="grid grid-cols-12 gap-1.5 items-center group">
                  <div className="col-span-6">
                    <Input value={entry.description} onChange={(e) => upLabor(entry.id, "description", e.target.value)} placeholder="Description" className="h-7 text-xs rounded-md border-border" />
                  </div>
                  <div className="col-span-2">
                    <Input type="number" value={entry.hours} onChange={(e) => upLabor(entry.id, "hours", parseFloat(e.target.value) || 0)} placeholder="h" className="h-7 text-xs rounded-md border-border text-center" />
                  </div>
                  <div className="col-span-3">
                    <Input type="number" value={entry.rate} onChange={(e) => upLabor(entry.id, "rate", parseFloat(e.target.value) || 0)} placeholder="$/h" className="h-7 text-xs rounded-md border-border text-right" />
                  </div>
                  <div className="col-span-1 flex justify-end">
                    <button onClick={() => removeLabor(entry.id)} className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-red-500 transition-all">
                      <Trash size={13} weight="duotone" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
            <button onClick={addLabor} className="mt-2 flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors">
              <Plus size={12} weight="duotone" /> Ajouter une entrée
            </button>
          </div>

          {/* ── Notes ── */}
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground mb-2">Notes internes</p>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Notes supplémentaires…"
              rows={2}
              className="w-full text-xs text-foreground bg-background border border-border rounded-lg p-2.5 resize-none focus:outline-none focus:ring-1 focus:ring-ring"
            />
          </div>

          {/* ── Sommaire ── */}
          <div className="rounded-xl border border-border bg-muted/20 p-4 space-y-2">
            <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground flex items-center gap-1.5 mb-1">
              <Receipt size={13} weight="duotone" /> Sommaire
            </p>
            <div className="flex justify-between text-xs"><span className="text-muted-foreground">Pièces</span><span className="font-mono">{fmt(partsSub)}</span></div>
            <div className="flex justify-between text-xs"><span className="text-muted-foreground">Main-d&#39;œuvre</span><span className="font-mono">{fmt(laborSub)}</span></div>
            <Separator />
            <div className="flex justify-between text-xs font-semibold"><span>Sous-total</span><span className="font-mono">{fmt(subtotal)}</span></div>
            <div className="flex justify-between text-xs"><span className="text-muted-foreground">TPS (5 %)</span><span className="font-mono">{fmt(gst)}</span></div>
            <div className="flex justify-between text-xs"><span className="text-muted-foreground">TVQ (9,975 %)</span><span className="font-mono">{fmt(qst)}</span></div>
            <Separator />
            <div className="flex justify-between items-center">
              <span className="text-sm font-bold text-foreground">Total TTC</span>
              <span className="font-mono text-base font-bold text-foreground">{fmt(total)}</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-4 border-t border-border bg-background sticky bottom-0">
          {saveMsg && (
            <p className={`text-xs mb-2 flex items-center gap-1 ${saveMsg.startsWith("⚠") ? "text-red-500" : "text-green-600"}`}>
              {saveMsg.startsWith("⚠") ? <Warning size={12} weight="duotone" /> : <CheckCircle size={12} weight="duotone" />}
              {saveMsg}
            </p>
          )}
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={onClose} className="flex-1 text-xs rounded-md border-border">
              Annuler
            </Button>
            <Button size="sm" onClick={handleSave} disabled={saving} className="flex-1 bg-primary text-primary-foreground text-xs rounded-md shadow-sm gap-1.5">
              <FloppyDisk size={13} weight="duotone" />
              {saving ? "Enregistrement…" : "Créer l'ordre"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────
export default function RepairOrders({ orgId }: { orgId: string }) {
  const [orders, setOrders] = useState<LocalOrder[]>(sampleOrders);
  const [statusFilter, setStatusFilter] = useState("Tous");
  const [bayFilter,    setBayFilter]    = useState("Tous");
  const [search,       setSearch]       = useState("");
  const [sortCol,      setSortCol]      = useState<string>("id");
  const [sortDir,      setSortDir]      = useState<"asc" | "desc">("desc");
  const [selectedId,   setSelectedId]   = useState<string | null>("RO-2024-0041");
  const [showModal,    setShowModal]    = useState(false);

  // context menu
  const [ctxMenu, setCtxMenu] = useState<{ x: number; y: number; orderId: string } | null>(null);

  const handleContextMenu = useCallback((e: React.MouseEvent, orderId: string) => {
    e.preventDefault();
    setCtxMenu({ x: e.clientX, y: e.clientY, orderId });
  }, []);

  const handleDeleteOrder = useCallback((orderId: string) => {
    if (!confirm("Supprimer cet ordre de réparation ?")) return;
    setOrders((prev) => prev.filter((o) => o.id !== orderId));
    if (selectedId === orderId) setSelectedId(null);
  }, [selectedId]);

  const handleSort = (col: string) => {
    if (sortCol === col) {
      setSortDir(sortDir === "asc" ? "desc" : "asc");
    } else {
      setSortCol(col);
      setSortDir("asc");
    }
  };

  const filtered = orders
    .filter((ro) => {
      if (statusFilter !== "Tous" && ro.status !== statusFilter) return false;
      if (bayFilter !== "Tous" && ro.bay !== bayFilter) return false;
      if (
        search &&
        !ro.id.toLowerCase().includes(search.toLowerCase()) &&
        !ro.customer.toLowerCase().includes(search.toLowerCase()) &&
        !ro.vehicle.toLowerCase().includes(search.toLowerCase())
      ) return false;
      return true;
    })
    .sort((a, b) => {
      let av = ""; let bv = "";
      if (sortCol === "id")       { av = a.id;       bv = b.id; }
      else if (sortCol === "customer") { av = a.customer; bv = b.customer; }
      else if (sortCol === "bay")      { av = a.bay;      bv = b.bay; }
      else if (sortCol === "status")   { av = a.status;   bv = b.status; }
      else if (sortCol === "promised") { av = a.promised; bv = b.promised; }
      else if (sortCol === "total") {
        const at = calcTotals(a).total;
        const bt = calcTotals(b).total;
        return sortDir === "asc" ? at - bt : bt - at;
      }
      return sortDir === "asc" ? av.localeCompare(bv) : bv.localeCompare(av);
    });

  const selectedRO = orders.find((ro) => ro.id === selectedId) || null;
  const totals     = selectedRO ? calcTotals(selectedRO) : null;

  const SortIcon = ({ col }: { col: string }) => {
    if (sortCol !== col) return <CaretUpDown size={13} weight="duotone" className="text-muted-foreground ml-1 inline" />;
    return sortDir === "asc"
      ? <CaretUp   size={13} weight="duotone" className="text-primary ml-1 inline" />
      : <CaretDown size={13} weight="duotone" className="text-primary ml-1 inline" />;
  };

  return (
    <section id="repair-orders" className="bg-background min-h-screen flex flex-col">
      {/* Page header */}
      <div className="border-b border-border px-6 py-4 flex items-center justify-between gap-4 bg-background">
        <div>
          <h1 className="font-heading text-lg font-semibold text-foreground tracking-tight">Ordres de réparation</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Actifs et planifiés — Atelier Nordic Garage</p>
        </div>
        <Button
          size="sm"
          onClick={() => setShowModal(true)}
          className="bg-primary text-primary-foreground rounded-md gap-1.5 text-xs font-medium shadow-sm"
        >
          <Wrench size={14} weight="duotone" />
          Nouvel ordre
        </Button>
      </div>

      {/* Filter bar */}
      <div className="border-b border-border bg-muted/40 px-6 py-3 flex flex-wrap items-end gap-4">
        {/* Search */}
        <div className="flex flex-col gap-1 min-w-[180px]">
          <Label className="text-[10px] font-medium text-muted-foreground uppercase tracking-widest">Recherche</Label>
          <div className="relative">
            <MagnifyingGlass size={14} weight="duotone" className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="No., client, véhicule…"
              className="pl-8 h-8 text-xs rounded-md border-border bg-background"
            />
          </div>
        </div>

        {/* Status filter */}
        <div className="flex flex-col gap-1">
          <Label className="text-[10px] font-medium text-muted-foreground uppercase tracking-widest">Statut</Label>
          <div className="flex gap-1">
            {statusOptions.map((s) => (
              <button
                key={s}
                onClick={() => setStatusFilter(s)}
                className={`px-2.5 py-1 rounded-md text-xs font-medium border transition-all duration-150 ${
                  statusFilter === s
                    ? "bg-primary text-primary-foreground border-primary shadow-sm"
                    : "bg-background text-muted-foreground border-border hover:border-primary hover:text-foreground"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Bay filter */}
        <div className="flex flex-col gap-1">
          <Label className="text-[10px] font-medium text-muted-foreground uppercase tracking-widest">Lift</Label>
          <div className="flex gap-1">
            {bayOptions.map((b) => (
              <button
                key={b}
                onClick={() => setBayFilter(b)}
                className={`px-2.5 py-1 rounded-md text-xs font-medium border transition-all duration-150 ${
                  bayFilter === b
                    ? "bg-primary text-primary-foreground border-primary shadow-sm"
                    : "bg-background text-muted-foreground border-border hover:border-primary hover:text-foreground"
                }`}
              >
                {b}
              </button>
            ))}
          </div>
        </div>

        <div className="ml-auto flex items-end">
          <span className="text-xs text-muted-foreground">
            <span className="font-semibold text-foreground">{filtered.length}</span>{" "}
            ordre{filtered.length !== 1 ? "s" : ""}
          </span>
        </div>
      </div>

      {/* Main content: table + drawer */}
      <div className="flex flex-1 overflow-hidden">
        {/* Table */}
        <div className={`flex-1 overflow-auto transition-all duration-200 ${selectedRO ? "lg:max-w-[calc(100%-420px)]" : ""}`}>
          <table className="w-full text-sm border-collapse">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                {[
                  { key: "id",       label: "No. OR" },
                  { key: "customer", label: "Client / Véhicule" },
                  { key: "bay",      label: "Lift" },
                  { key: "status",   label: "Statut" },
                  { key: "promised", label: "Promis le" },
                  { key: "total",    label: "Total" },
                ].map((col) => (
                  <th
                    key={col.key}
                    onClick={() => handleSort(col.key)}
                    className="text-left px-4 py-2.5 text-[10px] font-semibold text-muted-foreground uppercase tracking-widest cursor-pointer select-none whitespace-nowrap hover:text-foreground transition-colors"
                  >
                    {col.label}
                    <SortIcon col={col.key} />
                  </th>
                ))}
                <th className="px-4 py-2.5 w-8" />
              </tr>
            </thead>
            <tbody>
              {filtered.map((ro) => {
                const { total } = calcTotals(ro);
                const isSelected = selectedId === ro.id;
                const cfg = statusConfig[ro.status];
                return (
                  <tr
                    key={ro.id}
                    onClick={() => setSelectedId(isSelected ? null : ro.id)}
                    onContextMenu={(e) => handleContextMenu(e, ro.id)}
                    className={`border-b border-border cursor-pointer transition-all duration-100 group ${
                      isSelected ? "bg-accent/60" : "hover:bg-muted/50 hover:shadow-sm"
                    }`}
                  >
                    <td className="px-4 py-3 font-mono text-xs font-semibold text-foreground whitespace-nowrap">{ro.id}</td>
                    <td className="px-4 py-3">
                      <div className="font-medium text-foreground text-xs leading-tight">{ro.customer}</div>
                      <div className="text-muted-foreground text-[11px] mt-0.5 flex items-center gap-1">
                        <Car size={11} weight="duotone" />
                        {ro.vehicle}
                        <span className="font-mono text-[10px] bg-muted px-1 rounded ml-1">{ro.plate}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-xs text-foreground font-medium">{ro.bay}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium ${cfg.color}`}>
                        {cfg.icon}
                        {ro.status}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1 text-xs text-foreground">
                        <Clock size={12} weight="duotone" className="text-muted-foreground" />
                        {formatDateTime(ro.promised)}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-right font-mono text-xs font-semibold text-foreground whitespace-nowrap">
                      {total.toLocaleString("fr-CA", { style: "currency", currency: "CAD" })}
                    </td>
                    <td className="px-4 py-3">
                      <ArrowRight
                        size={14}
                        weight="duotone"
                        className={`text-muted-foreground transition-all duration-150 ${isSelected ? "text-primary rotate-90" : "group-hover:text-primary group-hover:translate-x-0.5"}`}
                      />
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-4 py-12 text-center text-muted-foreground text-sm">
                    Aucun ordre de réparation trouvé.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Detail Drawer */}
        {selectedRO && totals && (
          <aside className="w-full lg:w-[420px] border-l border-border bg-background flex flex-col overflow-y-auto shrink-0">
            {/* Drawer header */}
            <div className="px-5 py-4 border-b border-border flex items-start justify-between gap-3 sticky top-0 bg-background z-10">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-mono text-xs font-bold text-foreground">{selectedRO.id}</span>
                  <select
                    value={selectedRO.status}
                    onChange={(e) => setOrders((prev) => prev.map((o) => o.id === selectedRO.id ? { ...o, status: e.target.value } : o))}
                    className="text-[11px] font-medium rounded-full px-2 py-0.5 border-0 bg-muted text-foreground cursor-pointer focus:outline-none focus:ring-1 focus:ring-primary"
                  >
                    {STATUS_OPTS.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <input
                  value={selectedRO.customer}
                  onChange={(e) => setOrders((prev) => prev.map((o) => o.id === selectedRO.id ? { ...o, customer: e.target.value } : o))}
                  className="mt-0.5 text-sm font-semibold text-foreground bg-transparent border-b border-transparent focus:border-primary focus:outline-none w-full"
                />
                <div className="flex items-center gap-1.5 mt-0.5">
                  <Car size={12} weight="duotone" className="text-muted-foreground shrink-0" />
                  <input
                    value={selectedRO.vehicle}
                    onChange={(e) => setOrders((prev) => prev.map((o) => o.id === selectedRO.id ? { ...o, vehicle: e.target.value } : o))}
                    className="text-xs text-muted-foreground bg-transparent border-b border-transparent focus:border-primary focus:outline-none flex-1 min-w-0"
                  />
                  <input
                    value={selectedRO.plate}
                    onChange={(e) => setOrders((prev) => prev.map((o) => o.id === selectedRO.id ? { ...o, plate: e.target.value } : o))}
                    className="font-mono text-[10px] bg-muted px-1 rounded text-foreground border border-transparent focus:border-primary focus:outline-none w-20 text-center"
                  />
                </div>
              </div>
              <button onClick={() => setSelectedId(null)} className="text-muted-foreground hover:text-foreground transition-colors mt-0.5 shrink-0">
                <X size={16} weight="duotone" />
              </button>
            </div>

            {/* Meta row — editable */}
            <div className="px-5 py-3 border-b border-border grid grid-cols-2 gap-3 bg-muted/20">
              <div>
                <div className="text-[10px] font-semibold text-muted-foreground uppercase tracking-widest mb-0.5">Lift</div>
                <div className="flex items-center gap-1.5">
                  <Garage size={13} weight="duotone" className="text-muted-foreground shrink-0" />
                  <select
                    value={selectedRO.bay}
                    onChange={(e) => setOrders((prev) => prev.map((o) => o.id === selectedRO.id ? { ...o, bay: e.target.value } : o))}
                    className="text-xs font-medium text-foreground bg-transparent border-0 focus:outline-none focus:ring-1 focus:ring-primary rounded cursor-pointer"
                  >
                    {BAY_OPTS.map((b) => <option key={b} value={b}>{b}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <div className="text-[10px] font-semibold text-muted-foreground uppercase tracking-widest mb-0.5">Promis le</div>
                <div className="flex items-center gap-1.5">
                  <Clock size={13} weight="duotone" className="text-muted-foreground shrink-0" />
                  <input
                    type="datetime-local"
                    value={selectedRO.promised}
                    onChange={(e) => setOrders((prev) => prev.map((o) => o.id === selectedRO.id ? { ...o, promised: e.target.value } : o))}
                    className="text-xs font-medium text-foreground bg-transparent border-0 focus:outline-none focus:ring-1 focus:ring-primary rounded cursor-pointer w-full"
                  />
                </div>
              </div>
            </div>

            {/* Panel 1: Complaint / Notes */}
            <div className="px-5 py-4 border-b border-border">
              <div className="flex items-center gap-2 mb-3">
                <Note size={14} weight="duotone" className="text-muted-foreground" />
                <span className="text-[10px] font-semibold text-muted-foreground uppercase tracking-widest">Plainte / Notes</span>
              </div>
              <textarea
                value={selectedRO.complaint}
                onChange={(e) =>
                  setOrders((prev) =>
                    prev.map((o) => o.id === selectedRO.id ? { ...o, complaint: e.target.value } : o)
                  )
                }
                rows={3}
                className="w-full text-xs text-foreground bg-background border border-border rounded-lg p-2 resize-none focus:outline-none focus:ring-1 focus:ring-ring"
              />
              <div className="mt-2 pt-2 border-t border-border">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wide font-semibold mb-1">Note tech</p>
                <textarea
                  value={selectedRO.notes}
                  onChange={(e) =>
                    setOrders((prev) =>
                      prev.map((o) => o.id === selectedRO.id ? { ...o, notes: e.target.value } : o)
                    )
                  }
                  rows={2}
                  placeholder="Note technique…"
                  className="w-full text-xs text-foreground bg-background border border-border rounded-lg p-2 resize-none focus:outline-none focus:ring-1 focus:ring-ring"
                />
              </div>
            </div>

            {/* Panel 2: Parts — inline editable */}
            <div className="px-5 py-4 border-b border-border">
              <div className="flex items-center gap-2 mb-3">
                <Package size={14} weight="duotone" className="text-muted-foreground" />
                <span className="text-[10px] font-semibold text-muted-foreground uppercase tracking-widest">Pièces</span>
              </div>
              <div className="space-y-1">
                {selectedRO.parts.map((part, i) => (
                  <div key={i} className="grid grid-cols-12 gap-1 items-center py-1.5 border-b border-border last:border-0 group">
                    <div className="col-span-5">
                      <input
                        value={part.name}
                        onChange={(e) => setOrders((prev) => prev.map((o) => o.id === selectedRO.id ? { ...o, parts: o.parts.map((p, pi) => pi === i ? { ...p, name: e.target.value } : p) } : o))}
                        className="w-full text-xs font-medium text-foreground bg-transparent border-b border-transparent focus:border-primary focus:outline-none py-0.5"
                        placeholder="Description"
                      />
                    </div>
                    <div className="col-span-3">
                      <input
                        value={part.partNo}
                        onChange={(e) => setOrders((prev) => prev.map((o) => o.id === selectedRO.id ? { ...o, parts: o.parts.map((p, pi) => pi === i ? { ...p, partNo: e.target.value } : p) } : o))}
                        className="w-full text-[10px] text-muted-foreground font-mono bg-transparent border-b border-transparent focus:border-primary focus:outline-none py-0.5"
                        placeholder="N° pièce"
                      />
                    </div>
                    <div className="col-span-1 text-center">
                      <input
                        type="number"
                        value={part.qty}
                        onChange={(e) => setOrders((prev) => prev.map((o) => o.id === selectedRO.id ? { ...o, parts: o.parts.map((p, pi) => pi === i ? { ...p, qty: parseFloat(e.target.value) || 0 } : p) } : o))}
                        className="w-full text-xs text-center text-foreground bg-transparent border-b border-transparent focus:border-primary focus:outline-none py-0.5"
                      />
                    </div>
                    <div className="col-span-2">
                      <input
                        type="number"
                        value={part.unitPrice}
                        onChange={(e) => setOrders((prev) => prev.map((o) => o.id === selectedRO.id ? { ...o, parts: o.parts.map((p, pi) => pi === i ? { ...p, unitPrice: parseFloat(e.target.value) || 0 } : p) } : o))}
                        className="w-full text-xs text-right text-foreground bg-transparent border-b border-transparent focus:border-primary focus:outline-none py-0.5"
                      />
                    </div>
                    <div className="col-span-1 flex justify-end">
                      <button
                        onClick={() => setOrders((prev) => prev.map((o) => o.id === selectedRO.id ? { ...o, parts: o.parts.filter((_, pi) => pi !== i) } : o))}
                        className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-red-500 transition-all"
                      >
                        <Trash size={11} weight="duotone" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
              <button
                onClick={() => setOrders((prev) => prev.map((o) => o.id === selectedRO.id ? { ...o, parts: [...o.parts, { name: "", partNo: "", qty: 1, unitPrice: 0 }] } : o))}
                className="mt-2 flex items-center gap-1 text-[11px] text-muted-foreground hover:text-foreground transition-colors"
              >
                <Plus size={11} weight="duotone" /> Ajouter une pièce
              </button>
              <div className="flex justify-between items-center mt-2 pt-2 border-t border-border">
                <span className="text-[10px] text-muted-foreground uppercase tracking-widest font-semibold">Sous-total pièces</span>
                <span className="text-xs font-mono font-bold text-foreground">
                  {totals.partsSub.toLocaleString("fr-CA", { style: "currency", currency: "CAD" })}
                </span>
              </div>
            </div>

            {/* Panel 3: Labor — inline editable */}
            <div className="px-5 py-4 border-b border-border">
              <div className="flex items-center gap-2 mb-3">
                <Wrench size={14} weight="duotone" className="text-muted-foreground" />
                <span className="text-[10px] font-semibold text-muted-foreground uppercase tracking-widest">Main-d&#39;œuvre</span>
              </div>
              <div className="space-y-1">
                {selectedRO.labor.map((entry, i) => (
                  <div key={i} className="grid grid-cols-12 gap-1 items-center py-1.5 border-b border-border last:border-0 group">
                    <div className="col-span-6">
                      <input
                        value={entry.description}
                        onChange={(e) => setOrders((prev) => prev.map((o) => o.id === selectedRO.id ? { ...o, labor: o.labor.map((l, li) => li === i ? { ...l, description: e.target.value } : l) } : o))}
                        className="w-full text-xs font-medium text-foreground bg-transparent border-b border-transparent focus:border-primary focus:outline-none py-0.5"
                        placeholder="Description"
                      />
                    </div>
                    <div className="col-span-2 flex items-center gap-0.5">
                      <input
                        type="number"
                        value={entry.hours}
                        onChange={(e) => setOrders((prev) => prev.map((o) => o.id === selectedRO.id ? { ...o, labor: o.labor.map((l, li) => li === i ? { ...l, hours: parseFloat(e.target.value) || 0 } : l) } : o))}
                        className="w-full text-xs text-center text-foreground bg-transparent border-b border-transparent focus:border-primary focus:outline-none py-0.5"
                      />
                      <span className="text-[10px] text-muted-foreground shrink-0">h</span>
                    </div>
                    <div className="col-span-3">
                      <input
                        type="number"
                        value={entry.rate}
                        onChange={(e) => setOrders((prev) => prev.map((o) => o.id === selectedRO.id ? { ...o, labor: o.labor.map((l, li) => li === i ? { ...l, rate: parseFloat(e.target.value) || 0 } : l) } : o))}
                        className="w-full text-xs text-right text-foreground bg-transparent border-b border-transparent focus:border-primary focus:outline-none py-0.5"
                      />
                    </div>
                    <div className="col-span-1 flex justify-end">
                      <button
                        onClick={() => setOrders((prev) => prev.map((o) => o.id === selectedRO.id ? { ...o, labor: o.labor.filter((_, li) => li !== i) } : o))}
                        className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-red-500 transition-all"
                      >
                        <Trash size={11} weight="duotone" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
              <button
                onClick={() => setOrders((prev) => prev.map((o) => o.id === selectedRO.id ? { ...o, labor: [...o.labor, { description: "", hours: 1, rate: 120 }] } : o))}
                className="mt-2 flex items-center gap-1 text-[11px] text-muted-foreground hover:text-foreground transition-colors"
              >
                <Plus size={11} weight="duotone" /> Ajouter une entrée
              </button>
              <div className="flex justify-between items-center mt-2 pt-2 border-t border-border">
                <span className="text-[10px] text-muted-foreground uppercase tracking-widest font-semibold">Sous-total M.O.</span>
                <span className="text-xs font-mono font-bold text-foreground">
                  {totals.laborSub.toLocaleString("fr-CA", { style: "currency", currency: "CAD" })}
                </span>
              </div>
            </div>

            {/* Panel 4: Invoice summary */}
            <div className="px-5 py-4 bg-muted/20">
              <div className="flex items-center gap-2 mb-3">
                <Receipt size={14} weight="duotone" className="text-muted-foreground" />
                <span className="text-[10px] font-semibold text-muted-foreground uppercase tracking-widest">Sommaire de facturation</span>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">Pièces</span>
                  <span className="font-mono text-foreground">{totals.partsSub.toLocaleString("fr-CA", { style: "currency", currency: "CAD" })}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">Main-d&#39;œuvre</span>
                  <span className="font-mono text-foreground">{totals.laborSub.toLocaleString("fr-CA", { style: "currency", currency: "CAD" })}</span>
                </div>
                <Separator className="my-1" />
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-foreground">Sous-total</span>
                  <span className="font-mono text-foreground">{totals.subtotal.toLocaleString("fr-CA", { style: "currency", currency: "CAD" })}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground flex items-center gap-1">
                    <Badge variant="outline" className="text-[9px] px-1 py-0 h-4 font-mono border-border">TPS</Badge>
                    TPS (5,0 %)
                  </span>
                  <span className="font-mono text-foreground">{totals.gst.toLocaleString("fr-CA", { style: "currency", currency: "CAD" })}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground flex items-center gap-1">
                    <Badge variant="outline" className="text-[9px] px-1 py-0 h-4 font-mono border-border">TVQ</Badge>
                    TVQ (9,975 %)
                  </span>
                  <span className="font-mono text-foreground">{totals.qst.toLocaleString("fr-CA", { style: "currency", currency: "CAD" })}</span>
                </div>
                <Separator className="my-1" />
                <div className="flex justify-between items-center">
                  <span className="text-sm font-bold text-foreground flex items-center gap-1.5">
                    <CurrencyDollar size={15} weight="duotone" className="text-primary" />
                    Total TTC
                  </span>
                  <span className="font-mono text-base font-bold text-foreground">
                    {totals.total.toLocaleString("fr-CA", { style: "currency", currency: "CAD" })}
                  </span>
                </div>
              </div>

              {/* Technicien — only on completed orders */}
              {selectedRO.status === "Terminé" && (
                <div className="mt-3 pt-3 border-t border-border space-y-1.5">
                  <Label className="text-[10px] uppercase tracking-widest text-muted-foreground flex items-center gap-1.5">
                    <UserCircle size={12} weight="duotone" /> Travail exécuté par
                  </Label>
                  <Input
                    value={selectedRO.technicien}
                    onChange={(e) => {
                      setOrders((prev) =>
                        prev.map((o) =>
                          o.id === selectedRO.id ? { ...o, technicien: e.target.value } : o
                        )
                      );
                    }}
                    placeholder="Nom du technicien…"
                    className="h-8 text-xs rounded-md border-border bg-background"
                  />
                </div>
              )}

              <div className="mt-4 flex gap-2">
                <Button size="sm" className="flex-1 bg-primary text-primary-foreground text-xs rounded-md shadow-sm">
                  Créer la facture
                </Button>
                <Button size="sm" variant="outline" className="flex-1 text-xs rounded-md border-border">
                  Imprimer OR
                </Button>
              </div>
            </div>
          </aside>
        )}
      </div>

      {/* New Order Modal */}
      {showModal && (
        <NewOrderModal
          onClose={() => setShowModal(false)}
          orgId={orgId}
          onCreated={(newOrder) => {
            setOrders((prev) => [newOrder, ...prev]);
            setSelectedId(newOrder.id);
            setShowModal(false);
          }}
        />
      )}

      {ctxMenu && (() => {
        const ro = orders.find((o) => o.id === ctxMenu.orderId);
        if (!ro) return null;
        const menuItems: ContextMenuItem[] = [
          {
            label: "Ouvrir / Modifier",
            icon: <PencilSimple size={13} weight="duotone" />,
            onClick: () => setSelectedId(ro.id),
          },
          {
            label: ro.status === "Terminé" ? "Marquer En cours" : "Marquer Terminé",
            icon: <CheckCircle size={13} weight="duotone" />,
            onClick: () => setOrders((prev) => prev.map((o) => o.id === ro.id ? { ...o, status: o.status === "Terminé" ? "En cours" : "Terminé" } : o)),
          },
          {
            label: "Supprimer",
            icon: <Trash size={13} weight="duotone" />,
            onClick: () => handleDeleteOrder(ro.id),
            danger: true,
          },
        ];
        return (
          <ContextMenu
            x={ctxMenu.x}
            y={ctxMenu.y}
            items={menuItems}
            onClose={() => setCtxMenu(null)}
          />
        );
      })()}
    </section>
  );
}
