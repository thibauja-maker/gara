import { useState } from "react";
import { useApiCustomers } from "@/hooks/use-api-data";
import type { CatalogPart } from "./PartsCatalog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Plus,
  Trash,
  Calculator,
  User,
  Car,
  Wrench,
  Package,
  Drop,
  CaretUp,
  CaretDown,
  CaretRight,
  List,
  FloppyDisk,
  CheckCircle,
  Clock,
  X,
  Warning,
  Receipt,
  FileText,
  ArrowRight,
  Invoice,
} from "@phosphor-icons/react";

const GST_RATE = 0.05;
const QST_RATE = 0.09975;

type LineItem = { id: number; description: string; partNumber: string; qty: number; unitPrice: number };
type LaborItem = { id: number; description: string; hours: number; rate: number };
type SupplyItem = { id: number; description: string; amount: number };
type EstimateStatus = "Brouillon" | "Envoyée" | "Acceptée" | "Refusée" | "Expirée";

type Estimate = {
  id: string;
  estimateNumber: string;
  customerName: string;
  vehicleInfo: string;
  phone: string;
  mechanic: string;
  jobDesc: string;
  plate: string;
  mileage: string;
  parts: LineItem[];
  labor: LaborItem[];
  supplies: SupplyItem[];
  subtotal: number;
  tps: number;
  tvq: number;
  total: number;
  status: EstimateStatus;
  validUntil: string;
  note: string;
  createdAt: Date;
};

function parseVehicles(raw: string | undefined, primary: string): string[] {
  if (raw) {
    try {
      const arr = JSON.parse(raw);
      if (Array.isArray(arr) && arr.length > 0) {
        return arr.map((item: unknown) => {
          if (typeof item === "string") return item;
          if (item && typeof item === "object") {
            const o = item as Record<string, string>;
            if (o.label) return o.label;
            const parts: string[] = [];
            if (o.annee) parts.push(o.annee);
            if (o.marque) parts.push(o.marque);
            if (o.modele) parts.push(o.modele);
            return parts.length ? parts.join(" ") : (o.vehicleInfo || primary);
          }
          return primary;
        });
      }
    } catch { /* */ }
  }
  return primary ? [primary] : [];
}

const statusColor: Record<EstimateStatus, string> = {
  "Brouillon": "bg-muted text-muted-foreground",
  "Envoyée":   "bg-accent text-accent-foreground",
  "Acceptée":  "bg-primary text-primary-foreground",
  "Refusée":   "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400",
  "Expirée":   "bg-muted text-muted-foreground",
};

const statusIcon: Record<EstimateStatus, React.ReactNode> = {
  "Brouillon": <Clock size={11} weight="duotone" className="inline mr-1" />,
  "Envoyée":   <ArrowRight size={11} weight="duotone" className="inline mr-1" />,
  "Acceptée":  <CheckCircle size={11} weight="duotone" className="inline mr-1" />,
  "Refusée":   <Warning size={11} weight="duotone" className="inline mr-1" />,
  "Expirée":   <Clock size={11} weight="duotone" className="inline mr-1" />,
};

const ALL_STATUSES: EstimateStatus[] = ["Brouillon", "Envoyée", "Acceptée", "Refusée", "Expirée"];

function loadEstimates(orgId: string): Estimate[] {
  try {
    const raw = localStorage.getItem(`garagemanager_${orgId}_estimates`);
    if (raw) return JSON.parse(raw) as Estimate[];
  } catch { /* */ }
  return [];
}

function saveEstimates(orgId: string, list: Estimate[]) {
  localStorage.setItem(`garagemanager_${orgId}_estimates`, JSON.stringify(list));
}

import type { QuotePart } from "./PartsCatalog";
import type { InvoicePrefill } from "../GarageApp";

export default function Estimation({
  prefillParts,
  onPrefillConsumed,
  orgId = "default",
  onCreateInvoice,
}: {
  prefillParts?: QuotePart[] | null;
  onPrefillConsumed?: () => void;
  orgId?: string;
  onCreateInvoice?: (prefill: InvoicePrefill) => void;
}) {
  const [activeTab, setActiveTab] = useState<"new" | "list">(() => (prefillParts && prefillParts.length > 0 ? "new" : "list"));
  const [estimates, setEstimates] = useState<Estimate[]>(() => loadEstimates(orgId));
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [saveMsg, setSaveMsg] = useState("");

  // form
  const [customerName, setCustomerName] = useState("");
  const [phone, setPhone] = useState("");
  const [vehicleInfo, setVehicleInfo] = useState("");
  const [plate, setPlate] = useState("");
  const [mileage, setMileage] = useState("");
  const [mechanic, setMechanic] = useState("");
  const [jobDesc, setJobDesc] = useState("");
  const [parts, setParts] = useState<LineItem[]>(() => {
    if (prefillParts && prefillParts.length > 0) {
      return prefillParts.map((q, i) => ({
        id: i + 1,
        description: q.part.name,
        partNumber: q.part.partNumber ?? "",
        qty: q.qty,
        unitPrice: (q.part as CatalogPart & { price?: number }).price ?? 0,
      }));
    }
    return [{ id: 1, description: "", partNumber: "", qty: 1, unitPrice: 0 }];
  });
  const [labor, setLabor] = useState<LaborItem[]>([{ id: 1, description: "", hours: 0, rate: 110 }]);
  const [supplies, setSupplies] = useState<SupplyItem[]>([]);
  const [status, setStatus] = useState<EstimateStatus>("Brouillon");
  const [validUntil, setValidUntil] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 30);
    return d.toISOString().split("T")[0];
  });
  const [note, setNote] = useState("");

  const [openSections, setOpenSections] = useState({
    customer: true, parts: true, labor: true, supplies: true, taxes: true,
  });

  // customer picker — données depuis l'API MySQL
  const { data: allCustomers } = useApiCustomers(orgId);
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  const [showCustomerPicker, setShowCustomerPicker] = useState(false);
  const [customerSearch, setCustomerSearch] = useState("");

  const toggleSection = (key: keyof typeof openSections) =>
    setOpenSections((p) => ({ ...p, [key]: !p[key] }));

  // calcs
  const partsSubtotal = parts.reduce((s, p) => s + p.qty * p.unitPrice, 0);
  const laborSubtotal = labor.reduce((s, l) => s + l.hours * l.rate, 0);
  const suppliesSubtotal = supplies.reduce((s, s2) => s + s2.amount, 0);
  const subtotal = partsSubtotal + laborSubtotal + suppliesSubtotal;
  const tps = subtotal * GST_RATE;
  const tvq = subtotal * QST_RATE;
  const total = subtotal + tps + tvq;

  const fmt = (n: number) => n.toLocaleString("fr-CA", { style: "currency", currency: "CAD" });

  const nextEstimateNumber = () => {
    const y = new Date().getFullYear();
    const n = estimates.length + 1;
    return `EST-${y}-${String(n).padStart(4, "0")}`;
  };

  // parts helpers
  const addPart = () => setParts((p) => [...p, { id: Date.now(), description: "", partNumber: "", qty: 1, unitPrice: 0 }]);
  const removePart = (id: number) => setParts((p) => p.filter((x) => x.id !== id));
  const updatePart = (id: number, field: string, value: string | number) =>
    setParts((p) => p.map((x) => (x.id === id ? { ...x, [field]: value } : x)));

  const addLabor = () => setLabor((l) => [...l, { id: Date.now(), description: "", hours: 0, rate: 110 }]);
  const removeLabor = (id: number) => setLabor((l) => l.filter((x) => x.id !== id));
  const updateLabor = (id: number, field: string, value: string | number) =>
    setLabor((l) => l.map((x) => (x.id === id ? { ...x, [field]: value } : x)));

  const addSupply = () => setSupplies((s) => [...s, { id: Date.now(), description: "", amount: 0 }]);
  const removeSupply = (id: number) => setSupplies((s) => s.filter((x) => x.id !== id));
  const updateSupply = (id: number, field: string, value: string | number) =>
    setSupplies((s) => s.map((x) => (x.id === id ? { ...x, [field]: value } : x)));

  // customer picker
  const filteredCustomers = (allCustomers ?? []).filter((c) => {
    if (!customerSearch) return true;
    const q = customerSearch.toLowerCase();
    return c.name.toLowerCase().includes(q) || (c.vehicleInfo ?? "").toLowerCase().includes(q);
  });
  const selectedCustomer = selectedCustomerId ? allCustomers?.find((c) => c.id === selectedCustomerId) : null;

  const handleSelectCustomer = (id: string) => {
    const c = allCustomers?.find((x) => x.id === id);
    if (!c) return;
    setSelectedCustomerId(id);
    setCustomerName(c.name);
    setPhone(c.phone ?? "");
    const vehicles = parseVehicles(
      typeof c.vehicles === "string" ? c.vehicles : JSON.stringify(c.vehicles),
      c.vehicleInfo ?? ""
    );
    setVehicleInfo(vehicles[0] ?? c.vehicleInfo ?? "");
    setShowCustomerPicker(false);
    setCustomerSearch("");
  };

  const resetForm = () => {
    setCustomerName(""); setPhone(""); setVehicleInfo(""); setPlate(""); setMileage("");
    setMechanic(""); setJobDesc(""); setNote(""); setStatus("Brouillon");
    setParts([{ id: 1, description: "", partNumber: "", qty: 1, unitPrice: 0 }]);
    setLabor([{ id: 1, description: "", hours: 0, rate: 110 }]);
    setSupplies([]);
    setSelectedCustomerId(null);
    setSaveMsg("");
    onPrefillConsumed?.();
    const d = new Date(); d.setDate(d.getDate() + 30);
    setValidUntil(d.toISOString().split("T")[0]);
  };

  const handleSave = () => {
    if (!customerName.trim()) { setSaveMsg("⚠ Entrez le nom du client."); return; }
    const num = nextEstimateNumber();
    const est: Estimate = {
      id: Date.now().toString(),
      estimateNumber: num,
      customerName: customerName.trim(),
      vehicleInfo: vehicleInfo.trim() || "—",
      phone, mechanic, jobDesc, plate, mileage,
      parts: parts.map((p) => ({ ...p })),
      labor: labor.map((l) => ({ ...l })),
      supplies: supplies.map((s) => ({ ...s })),
      subtotal, tps, tvq, total, status, validUntil, note,
      createdAt: new Date(),
    };
    const updated = [est, ...estimates];
    setEstimates(updated);
    saveEstimates(orgId, updated);
    setSaveMsg(`✓ Estimation ${num} enregistrée.`);
    setTimeout(() => { setActiveTab("list"); resetForm(); }, 800);
  };

  const handleDelete = (id: string) => {
    if (!confirm("Supprimer cette estimation ?")) return;
    const updated = estimates.filter((e) => e.id !== id);
    setEstimates(updated);
    saveEstimates(orgId, updated);
    if (selectedId === id) setSelectedId(null);
  };

  const handleUpdateStatus = (id: string, s: EstimateStatus) => {
    const updated = estimates.map((e) => (e.id === id ? { ...e, status: s } : e));
    setEstimates(updated);
    saveEstimates(orgId, updated);
  };

  const selectedEstimate = estimates.find((e) => e.id === selectedId) ?? null;

  const SectionHeader = ({
    label, icon, sectionKey, subtotalAmt,
  }: { label: string; icon: React.ReactNode; sectionKey: keyof typeof openSections; subtotalAmt?: number }) => (
    <button
      onClick={() => toggleSection(sectionKey)}
      className="w-full flex items-center justify-between py-3 px-1 group hover:bg-muted/40 rounded-md transition-all duration-150"
    >
      <div className="flex items-center gap-2">
        <span className="text-primary">{icon}</span>
        <span className="font-heading text-sm font-semibold tracking-wide uppercase text-muted-foreground">{label}</span>
      </div>
      <div className="flex items-center gap-3">
        {subtotalAmt !== undefined && (
          <span className="text-sm font-medium text-foreground">{fmt(subtotalAmt)}</span>
        )}
        <span className="text-muted-foreground">
          {openSections[sectionKey] ? <CaretUp size={14} weight="duotone" /> : <CaretDown size={14} weight="duotone" />}
        </span>
      </div>
    </button>
  );

  return (
    <section id="estimation" className="bg-background min-h-screen py-10 px-4 md:px-8">
      {/* Header */}
      <div className="max-w-6xl mx-auto mb-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="font-heading text-2xl font-bold text-foreground tracking-tight">
              Estimations
            </h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              Créez des soumissions détaillées pour vos clients — pièces, main-d&#39;œuvre &amp; taxes TPS/TVQ. Utilisez le{" "}
            <button
              onClick={() => {/* nav handled at App level */}}
              className="text-primary underline underline-offset-2 hover:opacity-80"
            >
              Catalogue de pièces
            </button>{" "}
            pour ajouter des pièces rapidement.
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              variant={activeTab === "new" ? "default" : "outline"}
              size="sm"
              onClick={() => { setActiveTab("new"); resetForm(); }}
              className={`rounded-lg text-sm gap-1.5 ${activeTab === "new" ? "bg-primary text-primary-foreground" : "border-border"}`}
            >
              <Plus size={14} weight="duotone" />
              Nouvelle estimation
            </Button>
            <Button
              variant={activeTab === "list" ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveTab("list")}
              className={`rounded-lg text-sm gap-1.5 ${activeTab === "list" ? "bg-primary text-primary-foreground" : "border-border"}`}
            >
              <List size={14} weight="duotone" />
              Toutes les estimations
            </Button>
          </div>
        </div>
      </div>

      {/* ── LIST TAB ── */}
      {activeTab === "list" && (
        <div className="max-w-6xl mx-auto">
          {estimates.length === 0 ? (
            <div className="text-center py-20 text-muted-foreground text-sm">
              <FileText size={36} weight="duotone" className="mx-auto mb-3 text-muted-foreground/40" />
              Aucune estimation. Cliquez sur « Nouvelle estimation » pour commencer.
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* List */}
              <div className="lg:col-span-2 space-y-2">
                {estimates.map((est) => (
                  <div
                    key={est.id}
                    onClick={() => setSelectedId(est.id === selectedId ? null : est.id)}
                    className={`flex items-center gap-4 px-4 py-3.5 rounded-xl border cursor-pointer transition-all group ${
                      selectedId === est.id
                        ? "border-primary/40 bg-primary/5 shadow-sm"
                        : "border-border bg-card hover:bg-muted/40"
                    }`}
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <span className="font-mono text-xs font-semibold text-foreground">{est.estimateNumber}</span>
                        <Badge className={`text-[10px] px-2 py-0 rounded-full border-0 ${statusColor[est.status]}`}>
                          {statusIcon[est.status]}{est.status}
                        </Badge>
                      </div>
                      <p className="text-sm font-medium text-foreground truncate">{est.customerName}</p>
                      <p className="text-xs text-muted-foreground truncate">{est.vehicleInfo}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-sm font-bold text-foreground">{fmt(est.total)}</p>
                      <p className="text-[10px] text-muted-foreground">
                        Valide jusqu&#39;au {new Date(est.validUntil).toLocaleDateString("fr-CA")}
                      </p>
                    </div>
                    <CaretRight
                      size={14}
                      weight="duotone"
                      className={`shrink-0 text-muted-foreground transition-transform ${selectedId === est.id ? "rotate-90 text-primary" : ""}`}
                    />
                  </div>
                ))}
              </div>

              {/* Detail panel */}
              <div className="lg:col-span-1">
                {selectedEstimate ? (
                  <div className="sticky top-6 space-y-4">
                    <Card className="rounded-xl shadow-md border border-border">
                      <CardHeader className="pb-2 pt-5 px-5">
                        <div className="flex items-center justify-between">
                          <CardTitle className="font-heading text-sm font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-2">
                            <Receipt size={15} weight="duotone" className="text-primary" />
                            {selectedEstimate.estimateNumber}
                          </CardTitle>
                          <button
                            onClick={() => handleDelete(selectedEstimate.id)}
                            className="text-muted-foreground hover:text-red-500 transition-colors"
                            title="Supprimer"
                          >
                            <Trash size={14} weight="duotone" />
                          </button>
                        </div>
                      </CardHeader>
                      <CardContent className="px-5 pb-5 space-y-1">
                        <div className="flex justify-between py-1 text-xs">
                          <span className="text-muted-foreground">Client</span>
                          <span className="font-medium text-foreground">{selectedEstimate.customerName}</span>
                        </div>
                        <div className="flex justify-between py-1 text-xs">
                          <span className="text-muted-foreground">Véhicule</span>
                          <span className="font-medium text-foreground truncate max-w-[130px] text-right">{selectedEstimate.vehicleInfo}</span>
                        </div>
                        {selectedEstimate.phone && (
                          <div className="flex justify-between py-1 text-xs">
                            <span className="text-muted-foreground">Téléphone</span>
                            <span className="font-medium text-foreground">{selectedEstimate.phone}</span>
                          </div>
                        )}
                        <Separator className="my-3" />
                        <div className="flex justify-between py-1 text-xs">
                          <span className="text-muted-foreground">Pièces</span>
                          <span className="font-medium text-foreground">{fmt(selectedEstimate.subtotal - selectedEstimate.labor.reduce((s, l) => s + l.hours * l.rate, 0) - selectedEstimate.supplies.reduce((s, s2) => s + s2.amount, 0))}</span>
                        </div>
                        <div className="flex justify-between py-1 text-xs">
                          <span className="text-muted-foreground">Main-d&#39;œuvre</span>
                          <span className="font-medium text-foreground">{fmt(selectedEstimate.labor.reduce((s, l) => s + l.hours * l.rate, 0))}</span>
                        </div>
                        <div className="flex justify-between py-1 text-xs">
                          <span className="text-muted-foreground">Fournitures</span>
                          <span className="font-medium text-foreground">{fmt(selectedEstimate.supplies.reduce((s, s2) => s + s2.amount, 0))}</span>
                        </div>
                        <Separator className="my-3" />
                        <div className="flex justify-between py-1 text-xs">
                          <span className="text-muted-foreground">Sous-total</span>
                          <span className="font-medium text-foreground">{fmt(selectedEstimate.subtotal)}</span>
                        </div>
                        <div className="flex justify-between py-1 text-xs">
                          <Badge className="text-[10px] px-1.5 py-0 rounded bg-muted text-muted-foreground font-normal">TPS 5%</Badge>
                          <span className="font-medium text-foreground">{fmt(selectedEstimate.tps)}</span>
                        </div>
                        <div className="flex justify-between py-1 text-xs">
                          <Badge className="text-[10px] px-1.5 py-0 rounded bg-muted text-muted-foreground font-normal">TVQ 9.975%</Badge>
                          <span className="font-medium text-foreground">{fmt(selectedEstimate.tvq)}</span>
                        </div>
                        <Separator className="my-3" />
                        <div className="flex justify-between py-2 px-1 rounded-lg bg-muted/40">
                          <span className="text-sm font-bold text-foreground font-heading">Total TTC</span>
                          <span className="text-sm font-bold text-foreground">{fmt(selectedEstimate.total)}</span>
                        </div>
                        <Separator className="my-3" />
                        <div className="space-y-1.5">
                          <p className="text-xs text-muted-foreground uppercase tracking-wide font-semibold">Statut</p>
                          <div className="flex flex-wrap gap-1.5">
                            {ALL_STATUSES.map((s) => (
                              <button
                                key={s}
                                onClick={() => handleUpdateStatus(selectedEstimate.id, s)}
                                className={`px-2.5 py-1 rounded-full text-[10px] font-medium border transition-all ${
                                  selectedEstimate.status === s
                                    ? `${statusColor[s]} border-transparent`
                                    : "bg-background border-border text-muted-foreground hover:bg-muted"
                                }`}
                              >
                                {s}
                              </button>
                            ))}
                          </div>
                        </div>
                        {selectedEstimate.note && (
                          <>
                            <Separator className="my-3" />
                            <p className="text-xs text-muted-foreground uppercase tracking-wide font-semibold mb-1">Note</p>
                            <p className="text-xs text-foreground">{selectedEstimate.note}</p>
                          </>
                        )}
                        {onCreateInvoice && (
                          <>
                            <Separator className="my-3" />
                            <button
                              onClick={() => {
                                onCreateInvoice({
                                  customerName: selectedEstimate.customerName,
                                  phone: selectedEstimate.phone,
                                  vehicleInfo: selectedEstimate.vehicleInfo,
                                  parts: selectedEstimate.parts.map((p) => ({ ...p })),
                                  labor: selectedEstimate.labor.map((l) => ({ ...l })),
                                  supplies: selectedEstimate.supplies.map((s) => ({ ...s })),
                                  sourceEstimateNumber: selectedEstimate.estimateNumber,
                                });
                              }}
                              className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 transition-opacity"
                            >
                              <Invoice size={14} weight="duotone" />
                              Créer une facture
                            </button>
                          </>
                        )}
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-48 text-center text-muted-foreground text-xs px-4">
                    <FileText size={28} weight="duotone" className="mb-2 text-muted-foreground/40" />
                    Sélectionnez une estimation pour voir les détails.
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── NEW ESTIMATION TAB ── */}
      {activeTab === "new" && (
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main form */}
            <div className="lg:col-span-2 space-y-4">

              {/* 1. Client */}
              <Card className="rounded-xl shadow-sm border border-border">
                <CardContent className="p-5">
                  <SectionHeader label="Client &amp; Description" icon={<User size={16} weight="duotone" />} sectionKey="customer" />
                  {openSections.customer && (
                    <>
                      <Separator className="mb-4" />

                      {/* Customer quick-pick */}
                      <div className="mb-4">
                        <div className="flex items-center justify-between mb-2">
                          <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                            Choisir un client enregistré
                          </Label>
                          {selectedCustomer && (
                            <button
                              type="button"
                              onClick={() => { setSelectedCustomerId(null); setCustomerName(""); setPhone(""); setVehicleInfo(""); }}
                              className="text-[11px] text-muted-foreground hover:text-foreground flex items-center gap-0.5"
                            >
                              <X size={10} weight="bold" /> Effacer
                            </button>
                          )}
                        </div>
                        {selectedCustomer ? (
                          <div className="flex items-center gap-3 px-3 py-2.5 rounded-lg border border-primary/40 bg-primary/5">
                            <div className="w-7 h-7 rounded-full bg-primary/15 flex items-center justify-center shrink-0">
                              <User size={13} weight="duotone" className="text-primary" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-semibold text-foreground truncate">{selectedCustomer.name}</p>
                              <p className="text-[11px] text-muted-foreground">{selectedCustomer.phone ?? ""}</p>
                            </div>
                            <button
                              type="button"
                              onClick={() => setShowCustomerPicker(!showCustomerPicker)}
                              className="text-xs text-primary hover:underline flex items-center gap-0.5 shrink-0"
                            >
                              Changer <CaretRight size={11} weight="bold" />
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setShowCustomerPicker(!showCustomerPicker)}
                            className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg border border-dashed border-border bg-background hover:bg-muted text-xs text-muted-foreground transition-all"
                          >
                            <span className="flex items-center gap-2">
                              <User size={13} weight="duotone" />
                              Sélectionner un client existant…
                            </span>
                            <CaretDown size={12} weight="duotone" />
                          </button>
                        )}
                        {showCustomerPicker && (
                          <div className="mt-2 rounded-xl border border-border bg-card shadow-lg overflow-hidden z-10">
                            <div className="p-2 border-b border-border">
                              <Input
                                value={customerSearch}
                                onChange={(e) => setCustomerSearch(e.target.value)}
                                placeholder="Rechercher…"
                                className="h-7 text-xs rounded-md border-border"
                                autoFocus
                              />
                            </div>
                            <div className="max-h-48 overflow-y-auto">
                              {filteredCustomers.length === 0 ? (
                                <p className="text-xs text-muted-foreground text-center py-4">Aucun client trouvé.</p>
                              ) : filteredCustomers.map((c) => (
                                <button
                                  key={c.id}
                                  type="button"
                                  onClick={() => handleSelectCustomer(c.id)}
                                  className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-muted transition-colors text-left"
                                >
                                  <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                                    <User size={11} weight="duotone" className="text-primary" />
                                  </div>
                                  <div className="min-w-0 flex-1">
                                    <p className="text-xs font-medium text-foreground truncate">{c.name}</p>
                                    <p className="text-[10px] text-muted-foreground truncate">{c.vehicleInfo}</p>
                                  </div>
                                  {selectedCustomerId === c.id && (
                                    <CheckCircle size={13} weight="fill" className="text-primary shrink-0" />
                                  )}
                                </button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>

                      <Separator className="mb-4" />

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-1.5">
                          <Label className="text-xs text-muted-foreground uppercase tracking-wide">Nom du client</Label>
                          <Input value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder="Martin Tremblay" className="rounded-lg border-border text-sm" />
                        </div>
                        <div className="space-y-1.5">
                          <Label className="text-xs text-muted-foreground uppercase tracking-wide">Téléphone</Label>
                          <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="(418) 555-0192" className="rounded-lg border-border text-sm" />
                        </div>
                        <div className="space-y-1.5">
                          <Label className="text-xs text-muted-foreground uppercase tracking-wide">Véhicule</Label>
                          <div className="flex items-center gap-2">
                            <Car size={15} weight="duotone" className="text-muted-foreground shrink-0" />
                            <Input value={vehicleInfo} onChange={(e) => setVehicleInfo(e.target.value)} placeholder="2019 Honda Civic EX" className="rounded-lg border-border text-sm" />
                          </div>
                        </div>
                        <div className="space-y-1.5">
                          <Label className="text-xs text-muted-foreground uppercase tracking-wide">Plaque / VIN</Label>
                          <Input value={plate} onChange={(e) => setPlate(e.target.value)} placeholder="ABC-1234" className="rounded-lg border-border text-sm" />
                        </div>
                        <div className="space-y-1.5">
                          <Label className="text-xs text-muted-foreground uppercase tracking-wide">Kilométrage</Label>
                          <Input value={mileage} onChange={(e) => setMileage(e.target.value)} placeholder="87 450 km" className="rounded-lg border-border text-sm" />
                        </div>
                        <div className="space-y-1.5">
                          <Label className="text-xs text-muted-foreground uppercase tracking-wide">Mécanicien assigné</Label>
                          <Input value={mechanic} onChange={(e) => setMechanic(e.target.value)} placeholder="Jean-François Côté" className="rounded-lg border-border text-sm" />
                        </div>
                        <div className="space-y-1.5 sm:col-span-2">
                          <Label className="text-xs text-muted-foreground uppercase tracking-wide">Description des travaux</Label>
                          <Input value={jobDesc} onChange={(e) => setJobDesc(e.target.value)} placeholder="Ex. : Inspection freins avant + remplacement plaquettes" className="rounded-lg border-border text-sm" />
                        </div>
                        <div className="space-y-1.5">
                          <Label className="text-xs text-muted-foreground uppercase tracking-wide">Valide jusqu&#39;au</Label>
                          <Input type="date" value={validUntil} onChange={(e) => setValidUntil(e.target.value)} className="rounded-lg border-border text-sm" />
                        </div>
                        <div className="space-y-1.5">
                          <Label className="text-xs text-muted-foreground uppercase tracking-wide">Statut</Label>
                          <div className="flex flex-wrap gap-2">
                            {ALL_STATUSES.map((s) => (
                              <button
                                key={s}
                                type="button"
                                onClick={() => setStatus(s)}
                                className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                                  status === s
                                    ? "bg-primary text-primary-foreground border-primary"
                                    : "bg-background text-muted-foreground border-border hover:bg-muted"
                                }`}
                              >
                                {s}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              {/* 2. Parts */}
              <Card className="rounded-xl shadow-sm border border-border">
                <CardContent className="p-5">
                  <SectionHeader label="Pièces" icon={<Package size={16} weight="duotone" />} sectionKey="parts" subtotalAmt={partsSubtotal} />
                  {openSections.parts && (
                    <>
                      <Separator className="mb-4" />
                      <div className="hidden sm:grid grid-cols-12 gap-2 mb-2 px-1">
                        <span className="col-span-5 text-xs text-muted-foreground uppercase tracking-wide">Description</span>
                        <span className="col-span-2 text-xs text-muted-foreground uppercase tracking-wide">N° pièce</span>
                        <span className="col-span-1 text-xs text-muted-foreground uppercase tracking-wide text-center">Qté</span>
                        <span className="col-span-2 text-xs text-muted-foreground uppercase tracking-wide text-right">Prix unit.</span>
                        <span className="col-span-2 text-xs text-muted-foreground uppercase tracking-wide text-right">Total</span>
                      </div>
                      <div className="space-y-2">
                        {parts.map((part) => (
                          <div key={part.id} className="grid grid-cols-12 gap-2 items-center p-2 rounded-lg hover:bg-muted/30 group">
                            <div className="col-span-12 sm:col-span-5">
                              <Input value={part.description} onChange={(e) => updatePart(part.id, "description", e.target.value)} placeholder="Description" className="rounded-md border-border text-sm h-8" />
                            </div>
                            <div className="col-span-6 sm:col-span-2">
                              <Input value={part.partNumber} onChange={(e) => updatePart(part.id, "partNumber", e.target.value)} placeholder="N° pièce" className="rounded-md border-border text-sm h-8" />
                            </div>
                            <div className="col-span-2 sm:col-span-1">
                              <Input type="number" value={part.qty} onChange={(e) => updatePart(part.id, "qty", parseFloat(e.target.value) || 0)} className="rounded-md border-border text-sm h-8 text-center" />
                            </div>
                            <div className="col-span-4 sm:col-span-2">
                              <Input type="number" value={part.unitPrice} onChange={(e) => updatePart(part.id, "unitPrice", parseFloat(e.target.value) || 0)} className="rounded-md border-border text-sm h-8 text-right" />
                            </div>
                            <div className="col-span-10 sm:col-span-2 text-right">
                              <span className="text-sm font-medium text-foreground">{fmt(part.qty * part.unitPrice)}</span>
                            </div>
                            <div className="col-span-2 flex justify-end">
                              <button onClick={() => removePart(part.id)} className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-foreground transition-all">
                                <Trash size={14} weight="duotone" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                      <button onClick={addPart} className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors">
                        <Plus size={13} weight="duotone" /> Ajouter une pièce
                      </button>
                      <Separator className="mt-4 mb-2" />
                      <div className="flex justify-end">
                        <span className="text-sm text-muted-foreground mr-4">Sous-total pièces</span>
                        <span className="text-sm font-semibold text-foreground">{fmt(partsSubtotal)}</span>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              {/* 3. Labor */}
              <Card className="rounded-xl shadow-sm border border-border">
                <CardContent className="p-5">
                  <SectionHeader label="Main-d'œuvre" icon={<Wrench size={16} weight="duotone" />} sectionKey="labor" subtotalAmt={laborSubtotal} />
                  {openSections.labor && (
                    <>
                      <Separator className="mb-4" />
                      <div className="hidden sm:grid grid-cols-12 gap-2 mb-2 px-1">
                        <span className="col-span-6 text-xs text-muted-foreground uppercase tracking-wide">Description</span>
                        <span className="col-span-2 text-xs text-muted-foreground uppercase tracking-wide text-center">Heures</span>
                        <span className="col-span-2 text-xs text-muted-foreground uppercase tracking-wide text-right">Taux/h</span>
                        <span className="col-span-2 text-xs text-muted-foreground uppercase tracking-wide text-right">Total</span>
                      </div>
                      <div className="space-y-2">
                        {labor.map((entry) => (
                          <div key={entry.id} className="grid grid-cols-12 gap-2 items-center p-2 rounded-lg hover:bg-muted/30 group">
                            <div className="col-span-12 sm:col-span-6">
                              <Input value={entry.description} onChange={(e) => updateLabor(entry.id, "description", e.target.value)} placeholder="Description" className="rounded-md border-border text-sm h-8" />
                            </div>
                            <div className="col-span-4 sm:col-span-2">
                              <Input type="number" value={entry.hours} onChange={(e) => updateLabor(entry.id, "hours", parseFloat(e.target.value) || 0)} className="rounded-md border-border text-sm h-8 text-center" />
                            </div>
                            <div className="col-span-4 sm:col-span-2">
                              <Input type="number" value={entry.rate} onChange={(e) => updateLabor(entry.id, "rate", parseFloat(e.target.value) || 0)} className="rounded-md border-border text-sm h-8 text-right" />
                            </div>
                            <div className="col-span-3 sm:col-span-2 text-right">
                              <span className="text-sm font-medium text-foreground">{fmt(entry.hours * entry.rate)}</span>
                            </div>
                            <div className="col-span-1 flex justify-end">
                              <button onClick={() => removeLabor(entry.id)} className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-foreground transition-all">
                                <Trash size={14} weight="duotone" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                      <button onClick={addLabor} className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors">
                        <Plus size={13} weight="duotone" /> Ajouter une entrée
                      </button>
                      <Separator className="mt-4 mb-2" />
                      <div className="flex justify-end">
                        <span className="text-sm text-muted-foreground mr-4">Sous-total main-d&#39;œuvre</span>
                        <span className="text-sm font-semibold text-foreground">{fmt(laborSubtotal)}</span>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              {/* 4. Supplies */}
              <Card className="rounded-xl shadow-sm border border-border">
                <CardContent className="p-5">
                  <SectionHeader label="Fournitures d'atelier" icon={<Drop size={16} weight="duotone" />} sectionKey="supplies" subtotalAmt={suppliesSubtotal} />
                  {openSections.supplies && (
                    <>
                      <Separator className="mb-4" />
                      <div className="space-y-2">
                        {supplies.map((supply) => (
                          <div key={supply.id} className="grid grid-cols-12 gap-2 items-center p-2 rounded-lg hover:bg-muted/30 group">
                            <div className="col-span-9 sm:col-span-10">
                              <Input value={supply.description} onChange={(e) => updateSupply(supply.id, "description", e.target.value)} placeholder="Description" className="rounded-md border-border text-sm h-8" />
                            </div>
                            <div className="col-span-2">
                              <Input type="number" value={supply.amount} onChange={(e) => updateSupply(supply.id, "amount", parseFloat(e.target.value) || 0)} className="rounded-md border-border text-sm h-8 text-right" />
                            </div>
                            <div className="col-span-1 flex justify-end">
                              <button onClick={() => removeSupply(supply.id)} className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-foreground transition-all">
                                <Trash size={14} weight="duotone" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                      <button onClick={addSupply} className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors">
                        <Plus size={13} weight="duotone" /> Ajouter une fourniture
                      </button>
                    </>
                  )}
                </CardContent>
              </Card>

              {/* 5. Taxes summary */}
              <Card className="rounded-xl shadow-sm border border-border">
                <CardContent className="p-5">
                  <SectionHeader label="Taxes (Québec)" icon={<Calculator size={16} weight="duotone" />} sectionKey="taxes" />
                  {openSections.taxes && (
                    <>
                      <Separator className="mb-4" />
                      <div className="space-y-1">
                        <div className="flex items-center justify-between py-2.5 px-3 rounded-lg hover:bg-muted/30">
                          <span className="text-sm text-foreground font-medium">Sous-total avant taxes</span>
                          <span className="text-sm font-semibold text-foreground">{fmt(subtotal)}</span>
                        </div>
                        <Separator />
                        <div className="flex items-center justify-between py-2.5 px-3 rounded-lg hover:bg-muted/30">
                          <div>
                            <p className="text-sm text-foreground">TPS — Taxe sur les produits et services</p>
                            <p className="text-xs text-muted-foreground">Taux : 5,00 %</p>
                          </div>
                          <span className="text-sm font-semibold text-foreground">{fmt(tps)}</span>
                        </div>
                        <Separator />
                        <div className="flex items-center justify-between py-2.5 px-3 rounded-lg hover:bg-muted/30">
                          <div>
                            <p className="text-sm text-foreground">TVQ — Taxe de vente du Québec</p>
                            <p className="text-xs text-muted-foreground">Taux : 9,975 %</p>
                          </div>
                          <span className="text-sm font-semibold text-foreground">{fmt(tvq)}</span>
                        </div>
                        <Separator />
                        <div className="flex items-center justify-between py-3 px-3 rounded-lg bg-muted/40">
                          <span className="text-base font-bold text-foreground font-heading">Total TTC</span>
                          <span className="text-base font-bold text-foreground">{fmt(total)}</span>
                        </div>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              {/* Note interne */}
              <Card className="rounded-xl shadow-sm border border-border">
                <CardContent className="p-5">
                  <p className="text-xs text-muted-foreground uppercase tracking-wide font-semibold mb-3">Note interne</p>
                  <textarea
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    className="w-full text-xs text-foreground bg-background border border-border rounded-lg p-2 resize-none focus:outline-none focus:ring-1 focus:ring-ring"
                    rows={3}
                    placeholder="Ajouter une note pour cette estimation…"
                  />
                </CardContent>
              </Card>

              {/* Save */}
              <div className="pb-10">
                {saveMsg && (
                  <p className={`text-xs mb-3 ${saveMsg.startsWith("✓") ? "text-green-600" : "text-red-500"}`}>
                    {saveMsg}
                  </p>
                )}
                <Button
                  onClick={handleSave}
                  className="w-full bg-primary text-primary-foreground rounded-lg text-sm font-medium shadow-sm"
                >
                  <FloppyDisk size={15} weight="duotone" className="mr-2" />
                  Enregistrer l&#39;estimation
                </Button>
              </div>
            </div>

            {/* Sticky summary */}
            <div className="lg:col-span-1">
              <div className="sticky top-6">
                <Card className="rounded-xl shadow-md border border-border">
                  <CardHeader className="pb-2 pt-5 px-5">
                    <CardTitle className="font-heading text-sm font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-2">
                      <Receipt size={15} weight="duotone" className="text-primary" />
                      Sommaire
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="px-5 pb-5 space-y-1">
                    <div className="flex justify-between py-1.5 text-xs text-muted-foreground">
                      <span>Client</span>
                      <span className="font-medium text-foreground truncate max-w-[140px] text-right">{customerName || "—"}</span>
                    </div>
                    <div className="flex justify-between py-1.5 text-xs text-muted-foreground">
                      <span>Véhicule</span>
                      <span className="font-medium text-foreground truncate max-w-[140px] text-right">{vehicleInfo || "—"}</span>
                    </div>
                    <Separator className="my-3" />
                    <div className="flex justify-between py-1.5">
                      <span className="text-xs text-muted-foreground">Pièces</span>
                      <span className="text-xs font-medium text-foreground">{fmt(partsSubtotal)}</span>
                    </div>
                    <div className="flex justify-between py-1.5">
                      <span className="text-xs text-muted-foreground">Main-d&#39;œuvre</span>
                      <span className="text-xs font-medium text-foreground">{fmt(laborSubtotal)}</span>
                    </div>
                    <div className="flex justify-between py-1.5">
                      <span className="text-xs text-muted-foreground">Fournitures</span>
                      <span className="text-xs font-medium text-foreground">{fmt(suppliesSubtotal)}</span>
                    </div>
                    <Separator className="my-3" />
                    <div className="flex justify-between py-1.5">
                      <span className="text-xs text-muted-foreground">Sous-total</span>
                      <span className="text-xs font-medium text-foreground">{fmt(subtotal)}</span>
                    </div>
                    <div className="flex justify-between py-1.5">
                      <Badge className="text-xs px-1.5 py-0 rounded bg-muted text-muted-foreground font-normal">TPS 5%</Badge>
                      <span className="text-xs font-medium text-foreground">{fmt(tps)}</span>
                    </div>
                    <div className="flex justify-between py-1.5">
                      <Badge className="text-xs px-1.5 py-0 rounded bg-muted text-muted-foreground font-normal">TVQ 9.975%</Badge>
                      <span className="text-xs font-medium text-foreground">{fmt(tvq)}</span>
                    </div>
                    <Separator className="my-3" />
                    <div className="flex justify-between py-2 px-1 rounded-lg bg-muted/40">
                      <span className="text-sm font-bold text-foreground font-heading">Total TTC</span>
                      <span className="text-sm font-bold text-foreground">{fmt(total)}</span>
                    </div>
                    <Separator className="my-3" />
                    <div className="flex justify-between py-1.5">
                      <span className="text-xs text-muted-foreground">Valide jusqu&#39;au</span>
                      <span className="text-xs font-medium text-foreground">
                        {validUntil ? new Date(validUntil).toLocaleDateString("fr-CA") : "—"}
                      </span>
                    </div>
                    <div className="flex justify-between py-1.5">
                      <span className="text-xs text-muted-foreground">Statut</span>
                      <Badge className={`text-[10px] px-2 py-0.5 rounded-full border-0 ${statusColor[status]}`}>
                        {statusIcon[status]}{status}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
