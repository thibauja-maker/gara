import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import {
  Globe,
  ArrowSquareOut,
  CheckCircle,
  Clock,
  Plus,
  Trash,
  Copy,
  Eye,
  EyeSlash,
  Gear,
  Lightning,
  ShoppingCart,
  Star,
  Car,
  Wrench,
  X,
  FacebookLogo,
} from "@phosphor-icons/react";

type Integration = {
  id: string;
  name: string;
  description: string;
  category: string;
  icon: string;
  status: "connected" | "available" | "coming_soon";
  url?: string;
  apiKey?: string;
  color: string;
};

const INTEGRATIONS: Integration[] = [
  {
    id: "partssource",
    name: "PartsSource",
    description: "Commandez des pièces auto directement depuis votre compte PartsSource.",
    category: "Pièces",
    icon: "🔩",
    status: "available",
    url: "https://www.partssource.com",
    color: "from-blue-500 to-blue-700",
  },
  {
    id: "napa",
    name: "NAPA Auto Parts",
    description: "Intégration NAPA pour la commande et la vérification du stock en temps réel.",
    category: "Pièces",
    icon: "🚗",
    status: "available",
    url: "https://www.napacanada.com",
    color: "from-yellow-500 to-orange-600",
  },
  {
    id: "rockauto",
    name: "RockAuto",
    description: "Accès direct au catalogue RockAuto pour consulter les prix et disponibilités.",
    category: "Pièces",
    icon: "🪨",
    status: "available",
    url: "https://www.rockauto.com",
    color: "from-red-500 to-red-700",
  },
  {
    id: "carfax",
    name: "CARFAX Canada",
    description: "Vérifiez l\'historique d\'un véhicule par numéro VIN directement dans l\'application.",
    category: "Véhicules",
    icon: "📋",
    status: "available",
    url: "https://www.carfaxcanada.ca",
    color: "from-green-500 to-green-700",
  },
  {
    id: "google_reviews",
    name: "Google Business",
    description: "Envoyez automatiquement une demande d\'avis Google après chaque facture payée.",
    category: "Marketing",
    icon: "⭐",
    status: "available",
    url: "https://business.google.com",
    color: "from-blue-400 to-indigo-600",
  },
  {
    id: "quickbooks",
    name: "QuickBooks",
    description: "Synchronisez vos factures et paiements automatiquement avec QuickBooks.",
    category: "Comptabilité",
    icon: "📊",
    status: "coming_soon",
    color: "from-emerald-500 to-teal-600",
  },
  {
    id: "mitchell1",
    name: "Mitchell 1",
    description: "Accédez aux données techniques et aux estimations de réparation Mitchell 1.",
    category: "Technique",
    icon: "🔧",
    status: "coming_soon",
    color: "from-slate-500 to-slate-700",
  },
  {
    id: "sms_twilio",
    name: "SMS Client (Twilio)",
    description: "Envoyez des confirmations de RDV et rappels par SMS à vos clients.",
    category: "Communication",
    icon: "💬",
    status: "available",
    color: "from-pink-500 to-rose-600",
  },
  {
    id: "stripe",
    name: "Stripe Paiements",
    description: "Acceptez les paiements en ligne et par lien de paiement sécurisé.",
    category: "Paiements",
    icon: "💳",
    status: "coming_soon",
    color: "from-violet-500 to-purple-700",
  },
  {
    id: "tirecraft",
    name: "Tirecraft / OK Tire",
    description: "Vérifiez la disponibilité et les prix des pneus chez les distributeurs canadiens.",
    category: "Pièces",
    icon: "⭕",
    status: "available",
    url: "https://www.tirecraft.com",
    color: "from-zinc-600 to-zinc-800",
  },
];

// Lien vers la page Facebook de l'atelier — à mettre à jour avec l'URL réelle
const FACEBOOK_PAGE_URL = "https://www.facebook.com/votrepageatelier";

const CATEGORIES = ["Tous", "Pièces", "Véhicules", "Marketing", "Comptabilité", "Technique", "Communication", "Paiements"];

const categoryIcon: Record<string, React.ReactNode> = {
  Pièces: <Wrench size={12} weight="duotone" />,
  Véhicules: <Car size={12} weight="duotone" />,
  Marketing: <Star size={12} weight="duotone" />,
  Comptabilité: <ShoppingCart size={12} weight="duotone" />,
  Technique: <Gear size={12} weight="duotone" />,
  Communication: <Lightning size={12} weight="duotone" />,
  Paiements: <Globe size={12} weight="duotone" />,
};

type ConnectedInteg = {
  id: string;
  apiKey: string;
  webhookUrl?: string;
  connectedAt: string;
};

export default function Integrations({ orgId }: { orgId: string }) {
  const [activeCategory, setActiveCategory] = useState("Tous");
  const [search, setSearch] = useState("");
  const [configuringId, setConfiguringId] = useState<string | null>(null);
  const [connected, setConnected] = useState<ConnectedInteg[]>([]);
  const [apiKeyInput, setApiKeyInput] = useState("");
  const [webhookInput, setWebhookInput] = useState("");
  const [showApiKey, setShowApiKey] = useState<Record<string, boolean>>({});
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [customWebhooks, setCustomWebhooks] = useState<{ id: string; label: string; url: string }[]>([]);
  const [newWebhookLabel, setNewWebhookLabel] = useState("");
  const [newWebhookUrl, setNewWebhookUrl] = useState("");
  const [showAddWebhook, setShowAddWebhook] = useState(false);

  const filtered = INTEGRATIONS.filter((integ) => {
    const matchCat = activeCategory === "Tous" || integ.category === activeCategory;
    const matchSearch = !search || integ.name.toLowerCase().includes(search.toLowerCase()) || integ.description.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const isConnected = (id: string) => connected.some((c) => c.id === id);

  const handleConnect = (integ: Integration) => {
    if (integ.status === "coming_soon") return;
    setConfiguringId(integ.id);
    setApiKeyInput("");
    setWebhookInput("");
  };

  const handleSaveConnection = (id: string) => {
    if (!apiKeyInput.trim()) return;
    setConnected((prev) => [
      ...prev.filter((c) => c.id !== id),
      { id, apiKey: apiKeyInput, webhookUrl: webhookInput || undefined, connectedAt: new Date().toLocaleDateString("fr-CA") },
    ]);
    setConfiguringId(null);
    setSuccessMsg(`Intégration connectée avec succès.`);
    setTimeout(() => setSuccessMsg(null), 3500);
  };

  const handleDisconnect = (id: string) => {
    setConnected((prev) => prev.filter((c) => c.id !== id));
  };

  const handleAddWebhook = () => {
    if (!newWebhookLabel.trim() || !newWebhookUrl.trim()) return;
    setCustomWebhooks((prev) => [...prev, { id: String(Date.now()), label: newWebhookLabel, url: newWebhookUrl }]);
    setNewWebhookLabel("");
    setNewWebhookUrl("");
    setShowAddWebhook(false);
  };

  const connectedItems = INTEGRATIONS.filter((i) => isConnected(i.id));
  const statsConnected = connectedItems.length;
  const statsAvailable = INTEGRATIONS.filter((i) => i.status === "available").length - statsConnected;

  return (
    <section id="integrations" className="bg-background min-h-screen py-10 px-4 md:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <p className="text-xs font-mono tracking-widest text-muted-foreground uppercase mb-1">
            Intégrations
          </p>
          <h1 className="font-heading text-2xl font-semibold text-foreground tracking-tight">
            Connexions &amp; Intégrations web
          </h1>
          <p className="text-sm text-muted-foreground mt-1 max-w-xl">
            Connectez GarageManager à vos fournisseurs, outils de comptabilité, et services de communication pour automatiser votre atelier.
          </p>
          <div className="mt-4 h-px bg-border w-full" />
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          <Card className="rounded-xl border border-border shadow-sm">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                <CheckCircle size={18} weight="duotone" className="text-primary" />
              </div>
              <div>
                <p className="text-xl font-bold text-foreground font-heading">{statsConnected}</p>
                <p className="text-xs text-muted-foreground">Connectées</p>
              </div>
            </CardContent>
          </Card>
          <Card className="rounded-xl border border-border shadow-sm">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-blue-500/10 flex items-center justify-center shrink-0">
                <Globe size={18} weight="duotone" className="text-blue-500" />
              </div>
              <div>
                <p className="text-xl font-bold text-foreground font-heading">{statsAvailable}</p>
                <p className="text-xs text-muted-foreground">Disponibles</p>
              </div>
            </CardContent>
          </Card>
          <Card className="rounded-xl border border-border shadow-sm">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-muted flex items-center justify-center shrink-0">
                <Clock size={18} weight="duotone" className="text-muted-foreground" />
              </div>
              <div>
                <p className="text-xl font-bold text-foreground font-heading">
                  {INTEGRATIONS.filter((i) => i.status === "coming_soon").length}
                </p>
                <p className="text-xs text-muted-foreground">Bientôt</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Success banner */}
        {successMsg && (
          <div className="mb-4 flex items-center gap-2 px-4 py-3 rounded-xl border border-green-500/30 bg-green-500/10 text-green-600 text-sm">
            <CheckCircle size={15} weight="duotone" />
            {successMsg}
          </div>
        )}

        {/* Active connections */}
        {connectedItems.length > 0 && (
          <div className="mb-8">
            <h2 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
              <CheckCircle size={15} weight="duotone" className="text-primary" />
              Connexions actives
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {connectedItems.map((integ) => {
                const conn = connected.find((c) => c.id === integ.id);
                return (
                  <Card key={integ.id} className="rounded-xl border border-primary/30 bg-primary/5 shadow-sm">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="text-xl">{integ.icon}</span>
                          <div>
                            <p className="text-sm font-semibold text-foreground">{integ.name}</p>
                            <p className="text-[10px] text-muted-foreground">Connecté le {conn?.connectedAt}</p>
                          </div>
                        </div>
                        <Badge className="bg-primary/15 text-primary border-0 text-[10px] px-2 py-0.5 shrink-0">
                          Actif
                        </Badge>
                      </div>
                      <div className="mt-3 flex items-center gap-2">
                        {integ.url && (
                          <a
                            href={integ.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-1 text-[11px] text-primary hover:underline"
                          >
                            Ouvrir <ArrowSquareOut size={10} />
                          </a>
                        )}
                        <button
                          onClick={() => handleDisconnect(integ.id)}
                          className="flex items-center gap-1 text-[11px] text-red-500 hover:underline ml-auto"
                        >
                          <X size={10} weight="bold" /> Déconnecter
                        </button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        )}

        {/* Search + filter */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 mb-6">
          <div className="relative flex-1 max-w-sm">
            <Globe size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Rechercher une intégration…"
              className="pl-8 h-8 text-sm border-border rounded-lg"
            />
          </div>
          <div className="flex flex-wrap gap-1.5">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border transition-all ${
                  activeCategory === cat
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-background border-border text-muted-foreground hover:bg-muted"
                }`}
              >
                {cat !== "Tous" && <span className="opacity-70">{categoryIcon[cat]}</span>}
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Integration grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-10">
          {filtered.map((integ) => {
            const connected_ = isConnected(integ.id);
            const configuring_ = configuringId === integ.id;

            return (
              <Card
                key={integ.id}
                className={`rounded-xl border shadow-sm transition-all duration-200 hover:shadow-md ${
                  connected_ ? "border-primary/30" : "border-border"
                } ${integ.status === "coming_soon" ? "opacity-60" : ""}`}
              >
                <CardContent className="p-5">
                  {/* Top row */}
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${integ.color} flex items-center justify-center text-xl shadow-sm`}>
                        {integ.icon}
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-foreground leading-tight">{integ.name}</p>
                        <span className="text-[10px] text-muted-foreground">{integ.category}</span>
                      </div>
                    </div>
                    <Badge
                      className={`text-[10px] px-2 py-0.5 border-0 shrink-0 ${
                        connected_ ? "bg-primary/15 text-primary" :
                        integ.status === "coming_soon" ? "bg-muted text-muted-foreground" :
                        "bg-blue-500/10 text-blue-600"
                      }`}
                    >
                      {connected_ ? "Connecté" : integ.status === "coming_soon" ? "Bientôt" : "Disponible"}
                    </Badge>
                  </div>

                  <p className="text-xs text-muted-foreground leading-relaxed mb-4">
                    {integ.description}
                  </p>

                  {/* Config form */}
                  {configuring_ && !connected_ && (
                    <div className="mb-4 p-3 rounded-lg bg-muted/40 border border-border space-y-3">
                      <div>
                        <Label className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1 block">
                          Clé API / Token d&#39;accès
                        </Label>
                        <div className="flex items-center gap-2">
                          <Input
                            type={showApiKey[integ.id] ? "text" : "password"}
                            value={apiKeyInput}
                            onChange={(e) => setApiKeyInput(e.target.value)}
                            placeholder="sk_live_…"
                            className="h-7 text-xs rounded-md border-border flex-1"
                            autoFocus
                          />
                          <button
                            type="button"
                            onClick={() => setShowApiKey((p) => ({ ...p, [integ.id]: !p[integ.id] }))}
                            className="text-muted-foreground hover:text-foreground"
                          >
                            {showApiKey[integ.id] ? <EyeSlash size={13} /> : <Eye size={13} />}
                          </button>
                        </div>
                      </div>
                      <div>
                        <Label className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1 block">
                          URL Webhook (optionnel)
                        </Label>
                        <Input
                          type="url"
                          value={webhookInput}
                          onChange={(e) => setWebhookInput(e.target.value)}
                          placeholder="https://votresite.com/webhook"
                          className="h-7 text-xs rounded-md border-border"
                        />
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleSaveConnection(integ.id)}
                          className="flex-1 text-xs bg-primary text-primary-foreground rounded-md px-3 py-1.5 font-medium hover:opacity-90 transition-opacity"
                        >
                          Sauvegarder
                        </button>
                        <button
                          onClick={() => setConfiguringId(null)}
                          className="text-xs text-muted-foreground hover:text-foreground px-2 py-1.5"
                        >
                          Annuler
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex items-center gap-2">
                    {connected_ ? (
                      <>
                        {integ.url && (
                          <a
                            href={integ.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex-1 flex items-center justify-center gap-1.5 text-xs border border-border rounded-lg py-1.5 text-foreground hover:bg-muted transition-colors"
                          >
                            Ouvrir <ArrowSquareOut size={11} />
                          </a>
                        )}
                        <button
                          onClick={() => handleDisconnect(integ.id)}
                          className="flex items-center gap-1 text-xs text-red-500 hover:bg-red-500/10 rounded-lg px-2 py-1.5 transition-colors"
                        >
                          <Trash size={12} /> Déconnecter
                        </button>
                      </>
                    ) : integ.status === "coming_soon" ? (
                      <div className="flex-1 flex items-center justify-center gap-1.5 text-xs border border-dashed border-border rounded-lg py-1.5 text-muted-foreground cursor-not-allowed">
                        <Clock size={12} /> Bientôt disponible
                      </div>
                    ) : (
                      <>
                        {integ.url && (
                          <a
                            href={integ.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground border border-border rounded-lg px-2 py-1.5 transition-colors"
                            title="Ouvrir le site"
                          >
                            <ArrowSquareOut size={11} />
                          </a>
                        )}
                        <button
                          onClick={() => handleConnect(integ)}
                          className="flex-1 flex items-center justify-center gap-1.5 text-xs bg-primary text-primary-foreground rounded-lg py-1.5 font-medium hover:opacity-90 transition-opacity"
                        >
                          <Lightning size={12} weight="fill" /> Connecter
                        </button>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Webhooks personnalisés */}
        <Card className="rounded-xl border border-border shadow-sm mb-6">
          <CardHeader className="pb-2 pt-5 px-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-mono tracking-widest text-muted-foreground uppercase mb-0.5">Webhooks</p>
                <CardTitle className="font-heading text-base font-semibold text-foreground">
                  Webhooks personnalisés
                </CardTitle>
              </div>
              <button
                onClick={() => setShowAddWebhook((p) => !p)}
                className="flex items-center gap-1.5 text-xs bg-primary/10 text-primary rounded-lg px-3 py-1.5 font-medium hover:bg-primary/20 transition-colors"
              >
                <Plus size={12} weight="bold" /> Ajouter
              </button>
            </div>
          </CardHeader>
          <Separator />
          <CardContent className="px-5 pt-4 pb-5">
            <p className="text-xs text-muted-foreground mb-4">
              Recevez des notifications automatiques sur votre propre serveur ou service (Zapier, Make, n8n, etc.) lors d&#39;événements clés dans GarageManager.
            </p>

            {showAddWebhook && (
              <div className="mb-4 p-4 rounded-xl border border-border bg-muted/30 space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1 block">
                      Nom de l&#39;événement
                    </Label>
                    <Input
                      value={newWebhookLabel}
                      onChange={(e) => setNewWebhookLabel(e.target.value)}
                      placeholder="Ex. : Facture payée"
                      className="h-7 text-xs rounded-md border-border"
                      autoFocus
                    />
                  </div>
                  <div>
                    <Label className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1 block">
                      URL de destination
                    </Label>
                    <Input
                      value={newWebhookUrl}
                      onChange={(e) => setNewWebhookUrl(e.target.value)}
                      placeholder="https://hooks.zapier.com/…"
                      className="h-7 text-xs rounded-md border-border"
                    />
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleAddWebhook}
                    className="text-xs bg-primary text-primary-foreground rounded-md px-3 py-1.5 font-medium hover:opacity-90 transition-opacity"
                  >
                    Ajouter
                  </button>
                  <button
                    onClick={() => setShowAddWebhook(false)}
                    className="text-xs text-muted-foreground hover:text-foreground"
                  >
                    Annuler
                  </button>
                </div>
              </div>
            )}

            {customWebhooks.length === 0 && !showAddWebhook ? (
              <div className="text-center py-6 text-muted-foreground text-xs">
                Aucun webhook configuré. Cliquez sur « Ajouter » pour créer votre premier webhook.
              </div>
            ) : (
              <div className="space-y-2">
                {customWebhooks.map((wh) => (
                  <div key={wh.id} className="flex items-center gap-3 px-3 py-2.5 rounded-lg border border-border bg-background hover:bg-muted transition-colors group">
                    <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <Lightning size={13} weight="duotone" className="text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-foreground">{wh.label}</p>
                      <p className="text-[10px] text-muted-foreground truncate">{wh.url}</p>
                    </div>
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => navigator.clipboard.writeText(wh.url)}
                        className="text-muted-foreground hover:text-foreground p-1 rounded"
                        title="Copier l'URL"
                      >
                        <Copy size={12} />
                      </button>
                      <button
                        onClick={() => setCustomWebhooks((p) => p.filter((x) => x.id !== wh.id))}
                        className="text-muted-foreground hover:text-red-500 p-1 rounded"
                        title="Supprimer"
                      >
                        <Trash size={12} />
                      </button>
                    </div>
                    <Badge className="bg-green-500/10 text-green-600 border-0 text-[10px] px-2 py-0.5 shrink-0">
                      Actif
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Facebook Page */}
        <Card className="rounded-xl border border-border shadow-sm mb-6">
          <CardHeader className="pb-2 pt-5 px-5">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-600 to-blue-800 flex items-center justify-center shadow-sm shrink-0">
                <FacebookLogo size={20} weight="fill" className="text-white" />
              </div>
              <div>
                <p className="text-xs font-mono tracking-widest text-muted-foreground uppercase mb-0.5">Marketing</p>
                <CardTitle className="font-heading text-base font-semibold text-foreground">
                  Page Facebook de l&#39;atelier
                </CardTitle>
              </div>
            </div>
          </CardHeader>
          <Separator />
          <CardContent className="px-5 pt-4 pb-5">
            <p className="text-xs text-muted-foreground mb-4">
              Accédez directement à votre page Facebook pour publier des promotions, répondre aux avis clients et partager vos actualités.
            </p>
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
              <a
                href={FACEBOOK_PAGE_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#1877F2] hover:bg-[#166fe5] text-white text-sm font-medium transition-colors shadow-sm"
              >
                <FacebookLogo size={16} weight="fill" />
                Ouvrir ma page Facebook
                <ArrowSquareOut size={13} />
              </a>
              <p className="text-[11px] text-muted-foreground">
                Lien configuré par votre administrateur GarageManager
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Embed iframe widget */}
        <Card className="rounded-xl border border-border shadow-sm">
          <CardHeader className="pb-2 pt-5 px-5">
            <p className="text-xs font-mono tracking-widest text-muted-foreground uppercase mb-0.5">Widget</p>
            <CardTitle className="font-heading text-base font-semibold text-foreground">
              Widget de prise de rendez-vous
            </CardTitle>
          </CardHeader>
          <Separator />
          <CardContent className="px-5 pt-4 pb-5">
            <p className="text-xs text-muted-foreground mb-4">
              Intégrez ce widget sur votre site web pour permettre à vos clients de prendre rendez-vous directement en ligne.
            </p>
            <div className="p-3 rounded-lg bg-muted/50 border border-border font-mono text-[11px] text-muted-foreground break-all select-all mb-3">
              {`<iframe src="https://garagemanager.app/widget/booking?org=${orgId}" width="400" height="600" frameborder="0"></iframe>`}
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => navigator.clipboard.writeText(`<iframe src="https://garagemanager.app/widget/booking?org=${orgId}" width="400" height="600" frameborder="0"></iframe>`)}
                className="flex items-center gap-1.5 text-xs bg-primary/10 text-primary rounded-lg px-3 py-1.5 font-medium hover:bg-primary/20 transition-colors"
              >
                <Copy size={12} /> Copier le code
              </button>
              <Badge className="bg-amber-500/10 text-amber-600 border-0 text-[10px] px-2 py-0.5">
                <Clock size={10} className="mr-1 inline" weight="duotone" />
                Module en préparation
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
