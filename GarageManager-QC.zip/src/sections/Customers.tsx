import { useState, useCallback } from "react";
import { useApiCustomers, fetchRepairOrders, type ApiCustomer } from "@/hooks/use-api-data";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { InvoicePrefill } from "../GarageApp";
import SendInvoiceModal, { type SendInvoiceData } from "@/components/SendInvoiceModal";
import {
  User,
  Car,
  Phone,
  Envelope,
  Plus,
  MagnifyingGlass,
  X,
  FloppyDisk,
  Trash,
  UsersThree,
  CaretDown,
  CaretUp,
  Receipt,
  PencilSimple,
  Check,
  ClockCountdown,
  PaperPlaneTilt,
} from "@phosphor-icons/react";
import { ContextMenu, type ContextMenuItem } from "@/components/ui/context-menu-portal";

// ── helpers ─────────────────────────────────────────────────────────────────
function parseVehicles(raw: string | undefined, primary: string): VehicleEntry[] {
  if (raw) {
    try {
      const arr = JSON.parse(raw);
      if (Array.isArray(arr) && arr.length > 0) {
        // Support both legacy strings and new structured objects
        return arr.map((v: unknown) => {
          if (typeof v === "string") return { label: v };
          return v as VehicleEntry;
        });
      }
    } catch { /* fall through */ }
  }
  return primary ? [{ label: primary }] : [];
}

function vehicleLabel(v: VehicleEntry): string {
  if (v.label) return v.label;
  const parts = [v.annee, v.marque, v.modele].filter(Boolean).join(" ");
  return parts || "Véhicule";
}

// ── types ────────────────────────────────────────────────────────────────────
interface VehicleEntry {
  label?: string;
  marque?: string;
  modele?: string;
  annee?: string;
  moteur?: string;
  serie?: string;
  couleur?: string;
  garniture?: string;
  plaque?: string;
}

const EMPTY_VEHICLE: VehicleEntry = {
  marque: "",
  modele: "",
  annee: "",
  moteur: "",
  serie: "",
  couleur: "",
  garniture: "",
  plaque: "",
};

// ── component ────────────────────────────────────────────────────────────────
export default function Customers({ onCreateInvoice, orgId }: { onCreateInvoice: (prefill: InvoicePrefill) => void; orgId: string }) {
  const [search, setSearch] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", phone: "", vehicleInfo: "" });
  const [formError, setFormError] = useState("");
  const [expandedId, setExpandedId] = useState<string | null>(null);

  // edit-client modal
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState({ name: "", email: "", phone: "" });
  const [editError, setEditError] = useState("");

  // per-card: add-vehicle panel
  const [addingVehicleFor, setAddingVehicleFor] = useState<string | null>(null);
  const [newVehicle, setNewVehicle] = useState<VehicleEntry>({ ...EMPTY_VEHICLE });

  // history panel
  const [historyCustomerId, setHistoryCustomerId] = useState<string | null>(null);
  const [historyOrders, setHistoryOrders] = useState<Array<{ id: string; orderNumber: string; vehicleInfo: string; status: string; total: number; date: Date }>>([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  // send invoice modal
  const [sendingInvoice, setSendingInvoice] = useState<SendInvoiceData | null>(null);

  // context menu
  const [ctxMenu, setCtxMenu] = useState<{ x: number; y: number; customerId: string } | null>(null);

  const handleContextMenu = useCallback((e: React.MouseEvent, customerId: string) => {
    e.preventDefault();
    setCtxMenu({ x: e.clientX, y: e.clientY, customerId });
  }, []);

  const { data: customers, isPending, error, refetch, create, update, remove } = useApiCustomers(orgId);
  const isMutating = false;

  const openHistory = async (customerId: string, customerName: string) => {
    if (historyCustomerId === customerId) {
      setHistoryCustomerId(null);
      setHistoryOrders([]);
      return;
    }
    setHistoryCustomerId(customerId);
    setHistoryLoading(true);
    try {
      const orders = await fetchRepairOrders(orgId);
      const filtered = orders
        .filter((o) => o.customerName === customerName)
        .map((o) => ({
          id: o.id,
          orderNumber: o.orderNumber,
          vehicleInfo: o.vehicleInfo ?? "",
          status: o.status,
          total: parseFloat(o.total) || 0,
          date: o.date ? new Date(o.date) : new Date(),
        }));
      setHistoryOrders(filtered);
    } catch {
      setHistoryOrders([]);
    }
    setHistoryLoading(false);
  };

  const filtered = (customers ?? []).filter((c) => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      c.name.toLowerCase().includes(q) ||
      (c.email ?? "").toLowerCase().includes(q) ||
      (c.phone ?? "").toLowerCase().includes(q) ||
      (c.vehicleInfo ?? "").toLowerCase().includes(q)
    );
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.vehicleInfo.trim()) {
      setFormError("Le nom et le véhicule sont obligatoires.");
      return;
    }
    setFormError("");
    try {
      await create({
        orgId,
        name: form.name.trim(),
        email: form.email.trim() || undefined,
        phone: form.phone.trim() || undefined,
        vehicleInfo: form.vehicleInfo.trim(),
        vehicles: JSON.stringify([{ label: form.vehicleInfo.trim() }]),
      });
      await refetch();
      setForm({ name: "", email: "", phone: "", vehicleInfo: "" });
      setShowAdd(false);
    } catch {
      setFormError("Erreur lors de l'ajout du client.");
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Supprimer ce client ?")) return;
    try { await remove(id); await refetch(); } catch { /* silently ignore */ }
  };

  // ── edit client info ──────────────────────────────────────────────────────
  const openEdit = (c: { id: string; name: string; email?: string | null; phone?: string | null }) => {
    setEditingId(c.id);
    setEditForm({ name: c.name, email: c.email ?? "", phone: c.phone ?? "" });
    setEditError("");
  };

  const handleEditSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editForm.name.trim()) { setEditError("Le nom est obligatoire."); return; }
    try {
      await update(editingId!, {
        name: editForm.name.trim(),
        email: editForm.email.trim() || undefined,
        phone: editForm.phone.trim() || undefined,
      });
      await refetch();
      setEditingId(null);
    } catch {
      setEditError("Erreur lors de la mise à jour.");
    }
  };

  // ── add vehicle ───────────────────────────────────────────────────────────
  const openAddVehicle = (id: string) => {
    setAddingVehicleFor(id);
    setNewVehicle({ ...EMPTY_VEHICLE });
  };

  const handleAddVehicle = (c: ApiCustomer) => {
    const hasData = newVehicle.marque?.trim() || newVehicle.modele?.trim() || newVehicle.annee?.trim();
    if (!hasData) return;
    const existing = parseVehicles(
      typeof c.vehicles === "string" ? c.vehicles : JSON.stringify(c.vehicles),
      c.vehicleInfo ?? ""
    );
    const entry: VehicleEntry = {
      marque: newVehicle.marque?.trim() || undefined,
      modele: newVehicle.modele?.trim() || undefined,
      annee: newVehicle.annee?.trim() || undefined,
      moteur: newVehicle.moteur?.trim() || undefined,
      serie: newVehicle.serie?.trim() || undefined,
      couleur: newVehicle.couleur?.trim() || undefined,
      garniture: newVehicle.garniture?.trim() || undefined,
      plaque: newVehicle.plaque?.trim() || undefined,
    };
    const updated = [...existing, entry];
    const primaryLabel = vehicleLabel(entry);
    update(c.id, {
      vehicles: JSON.stringify(updated),
      vehicleInfo: existing.length === 0 ? primaryLabel : c.vehicleInfo ?? undefined,
    }).then(() => refetch());
    setAddingVehicleFor(null);
    setNewVehicle({ ...EMPTY_VEHICLE });
  };

  const handleRemoveVehicle = (c: ApiCustomer, idx: number) => {
    const existing = parseVehicles(
      typeof c.vehicles === "string" ? c.vehicles : JSON.stringify(c.vehicles),
      c.vehicleInfo ?? ""
    );
    const updated = existing.filter((_, i) => i !== idx);
    update(c.id, {
      vehicles: JSON.stringify(updated),
      vehicleInfo: updated.length > 0 ? vehicleLabel(updated[0]) : c.vehicleInfo ?? undefined,
    }).then(() => refetch());
  };

  return (
    <section id="customers" className="bg-background min-h-screen py-10 px-4 md:px-8 lg:px-12">

      {/* ── Edit client modal ─────────────────────────────────────────────── */}
      {editingId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm px-4">
          <div className="bg-card border border-border rounded-2xl shadow-xl w-full max-w-md p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-semibold uppercase tracking-widest text-muted-foreground">
                Modifier le client
              </h2>
              <button onClick={() => setEditingId(null)} className="text-muted-foreground hover:text-foreground">
                <X size={16} weight="bold" />
              </button>
            </div>
            <form onSubmit={handleEditSave} className="space-y-4">
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                  Nom complet <span className="text-primary">*</span>
                </Label>
                <Input
                  value={editForm.name}
                  onChange={(e) => setEditForm((f) => ({ ...f, name: e.target.value }))}
                  placeholder="Ex. : Jean-François Tremblay"
                  className="rounded-lg border-border text-sm"
                  disabled={isMutating}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                  Téléphone
                </Label>
                <div className="relative">
                  <Phone size={13} weight="duotone" className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    value={editForm.phone}
                    onChange={(e) => setEditForm((f) => ({ ...f, phone: e.target.value }))}
                    placeholder="(418) 555-0000"
                    className="pl-8 rounded-lg border-border text-sm"
                    disabled={isMutating}
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                  Courriel
                </Label>
                <div className="relative">
                  <Envelope size={13} weight="duotone" className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    type="email"
                    value={editForm.email}
                    onChange={(e) => setEditForm((f) => ({ ...f, email: e.target.value }))}
                    placeholder="courriel@exemple.com"
                    className="pl-8 rounded-lg border-border text-sm"
                    disabled={isMutating}
                  />
                </div>
              </div>
              {editError && <p className="text-xs text-red-500">{editError}</p>}
              <div className="flex gap-2 pt-1">
                <Button
                  type="submit"
                  disabled={isMutating}
                  className="bg-primary text-primary-foreground rounded-lg text-sm gap-1.5 shadow-sm"
                >
                  <FloppyDisk size={14} weight="duotone" />
                  {isMutating ? "Enregistrement…" : "Sauvegarder"}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setEditingId(null)}
                  className="rounded-lg text-sm border-border"
                >
                  Annuler
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="max-w-5xl mx-auto mb-7">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-3">
            <UsersThree weight="duotone" className="w-6 h-6 text-primary" />
            <div>
              <h1 className="font-heading text-2xl font-semibold text-foreground tracking-tight">
                Clients
              </h1>
              <p className="text-sm text-muted-foreground">
                Répertoire des clients et de leurs véhicules.
              </p>
            </div>
          </div>
          <Button
            onClick={() => setShowAdd(!showAdd)}
            className="bg-primary text-primary-foreground rounded-lg text-sm font-medium gap-1.5 shadow-sm"
          >
            {showAdd ? <X size={15} weight="duotone" /> : <Plus size={15} weight="duotone" />}
            {showAdd ? "Annuler" : "Nouveau client"}
          </Button>
        </div>
        <Separator className="mt-5" />
      </div>

      <div className="max-w-5xl mx-auto space-y-5">
        {/* Add customer form */}
        {showAdd && (
          <Card className="rounded-xl border border-primary/30 shadow-sm bg-card">
            <CardHeader className="pb-2 pt-5 px-5">
              <div className="flex items-center gap-2">
                <Plus weight="duotone" className="w-4 h-4 text-primary" />
                <CardTitle className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                  Ajouter un nouveau client
                </CardTitle>
              </div>
              <Separator className="mt-3" />
            </CardHeader>
            <CardContent className="px-5 pb-5">
              <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                    Nom complet <span className="text-primary">*</span>
                  </Label>
                  <Input
                    value={form.name}
                    onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                    placeholder="Ex. : Jean-François Tremblay"
                    className="rounded-lg border-border text-sm"
                    disabled={isMutating}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                    Téléphone
                  </Label>
                  <Input
                    value={form.phone}
                    onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))}
                    placeholder="(418) 555-0000"
                    className="rounded-lg border-border text-sm"
                    disabled={isMutating}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                    Courriel
                  </Label>
                  <Input
                    type="email"
                    value={form.email}
                    onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                    placeholder="courriel@exemple.com"
                    className="rounded-lg border-border text-sm"
                    disabled={isMutating}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                    Véhicule principal <span className="text-primary">*</span>
                  </Label>
                  <Input
                    value={form.vehicleInfo}
                    onChange={(e) => setForm((f) => ({ ...f, vehicleInfo: e.target.value }))}
                    placeholder="Ex. : 2022 Honda Civic"
                    className="rounded-lg border-border text-sm"
                    disabled={isMutating}
                  />
                </div>
                {formError && (
                  <p className="sm:col-span-2 text-xs text-red-500">{formError}</p>
                )}
                <div className="sm:col-span-2 flex gap-2 pt-1">
                  <Button
                    type="submit"
                    disabled={isMutating}
                    className="bg-primary text-primary-foreground rounded-lg text-sm gap-1.5 shadow-sm"
                  >
                    <FloppyDisk size={15} weight="duotone" />
                    {isMutating ? "Enregistrement…" : "Enregistrer le client"}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => { setShowAdd(false); setFormError(""); }}
                    className="rounded-lg text-sm border-border"
                  >
                    Annuler
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Search */}
        <div className="relative max-w-sm">
          <MagnifyingGlass size={15} weight="duotone" className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher un client ou véhicule…"
            className="pl-9 rounded-lg border-border text-sm"
          />
        </div>

        {/* Loading / error */}
        {isPending && (
          <div className="text-sm text-muted-foreground py-8 text-center">Chargement des clients…</div>
        )}
        {error && (
          <div className="text-sm text-red-500 py-4">Erreur lors du chargement des clients.</div>
        )}

        {/* Customer list */}
        {!isPending && !error && (
          <>
            {filtered.length === 0 ? (
              <div className="text-center py-16 text-muted-foreground text-sm">
                {search
                  ? "Aucun client ne correspond à la recherche."
                  : "Aucun client enregistré. Cliquez sur « Nouveau client » pour commencer."}
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {filtered.map((c) => {
                  const isExpanded = expandedId === c.id;
                  const vehicles = parseVehicles(c.vehicles as string | undefined, c.vehicleInfo ?? "");

                  return (
                    <Card
                      key={c.id}
                      className="rounded-xl shadow-sm border border-border bg-card hover:shadow-md transition-all duration-150"
                      onContextMenu={(e) => handleContextMenu(e, c.id)}
                    >
                      <CardContent className="p-5">
                        {/* Top row — avatar + name + actions */}
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-center gap-3 min-w-0">
                            <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                              <User weight="duotone" size={17} className="text-primary" />
                            </div>
                            <div className="min-w-0">
                              <p className="text-sm font-semibold text-foreground truncate">{c.name}</p>
                              <p className="text-xs text-muted-foreground mt-0.5">
                                Client depuis{" "}
                                {new Date(c.createdAt ?? Date.now()).toLocaleDateString("fr-CA", {
                                  month: "long",
                                  year: "numeric",
                                })}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2 shrink-0 mt-0.5">
                            <button
                              onClick={() => openEdit(c)}
                              className="text-muted-foreground hover:text-primary transition-colors"
                              title="Modifier le client"
                            >
                              <PencilSimple size={14} weight="duotone" />
                            </button>
                            <button
                              onClick={() => handleDelete(c.id)}
                              disabled={isMutating}
                              className="text-muted-foreground hover:text-red-500 transition-colors"
                              title="Supprimer"
                            >
                              <Trash size={14} weight="duotone" />
                            </button>
                          </div>
                        </div>

                        <Separator className="my-3" />

                        {/* Quick info */}
                        <div className="space-y-2">
                          {c.phone && (
                            <div className="flex items-center gap-2 text-xs text-foreground">
                              <Phone size={13} weight="duotone" className="text-primary shrink-0" />
                              {c.phone}
                            </div>
                          )}
                          {c.email && (
                            <div className="flex items-center gap-2 text-xs text-foreground">
                              <Envelope size={13} weight="duotone" className="text-primary shrink-0" />
                              {c.email}
                            </div>
                          )}
                          {!c.phone && !c.email && (
                            <p className="text-xs text-muted-foreground italic">Aucune coordonnée enregistrée.</p>
                          )}
                          <div className="flex items-center gap-2 text-xs text-foreground">
                            <Car size={13} weight="duotone" className="text-primary shrink-0" />
                            <span className="truncate">{vehicleLabel(vehicles[0]) ?? c.vehicleInfo}</span>
                            {vehicles.length > 1 && (
                              <Badge className="ml-1 text-[10px] px-1.5 py-0 rounded-full bg-muted text-muted-foreground border-0">
                                +{vehicles.length - 1}
                              </Badge>
                            )}
                          </div>
                        </div>

                        {/* Expanded details */}
                        {isExpanded && (
                          <div className="mt-4 space-y-3">
                            <Separator />

                            {/* Registered vehicles */}
                            <div>
                              <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold mb-2">
                                Véhicules enregistrés
                              </p>
                              <div className="space-y-2">
                                {vehicles.map((v, i) => (
                                  <div key={i} className="rounded-lg border border-border bg-muted/30 p-3 group">
                                    <div className="flex items-center justify-between gap-2 mb-1.5">
                                      <div className="flex items-center gap-2 min-w-0">
                                        <Car size={12} weight="duotone" className="text-primary shrink-0" />
                                        <span className="text-xs font-semibold text-foreground truncate">{vehicleLabel(v)}</span>
                                      </div>
                                      <div className="flex items-center gap-2 shrink-0">
                                        <button
                                          onClick={() =>
                                            onCreateInvoice({
                                              customerName: c.name,
                                              phone: c.phone ?? "",
                                              vehicleInfo: vehicleLabel(v),
                                            })
                                          }
                                          className="opacity-0 group-hover:opacity-100 text-[10px] text-primary hover:underline transition-all flex items-center gap-0.5"
                                          title="Créer une facture pour ce véhicule"
                                        >
                                          <Receipt size={11} weight="duotone" />
                                          Facturer
                                        </button>
                                        {vehicles.length > 1 && (
                                          <button
                                            onClick={() => handleRemoveVehicle(c, i)}
                                            disabled={isMutating}
                                            className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-red-500 transition-all"
                                            title="Retirer ce véhicule"
                                          >
                                            <X size={11} weight="bold" />
                                          </button>
                                        )}
                                      </div>
                                    </div>
                                    {/* Vehicle details grid — all fields editable inline */}
                                    <div className="grid grid-cols-2 gap-x-4 gap-y-0.5 mt-1.5 pl-5">
                                      {(["annee","marque","modele","moteur","couleur","garniture","plaque","serie"] as const).map((field) => {
                                        const labels: Record<string, string> = {
                                          annee: "Année", marque: "Marque", modele: "Modèle",
                                          moteur: "Moteur", couleur: "Couleur", garniture: "Garniture",
                                          plaque: "N° de plaque", serie: "N° de série",
                                        };
                                        const current = v[field] ?? "";
                                        return (
                                          <VehicleDetail
                                            key={field}
                                            label={labels[field]}
                                            value={current || "—"}
                                            onSave={(newVal) => {
                                              const existing = parseVehicles(c.vehicles as string | undefined, c.vehicleInfo ?? "");
                                              const updated = existing.map((ve, idx) =>
                                                idx === i ? { ...ve, [field]: newVal } : ve
                                              );
                                              update(c.id, { vehicles: JSON.stringify(updated) });
                                            }}
                                          />
                                        );
                                      })}
                                    </div>
                                  </div>
                                ))}
                              </div>

                              {/* Add vehicle form */}
                              {addingVehicleFor === c.id ? (
                                <div className="mt-3 rounded-xl border border-primary/30 bg-muted/20 p-4 space-y-3">
                                  <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold">
                                    Nouveau véhicule
                                  </p>
                                  <div className="grid grid-cols-2 gap-3">
                                    <div className="space-y-1">
                                      <Label className="text-[10px] text-muted-foreground uppercase tracking-wide">Marque</Label>
                                      <Input
                                        value={newVehicle.marque ?? ""}
                                        onChange={(e) => setNewVehicle((v) => ({ ...v, marque: e.target.value }))}
                                        placeholder="Honda"
                                        className="h-7 text-xs rounded-md border-border"
                                        disabled={isMutating}
                                      />
                                    </div>
                                    <div className="space-y-1">
                                      <Label className="text-[10px] text-muted-foreground uppercase tracking-wide">Modèle</Label>
                                      <Input
                                        value={newVehicle.modele ?? ""}
                                        onChange={(e) => setNewVehicle((v) => ({ ...v, modele: e.target.value }))}
                                        placeholder="Civic"
                                        className="h-7 text-xs rounded-md border-border"
                                        disabled={isMutating}
                                      />
                                    </div>
                                    <div className="space-y-1">
                                      <Label className="text-[10px] text-muted-foreground uppercase tracking-wide">Année</Label>
                                      <Input
                                        value={newVehicle.annee ?? ""}
                                        onChange={(e) => setNewVehicle((v) => ({ ...v, annee: e.target.value }))}
                                        placeholder="2022"
                                        className="h-7 text-xs rounded-md border-border"
                                        disabled={isMutating}
                                      />
                                    </div>
                                    <div className="space-y-1">
                                      <Label className="text-[10px] text-muted-foreground uppercase tracking-wide">Moteur</Label>
                                      <Input
                                        value={newVehicle.moteur ?? ""}
                                        onChange={(e) => setNewVehicle((v) => ({ ...v, moteur: e.target.value }))}
                                        placeholder="2.0L 4cyl"
                                        className="h-7 text-xs rounded-md border-border"
                                        disabled={isMutating}
                                      />
                                    </div>
                                    <div className="space-y-1">
                                      <Label className="text-[10px] text-muted-foreground uppercase tracking-wide">Couleur</Label>
                                      <Input
                                        value={newVehicle.couleur ?? ""}
                                        onChange={(e) => setNewVehicle((v) => ({ ...v, couleur: e.target.value }))}
                                        placeholder="Ex. : Argent"
                                        className="h-7 text-xs rounded-md border-border"
                                        disabled={isMutating}
                                      />
                                    </div>
                                    <div className="space-y-1">
                                      <Label className="text-[10px] text-muted-foreground uppercase tracking-wide">Garniture</Label>
                                      <Input
                                        value={newVehicle.garniture ?? ""}
                                        onChange={(e) => setNewVehicle((v) => ({ ...v, garniture: e.target.value }))}
                                        placeholder="Ex. : Sport, EX-L"
                                        className="h-7 text-xs rounded-md border-border"
                                        disabled={isMutating}
                                      />
                                    </div>
                                    <div className="space-y-1">
                                      <Label className="text-[10px] text-muted-foreground uppercase tracking-wide">N° de plaque</Label>
                                      <Input
                                        value={newVehicle.plaque ?? ""}
                                        onChange={(e) => setNewVehicle((v) => ({ ...v, plaque: e.target.value }))}
                                        placeholder="Ex. : ABC 123"
                                        className="h-7 text-xs rounded-md border-border"
                                        disabled={isMutating}
                                      />
                                    </div>
                                    <div className="col-span-2 space-y-1">
                                      <Label className="text-[10px] text-muted-foreground uppercase tracking-wide">Numéro de série (VIN)</Label>
                                      <Input
                                        value={newVehicle.serie ?? ""}
                                        onChange={(e) => setNewVehicle((v) => ({ ...v, serie: e.target.value }))}
                                        placeholder="1HGCM82633A123456"
                                        className="h-7 text-xs rounded-md border-border"
                                        disabled={isMutating}
                                      />
                                    </div>
                                  </div>
                                  <div className="flex gap-2 pt-1">
                                    <Button
                                      size="sm"
                                      onClick={() => handleAddVehicle(c)}
                                      disabled={isMutating}
                                      className="h-7 text-xs bg-primary text-primary-foreground rounded-lg gap-1.5 px-3"
                                    >
                                      <Check size={12} weight="bold" />
                                      {isMutating ? "Ajout…" : "Ajouter"}
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => { setAddingVehicleFor(null); setNewVehicle({ ...EMPTY_VEHICLE }); }}
                                      className="h-7 text-xs rounded-lg border-border px-3"
                                    >
                                      Annuler
                                    </Button>
                                  </div>
                                </div>
                              ) : (
                                <button
                                  onClick={() => openAddVehicle(c.id)}
                                  className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
                                >
                                  <Plus size={12} weight="duotone" />
                                  Ajouter un véhicule
                                </button>
                              )}
                            </div>
                          </div>
                        )}

                        <Separator className="mt-3 mb-3" />

                        {/* History panel */}
                        {historyCustomerId === c.id && (
                          <div className="mt-3 pt-3 border-t border-border">
                            <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold mb-2 flex items-center gap-1.5">
                              <ClockCountdown size={12} weight="duotone" />
                              Historique des factures
                            </p>
                            {historyLoading ? (
                              <p className="text-xs text-muted-foreground py-2">Chargement…</p>
                            ) : historyOrders.length === 0 ? (
                              <p className="text-xs text-muted-foreground italic py-1">Aucune facture trouvée.</p>
                            ) : (
                              <div className="space-y-1.5">
                                {historyOrders.map((o) => (
                                  <div key={o.id} className="flex items-center justify-between gap-2 px-2 py-1.5 rounded-lg bg-muted/30 border border-border">
                                    <div className="min-w-0">
                                      <p className="text-[11px] font-mono font-semibold text-foreground">{o.orderNumber}</p>
                                      <p className="text-[10px] text-muted-foreground truncate">{o.vehicleInfo}</p>
                                    </div>
                                    <div className="flex items-center gap-2 shrink-0">
                                      <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded-full ${
                                        o.status === "Payée" ? "bg-primary/10 text-primary" :
                                        o.status === "Non payée" ? "bg-red-500/10 text-red-500" :
                                        "bg-muted text-muted-foreground"
                                      }`}>{o.status}</span>
                                      <span className="text-[11px] font-mono font-bold text-foreground">
                                        {o.total.toLocaleString("fr-CA", { style: "currency", currency: "CAD" })}
                                      </span>
                                      <button
                                        onClick={() => setSendingInvoice({
                                          orderNumber: o.orderNumber,
                                          customerName: c.name,
                                          vehicleInfo: o.vehicleInfo,
                                          total: o.total,
                                          email: c.email ?? undefined,
                                          phone: c.phone ?? undefined,
                                        })}
                                        className="text-muted-foreground hover:text-primary transition-colors"
                                        title="Envoyer cette facture"
                                      >
                                        <PaperPlaneTilt size={12} weight="duotone" />
                                      </button>
                                    </div>
                                  </div>
                                ))}
                                <p className="text-[10px] text-muted-foreground pt-1">
                                  {historyOrders.length} facture{historyOrders.length !== 1 ? "s" : ""} —{" "}
                                  Total :{" "}
                                  <span className="font-semibold text-foreground">
                                    {historyOrders.reduce((s, o) => s + o.total, 0).toLocaleString("fr-CA", { style: "currency", currency: "CAD" })}
                                  </span>
                                </p>
                              </div>
                            )}
                          </div>
                        )}

                        {/* Action buttons */}
                        <div className="flex items-center gap-2 flex-wrap mt-3">
                          <button
                            onClick={() => setExpandedId(isExpanded ? null : c.id)}
                            className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
                          >
                            {isExpanded ? (
                              <><CaretUp size={12} weight="duotone" /> Réduire</>
                            ) : (
                              <><CaretDown size={12} weight="duotone" /> Plus de détails</>
                            )}
                          </button>
                          <button
                            onClick={() => openHistory(c.id, c.name)}
                            className={`flex items-center gap-1 text-xs transition-colors ${
                              historyCustomerId === c.id ? "text-primary" : "text-muted-foreground hover:text-foreground"
                            }`}
                          >
                            <ClockCountdown size={12} weight="duotone" />
                            {historyCustomerId === c.id ? "Cacher" : "Historique"}
                          </button>

                          <div className="flex-1" />

                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setSendingInvoice({
                              orderNumber: "—",
                              customerName: c.name,
                              vehicleInfo: vehicleLabel(vehicles[0]) ?? c.vehicleInfo,
                              total: 0,
                              email: c.email ?? undefined,
                              phone: c.phone ?? undefined,
                            })}
                            className="h-7 text-xs rounded-lg border-border gap-1 px-2.5"
                            title="Envoyer un message au client"
                          >
                            <PaperPlaneTilt size={12} weight="duotone" className="text-primary" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() =>
                              onCreateInvoice({
                                customerName: c.name,
                                phone: c.phone ?? "",
                                vehicleInfo: vehicleLabel(vehicles[0]) ?? c.vehicleInfo,
                              })
                            }
                            className="h-7 text-xs rounded-lg border-border gap-1 px-2.5"
                          >
                            <Receipt size={12} weight="duotone" className="text-primary" />
                            Créer une facture
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
            <p className="text-xs text-muted-foreground text-right pt-1">
              {filtered.length} client{filtered.length !== 1 ? "s" : ""}
            </p>
          </>
        )}
      </div>
      {sendingInvoice && (
        <SendInvoiceModal
          invoice={sendingInvoice}
          onClose={() => setSendingInvoice(null)}
        />
      )}

      {ctxMenu && (() => {
        const c = (customers ?? []).find((x) => x.id === ctxMenu.customerId);
        if (!c) return null;
        const vehicles = parseVehicles(c.vehicles as string | undefined, c.vehicleInfo ?? "");
        const menuItems: ContextMenuItem[] = [
          {
            label: "Modifier",
            icon: <PencilSimple size={13} weight="duotone" />,
            onClick: () => openEdit(c),
          },
          {
            label: "Créer une facture",
            icon: <Receipt size={13} weight="duotone" />,
            onClick: () => onCreateInvoice({
              customerName: c.name,
              phone: c.phone ?? "",
              vehicleInfo: vehicleLabel(vehicles[0]) ?? c.vehicleInfo,
            }),
          },
          {
            label: "Envoyer message",
            icon: <PaperPlaneTilt size={13} weight="duotone" />,
            onClick: () => setSendingInvoice({
              orderNumber: "—",
              customerName: c.name,
              vehicleInfo: vehicleLabel(vehicles[0]) ?? c.vehicleInfo,
              total: 0,
              email: c.email ?? undefined,
              phone: c.phone ?? undefined,
            }),
          },
          {
            label: "Supprimer",
            icon: <Trash size={13} weight="duotone" />,
            onClick: () => handleDelete(c.id),
            danger: true,
            disabled: isMutating,
          },
        ];
        return (
          <ContextMenu
            x={ctxMenu.x}
            y={ctxMenu.y}
            items={menuItems}
            onClose={() => setCtxMenu(null)}
          />
        );
      })()}
    </section>
  );
}

// ── small helper component — inline editable ─────────────────────────────────
function VehicleDetail({
  label,
  value,
  onSave,
}: {
  label: string;
  value: string;
  onSave: (v: string) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);

  const commit = () => {
    setEditing(false);
    if (draft.trim() !== value) onSave(draft.trim());
  };

  if (editing) {
    return (
      <div className="flex items-center gap-1 col-span-2">
        <span className="text-[10px] text-muted-foreground shrink-0">{label} :</span>
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onBlur={commit}
          onKeyDown={(e) => {
            if (e.key === "Enter") commit();
            if (e.key === "Escape") { setDraft(value); setEditing(false); }
          }}
          autoFocus
          className="text-[10px] text-foreground font-medium bg-background border border-primary rounded px-1 py-0.5 w-full focus:outline-none"
        />
      </div>
    );
  }

  return (
    <button
      className="flex items-center gap-1 group/field text-left w-full"
      onClick={() => { setDraft(value); setEditing(true); }}
      title={`Modifier ${label}`}
    >
      <span className="text-[10px] text-muted-foreground shrink-0">{label} :</span>
      <span className="text-[10px] text-foreground font-medium">{value}</span>
      <PencilSimple
        size={9}
        weight="duotone"
        className="text-muted-foreground opacity-0 group-hover/field:opacity-100 transition-opacity ml-0.5 shrink-0"
      />
    </button>
  );
}
