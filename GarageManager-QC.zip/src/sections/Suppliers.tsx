import { useState, useRef } from "react";
import { useQuery, useMutation } from "@animaapp/playground-react-sdk";
import type { Supplier } from "@/lib/anima-sdk-stub";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import {
  Phone,
  Envelope,
  MapPin,
  Globe,
  Plus,
  MagnifyingGlass,
  X,
  FloppyDisk,
  Trash,
  PencilSimple,
  Note,
  CaretDown,
  CaretUp,
  ArrowSquareOut,
  Camera,
  Image,
  Copy,
  Tag,
  IdentificationCard,
  CurrencyDollar,
  User,
  Storefront,
} from "@phosphor-icons/react";

// ── Catégories disponibles ──────────────────────────────────────────────────
const CATEGORIES = [
  "Tous",
  "Pièces",
  "Pneus",
  "Huile & Fluides",
  "Électronique",
  "Carrosserie",
  "Outils",
  "Fournitures",
  "Autre",
];

const CATEGORY_COLORS: Record<string, string> = {
  Pièces: "bg-blue-500/10 text-blue-600",
  Pneus: "bg-zinc-500/10 text-zinc-600",
  "Huile & Fluides": "bg-amber-500/10 text-amber-600",
  Électronique: "bg-violet-500/10 text-violet-600",
  Carrosserie: "bg-red-500/10 text-red-600",
  Outils: "bg-orange-500/10 text-orange-600",
  Fournitures: "bg-teal-500/10 text-teal-600",
  Autre: "bg-muted text-muted-foreground",
};

const EMPTY_FORM = {
  companyName: "",
  contactName: "",
  phone: "",
  email: "",
  address: "",
  website: "",
  category: "Pièces",
  accountNumber: "",
  notes: "",
  cardImageUrl: "",
  tags: "",
};

type SupplierForm = typeof EMPTY_FORM;

// ── helpers ─────────────────────────────────────────────────────────────────
function parseTags(raw: string | undefined): string[] {
  if (!raw) return [];
  try {
    const arr = JSON.parse(raw);
    if (Array.isArray(arr)) return arr.map(String);
  } catch {
    /* fall through */
  }
  return raw
    .split(",")
    .map((t) => t.trim())
    .filter(Boolean);
}

function initials(name: string) {
  return (
    name
      .split(" ")
      .map((w) => w[0] ?? "")
      .join("")
      .toUpperCase()
      .slice(0, 2) || "??"
  );
}

// ── SupplierCard modal ────────────────────────────────────────────────────────
function SupplierDetailModal({
  supplier,
  onClose,
  onEdit,
  onDelete,
}: {
  supplier: {
    id: string;
    companyName: string;
    contactName?: string;
    phone?: string;
    email?: string;
    address?: string;
    website?: string;
    category?: string;
    accountNumber?: string;
    notes?: string;
    cardImageUrl?: string;
    tags?: string;
    createdAt: string;
  };
  onClose: () => void;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const tags = parseTags(supplier.tags);
  const [imgError, setImgError] = useState(false);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm px-4">
      <div className="bg-card border border-border rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-card border-b border-border px-6 py-4 flex items-center justify-between gap-3 z-10 rounded-t-2xl">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
              <span className="text-sm font-bold text-primary">
                {initials(supplier.companyName)}
              </span>
            </div>
            <div className="min-w-0">
              <h2 className="text-sm font-semibold text-foreground truncate">
                {supplier.companyName}
              </h2>
              {supplier.category && (
                <span
                  className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${CATEGORY_COLORS[supplier.category] ?? "bg-muted text-muted-foreground"}`}
                >
                  {supplier.category}
                </span>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={onEdit}
              className="text-muted-foreground hover:text-primary transition-colors p-1.5 rounded-lg hover:bg-muted"
              title="Modifier"
            >
              <PencilSimple size={15} weight="duotone" />
            </button>
            <button
              onClick={onClose}
              className="text-muted-foreground hover:text-foreground transition-colors p-1.5 rounded-lg hover:bg-muted"
            >
              <X size={15} weight="bold" />
            </button>
          </div>
        </div>

        <div className="px-6 py-5 space-y-5">
          {/* Business card image */}
          {supplier.cardImageUrl && !imgError && (
            <div>
              <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold mb-2 flex items-center gap-1.5">
                <IdentificationCard size={11} weight="duotone" />
                Carte d&#39;affaire scannée
              </p>
              <div className="rounded-xl overflow-hidden border border-border bg-muted/20">
                <img
                  src={supplier.cardImageUrl}
                  alt={`Carte d'affaire — ${supplier.companyName}`}
                  className="w-full object-contain max-h-52"
                  onError={() => setImgError(true)}
                />
              </div>
            </div>
          )}

          {/* Contact info */}
          <div>
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold mb-3 flex items-center gap-1.5">
              <User size={11} weight="duotone" />
              Coordonnées
            </p>
            <div className="space-y-2.5">
              {supplier.contactName && (
                <div className="flex items-center gap-2.5">
                  <User
                    size={14}
                    weight="duotone"
                    className="text-primary shrink-0"
                  />
                  <span className="text-sm text-foreground">
                    {supplier.contactName}
                  </span>
                </div>
              )}
              {supplier.phone && (
                <div className="flex items-center gap-2.5">
                  <Phone
                    size={14}
                    weight="duotone"
                    className="text-primary shrink-0"
                  />
                  <a
                    href={`tel:${supplier.phone}`}
                    className="text-sm text-foreground hover:text-primary transition-colors"
                  >
                    {supplier.phone}
                  </a>
                  <button
                    onClick={() =>
                      navigator.clipboard.writeText(supplier.phone ?? "")
                    }
                    className="text-muted-foreground hover:text-foreground ml-auto"
                    title="Copier"
                  >
                    <Copy size={11} />
                  </button>
                </div>
              )}
              {supplier.email && (
                <div className="flex items-center gap-2.5">
                  <Envelope
                    size={14}
                    weight="duotone"
                    className="text-primary shrink-0"
                  />
                  <a
                    href={`mailto:${supplier.email}`}
                    className="text-sm text-foreground hover:text-primary transition-colors truncate"
                  >
                    {supplier.email}
                  </a>
                  <button
                    onClick={() =>
                      navigator.clipboard.writeText(supplier.email ?? "")
                    }
                    className="text-muted-foreground hover:text-foreground ml-auto shrink-0"
                    title="Copier"
                  >
                    <Copy size={11} />
                  </button>
                </div>
              )}
              {supplier.address && (
                <div className="flex items-start gap-2.5">
                  <MapPin
                    size={14}
                    weight="duotone"
                    className="text-primary shrink-0 mt-0.5"
                  />
                  <span className="text-sm text-foreground leading-snug">
                    {supplier.address}
                  </span>
                  <a
                    href={`https://maps.google.com/?q=${encodeURIComponent(supplier.address)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-muted-foreground hover:text-primary ml-auto shrink-0"
                    title="Ouvrir dans Google Maps"
                  >
                    <ArrowSquareOut size={11} />
                  </a>
                </div>
              )}
              {supplier.website && (
                <div className="flex items-center gap-2.5">
                  <Globe
                    size={14}
                    weight="duotone"
                    className="text-primary shrink-0"
                  />
                  <a
                    href={
                      supplier.website.startsWith("http")
                        ? supplier.website
                        : `https://${supplier.website}`
                    }
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-primary hover:underline truncate"
                  >
                    {supplier.website}
                  </a>
                  <ArrowSquareOut
                    size={11}
                    className="text-muted-foreground shrink-0"
                  />
                </div>
              )}
              {!supplier.contactName &&
                !supplier.phone &&
                !supplier.email &&
                !supplier.address &&
                !supplier.website && (
                  <p className="text-xs text-muted-foreground italic">
                    Aucune coordonnée enregistrée.
                  </p>
                )}
            </div>
          </div>

          {/* Account / Reference */}
          {supplier.accountNumber && (
            <>
              <Separator />
              <div>
                <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold mb-2 flex items-center gap-1.5">
                  <CurrencyDollar size={11} weight="duotone" />
                  Référence compte
                </p>
                <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-muted/40 border border-border">
                  <span className="text-xs font-mono font-semibold text-foreground flex-1">
                    #{supplier.accountNumber}
                  </span>
                  <button
                    onClick={() =>
                      navigator.clipboard.writeText(
                        supplier.accountNumber ?? "",
                      )
                    }
                    className="text-muted-foreground hover:text-foreground"
                    title="Copier"
                  >
                    <Copy size={11} />
                  </button>
                </div>
              </div>
            </>
          )}

          {/* Tags */}
          {tags.length > 0 && (
            <>
              <Separator />
              <div>
                <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold mb-2 flex items-center gap-1.5">
                  <Tag size={11} weight="duotone" />
                  Étiquettes
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {tags.map((tag, i) => (
                    <span
                      key={i}
                      className="text-[11px] px-2 py-0.5 rounded-full bg-primary/10 text-primary font-medium"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* Notes */}
          {supplier.notes && (
            <>
              <Separator />
              <div>
                <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold mb-2 flex items-center gap-1.5">
                  <Note size={11} weight="duotone" />
                  Notes
                </p>
                <div className="rounded-xl bg-muted/30 border border-border px-4 py-3">
                  <p className="text-sm text-foreground leading-relaxed whitespace-pre-wrap">
                    {supplier.notes}
                  </p>
                </div>
              </div>
            </>
          )}

          <Separator />

          {/* Footer actions */}
          <div className="flex items-center gap-2 pt-1">
            <Button
              variant="outline"
              size="sm"
              onClick={onEdit}
              className="flex-1 rounded-lg border-border text-sm gap-1.5"
            >
              <PencilSimple size={13} weight="duotone" />
              Modifier
            </Button>
            <button
              onClick={onDelete}
              className="flex items-center gap-1.5 text-xs text-red-500 hover:bg-red-500/10 rounded-lg px-3 py-2 transition-colors font-medium"
            >
              <Trash size={13} weight="duotone" />
              Supprimer
            </button>
          </div>

          <p className="text-[10px] text-muted-foreground text-center">
            Ajouté le{" "}
            {new Date(supplier.createdAt).toLocaleDateString("fr-CA", {
              day: "numeric",
              month: "long",
              year: "numeric",
            })}
          </p>
        </div>
      </div>
    </div>
  );
}

// ── Form modal (add / edit) ──────────────────────────────────────────────────
function SupplierFormModal({
  initial,
  onSave,
  onClose,
  isSaving,
}: {
  initial: SupplierForm;
  onSave: (data: SupplierForm) => void;
  onClose: () => void;
  isSaving: boolean;
}) {
  const [form, setForm] = useState<SupplierForm>(initial);
  const [error, setError] = useState("");
  const [tagInput, setTagInput] = useState(() => {
    const t = parseTags(initial.tags);
    return t.join(", ");
  });
  const fileInputRef = useRef<HTMLInputElement>(null);

  const f =
    (field: keyof SupplierForm) =>
    (
      e: React.ChangeEvent<
        HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
      >,
    ) =>
      setForm((p) => ({ ...p, [field]: e.target.value }));

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      setForm((p) => ({ ...p, cardImageUrl: reader.result as string }));
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.companyName.trim()) {
      setError("Le nom de la compagnie est obligatoire.");
      return;
    }
    setError("");
    const tags = tagInput
      .split(",")
      .map((t) => t.trim())
      .filter(Boolean);
    onSave({ ...form, tags: tags.length ? JSON.stringify(tags) : "" });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm px-4">
      <div className="bg-card border border-border rounded-2xl shadow-2xl w-full max-w-lg max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-card border-b border-border px-6 py-4 flex items-center justify-between rounded-t-2xl z-10">
          <h2 className="text-sm font-semibold uppercase tracking-widest text-muted-foreground">
            {initial.companyName
              ? "Modifier le fournisseur"
              : "Ajouter un fournisseur"}
          </h2>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground p-1"
          >
            <X size={15} weight="bold" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="px-6 py-5 space-y-5">
          {/* Company info */}
          <div className="space-y-4">
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold">
              Informations générales
            </p>
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2 space-y-1.5">
                <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                  Nom de la compagnie <span className="text-primary">*</span>
                </Label>
                <Input
                  value={form.companyName}
                  onChange={f("companyName")}
                  placeholder="Ex. : NAPA Auto Parts"
                  className="rounded-lg border-border text-sm"
                  disabled={isSaving}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                  Personne-ressource
                </Label>
                <Input
                  value={form.contactName}
                  onChange={f("contactName")}
                  placeholder="Ex. : Jean Tremblay"
                  className="rounded-lg border-border text-sm"
                  disabled={isSaving}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                  Catégorie
                </Label>
                <select
                  value={form.category}
                  onChange={f("category")}
                  className="w-full h-9 rounded-lg border border-border bg-background text-sm px-3 text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                  disabled={isSaving}
                >
                  {CATEGORIES.filter((c) => c !== "Tous").map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <Separator />

          {/* Contact */}
          <div className="space-y-4">
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold">
              Coordonnées
            </p>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                  Téléphone
                </Label>
                <div className="relative">
                  <Phone
                    size={12}
                    weight="duotone"
                    className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none"
                  />
                  <Input
                    value={form.phone}
                    onChange={f("phone")}
                    placeholder="(418) 555-0000"
                    className="pl-7 rounded-lg border-border text-sm"
                    disabled={isSaving}
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                  Courriel
                </Label>
                <div className="relative">
                  <Envelope
                    size={12}
                    weight="duotone"
                    className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none"
                  />
                  <Input
                    type="email"
                    value={form.email}
                    onChange={f("email")}
                    placeholder="info@fournisseur.com"
                    className="pl-7 rounded-lg border-border text-sm"
                    disabled={isSaving}
                  />
                </div>
              </div>
              <div className="col-span-2 space-y-1.5">
                <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                  Adresse
                </Label>
                <div className="relative">
                  <MapPin
                    size={12}
                    weight="duotone"
                    className="absolute left-2.5 top-3 text-muted-foreground pointer-events-none"
                  />
                  <Input
                    value={form.address}
                    onChange={f("address")}
                    placeholder="123 rue de la Pièce, Québec, QC G1A 0A1"
                    className="pl-7 rounded-lg border-border text-sm"
                    disabled={isSaving}
                  />
                </div>
              </div>
              <div className="col-span-2 space-y-1.5">
                <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                  Site web
                </Label>
                <div className="relative">
                  <Globe
                    size={12}
                    weight="duotone"
                    className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none"
                  />
                  <Input
                    value={form.website}
                    onChange={f("website")}
                    placeholder="https://www.fournisseur.com"
                    className="pl-7 rounded-lg border-border text-sm"
                    disabled={isSaving}
                  />
                </div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Account + tags */}
          <div className="space-y-4">
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold">
              Référence & étiquettes
            </p>
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                Numéro de compte client
              </Label>
              <Input
                value={form.accountNumber}
                onChange={f("accountNumber")}
                placeholder="Ex. : 10045-A"
                className="rounded-lg border-border text-sm font-mono"
                disabled={isSaving}
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                Étiquettes (séparées par une virgule)
              </Label>
              <Input
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                placeholder="Ex. : livraison, priorité, net30"
                className="rounded-lg border-border text-sm"
                disabled={isSaving}
              />
            </div>
          </div>

          <Separator />

          {/* Business card photo */}
          <div className="space-y-3">
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold flex items-center gap-1.5">
              <IdentificationCard size={11} weight="duotone" />
              Carte d&#39;affaire
            </p>
            <p className="text-xs text-muted-foreground">
              Scannez ou prenez en photo la carte d&#39;affaire du fournisseur
              pour la conserver en référence.
            </p>
            {form.cardImageUrl && (
              <div className="rounded-xl overflow-hidden border border-border bg-muted/20 relative">
                <img
                  src={form.cardImageUrl}
                  alt="Carte d'affaire"
                  className="w-full object-contain max-h-40"
                />
                <button
                  type="button"
                  onClick={() => setForm((p) => ({ ...p, cardImageUrl: "" }))}
                  className="absolute top-2 right-2 bg-background/80 backdrop-blur-sm rounded-full p-1 text-foreground hover:text-red-500 border border-border"
                >
                  <X size={12} weight="bold" />
                </button>
              </div>
            )}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handlePhotoUpload}
              className="hidden"
            />
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-1.5 text-xs border border-dashed border-border rounded-lg px-3 py-2 text-muted-foreground hover:border-primary hover:text-primary transition-colors"
              >
                <Camera size={13} weight="duotone" />
                {form.cardImageUrl
                  ? "Changer la photo"
                  : "Prendre une photo / Scanner"}
              </button>
              <button
                type="button"
                onClick={() => {
                  if (fileInputRef.current) {
                    fileInputRef.current.removeAttribute("capture");
                    fileInputRef.current.click();
                    setTimeout(
                      () =>
                        fileInputRef.current?.setAttribute(
                          "capture",
                          "environment",
                        ),
                      500,
                    );
                  }
                }}
                className="flex items-center gap-1.5 text-xs border border-dashed border-border rounded-lg px-3 py-2 text-muted-foreground hover:border-primary hover:text-primary transition-colors"
              >
                <Image size={13} weight="duotone" />
                Importer une image
              </button>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                Ou coller une URL d&#39;image
              </Label>
              <Input
                value={form.cardImageUrl}
                onChange={f("cardImageUrl")}
                placeholder="https://… ou data:image/…"
                className="rounded-lg border-border text-xs font-mono"
                disabled={isSaving}
              />
            </div>
          </div>

          <Separator />

          {/* Notes */}
          <div className="space-y-1.5">
            <Label className="text-xs text-muted-foreground uppercase tracking-wide flex items-center gap-1.5">
              <Note size={11} weight="duotone" />
              Notes internes
            </Label>
            <textarea
              value={form.notes}
              onChange={f("notes")}
              rows={4}
              placeholder="Délai de livraison, conditions de paiement, contacts secondaires, etc."
              className="w-full rounded-lg border border-border bg-background text-sm px-3 py-2 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary resize-none"
              disabled={isSaving}
            />
          </div>

          {error && <p className="text-xs text-red-500">{error}</p>}

          <div className="flex gap-2 pt-1">
            <Button
              type="submit"
              disabled={isSaving}
              className="flex-1 bg-primary text-primary-foreground rounded-lg text-sm gap-1.5 shadow-sm"
            >
              <FloppyDisk size={14} weight="duotone" />
              {isSaving ? "Enregistrement…" : "Sauvegarder"}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="rounded-lg text-sm border-border"
            >
              Annuler
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ── Main Suppliers component ──────────────────────────────────────────────────
export default function Suppliers({ orgId }: { orgId: string }) {
  const [search, setSearch] = useState("");
  const [activeCategory, _setActiveCategory] = useState("Tous");
  const [showAdd, setShowAdd] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<{
    id: string;
    form: SupplierForm;
  } | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [expandedNotes, setExpandedNotes] = useState<Set<string>>(new Set());

  const {
    data: suppliers,
    isPending,
    error,
  } = useQuery<Supplier>("Supplier", {
    where: { orgId },
    orderBy: { companyName: "asc" },
  });

  const {
    create,
    update,
    remove,
    isPending: isMutating,
  } = useMutation<Supplier>("Supplier");

  const filtered = (suppliers ?? []).filter((s) => {
    const matchCat = activeCategory === "Tous" || s.category === activeCategory;
    if (!matchCat) return false;
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      s.companyName.toLowerCase().includes(q) ||
      (s.contactName ?? "").toLowerCase().includes(q) ||
      (s.email ?? "").toLowerCase().includes(q) ||
      (s.phone ?? "").toLowerCase().includes(q) ||
      (s.address ?? "").toLowerCase().includes(q) ||
      (s.notes ?? "").toLowerCase().includes(q)
    );
  });

  const selectedSupplier = selectedId
    ? (suppliers ?? []).find((s) => s.id === selectedId)
    : null;

  const handleCreate = async (data: SupplierForm) => {
    await create({ orgId, ...data });
    setShowAdd(false);
  };

  const handleUpdate = async (data: SupplierForm) => {
    if (!editingSupplier) return;
    await update(editingSupplier.id, data);
    setEditingSupplier(null);
    // If we were viewing this supplier, keep it selected
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Supprimer ce fournisseur ?")) return;
    await remove(id);
    if (selectedId === id) setSelectedId(null);
  };

  const toggleNotes = (id: string) => {
    setExpandedNotes((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const categoryCounts: Record<string, number> = {};
  (suppliers ?? []).forEach((s) => {
    const cat = s.category ?? "Autre";
    categoryCounts[cat] = (categoryCounts[cat] ?? 0) + 1;
  });

  return (
    <section
      id="suppliers"
      className="bg-background min-h-screen py-10 px-4 md:px-8 lg:px-12"
    >
      {/* Detail modal */}
      {selectedSupplier && (
        <SupplierDetailModal
          supplier={selectedSupplier}
          onClose={() => setSelectedId(null)}
          onEdit={() => {
            setEditingSupplier({
              id: selectedSupplier.id,
              form: {
                companyName: selectedSupplier.companyName,
                contactName: selectedSupplier.contactName ?? "",
                phone: selectedSupplier.phone ?? "",
                email: selectedSupplier.email ?? "",
                address: selectedSupplier.address ?? "",
                website: selectedSupplier.website ?? "",
                category: selectedSupplier.category ?? "Pièces",
                accountNumber: selectedSupplier.accountNumber ?? "",
                notes: selectedSupplier.notes ?? "",
                cardImageUrl: selectedSupplier.cardImageUrl ?? "",
                tags: selectedSupplier.tags ?? "",
              },
            });
            setSelectedId(null);
          }}
          onDelete={() => {
            handleDelete(selectedSupplier.id);
          }}
        />
      )}

      {/* Add form modal */}
      {showAdd && (
        <SupplierFormModal
          initial={{ ...EMPTY_FORM }}
          onSave={handleCreate}
          onClose={() => setShowAdd(false)}
          isSaving={isMutating}
        />
      )}

      {/* Edit form modal */}
      {editingSupplier && (
        <SupplierFormModal
          initial={editingSupplier.form}
          onSave={handleUpdate}
          onClose={() => setEditingSupplier(null)}
          isSaving={isMutating}
        />
      )}

      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-1">
            <div className="flex items-center gap-3">
              <Storefront weight="duotone" className="w-6 h-6 text-primary" />
              <div>
                <h1 className="font-heading text-2xl font-semibold text-foreground tracking-tight">
                  Fournisseurs
                </h1>
                <p className="text-sm text-muted-foreground">
                  Répertoire des fournisseurs, cartes d&#39;affaire et contacts.
                </p>
              </div>
            </div>
            <Button
              onClick={() => setShowAdd(true)}
              className="bg-primary text-primary-foreground rounded-lg text-sm font-medium gap-1.5 shadow-sm shrink-0"
            >
              <Plus size={15} weight="duotone" />
              Ajouter un fournisseur
            </Button>
          </div>
          <Separator className="mt-5" />
        </div>

        {/* Search */}
        <div className="mb-6">
          <div className="relative flex-1 max-w-sm">
            <MagnifyingGlass
              size={14}
              className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none"
            />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Rechercher un fournisseur…"
              className="pl-8 h-8 text-sm border-border rounded-lg"
            />
          </div>
        </div>

        {/* Loading / error */}
        {isPending && (
          <div className="text-sm text-muted-foreground py-12 text-center">
            Chargement des fournisseurs…
          </div>
        )}
        {error && (
          <div className="text-sm text-red-500 py-4">
            Erreur lors du chargement des fournisseurs.
          </div>
        )}

        {/* Grid */}
        {!isPending && !error && (
          <>
            {filtered.length === 0 ? (
              <div className="text-center py-20">
                <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center mx-auto mb-4">
                  <Storefront
                    size={28}
                    weight="duotone"
                    className="text-muted-foreground"
                  />
                </div>
                <p className="text-sm text-muted-foreground">
                  {search || activeCategory !== "Tous"
                    ? "Aucun fournisseur ne correspond à la recherche."
                    : "Aucun fournisseur enregistré. Cliquez sur « Ajouter un fournisseur » pour commencer."}
                </p>
                {!search && activeCategory === "Tous" && (
                  <p className="text-xs text-muted-foreground/60 mt-2">
                    💡 Astuce : vous pouvez prendre en photo les cartes
                    d&#39;affaire de vos fournisseurs directement depuis
                    l&#39;application.
                  </p>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {filtered.map((s) => {
                  const tags = parseTags(s.tags);
                  const notesExpanded = expandedNotes.has(s.id);

                  return (
                    <Card
                      key={s.id}
                      className="rounded-xl shadow-sm border border-border bg-card hover:shadow-md transition-all duration-150 cursor-pointer group"
                      onClick={() => setSelectedId(s.id)}
                    >
                      <CardContent className="p-5">
                        {/* Top */}
                        <div className="flex items-start justify-between gap-2 mb-3">
                          <div className="flex items-center gap-3 min-w-0">
                            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 text-sm font-bold text-primary">
                              {initials(s.companyName)}
                            </div>
                            <div className="min-w-0">
                              <p className="text-sm font-semibold text-foreground truncate">
                                {s.companyName}
                              </p>
                              {s.contactName && (
                                <p className="text-[11px] text-muted-foreground truncate">
                                  {s.contactName}
                                </p>
                              )}
                            </div>
                          </div>
                          <div
                            className="flex items-center gap-1.5 shrink-0"
                            onClick={(e) => e.stopPropagation()}
                          >
                            {s.category && (
                              <span
                                className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${CATEGORY_COLORS[s.category] ?? "bg-muted text-muted-foreground"}`}
                              >
                                {s.category}
                              </span>
                            )}
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setEditingSupplier({
                                  id: s.id,
                                  form: {
                                    companyName: s.companyName,
                                    contactName: s.contactName ?? "",
                                    phone: s.phone ?? "",
                                    email: s.email ?? "",
                                    address: s.address ?? "",
                                    website: s.website ?? "",
                                    category: s.category ?? "Pièces",
                                    accountNumber: s.accountNumber ?? "",
                                    notes: s.notes ?? "",
                                    cardImageUrl: s.cardImageUrl ?? "",
                                    tags: s.tags ?? "",
                                  },
                                });
                              }}
                              className="p-1 rounded text-muted-foreground hover:text-primary opacity-0 group-hover:opacity-100 transition-all"
                              title="Modifier"
                            >
                              <PencilSimple size={13} weight="duotone" />
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDelete(s.id);
                              }}
                              disabled={isMutating}
                              className="p-1 rounded text-muted-foreground hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                              title="Supprimer"
                            >
                              <Trash size={13} weight="duotone" />
                            </button>
                          </div>
                        </div>

                        <Separator className="mb-3" />

                        {/* Contact info */}
                        <div className="space-y-1.5 mb-3">
                          {s.phone && (
                            <div className="flex items-center gap-2">
                              <Phone
                                size={12}
                                weight="duotone"
                                className="text-primary shrink-0"
                              />
                              <span className="text-xs text-foreground">
                                {s.phone}
                              </span>
                            </div>
                          )}
                          {s.email && (
                            <div className="flex items-center gap-2">
                              <Envelope
                                size={12}
                                weight="duotone"
                                className="text-primary shrink-0"
                              />
                              <span className="text-xs text-foreground truncate">
                                {s.email}
                              </span>
                            </div>
                          )}
                          {s.address && (
                            <div className="flex items-center gap-2">
                              <MapPin
                                size={12}
                                weight="duotone"
                                className="text-primary shrink-0"
                              />
                              <span className="text-xs text-muted-foreground truncate">
                                {s.address}
                              </span>
                            </div>
                          )}
                          {s.website && (
                            <div
                              className="flex items-center gap-2"
                              onClick={(e) => e.stopPropagation()}
                            >
                              <Globe
                                size={12}
                                weight="duotone"
                                className="text-primary shrink-0"
                              />
                              <a
                                href={
                                  s.website.startsWith("http")
                                    ? s.website
                                    : `https://${s.website}`
                                }
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-xs text-primary hover:underline truncate"
                                onClick={(e) => e.stopPropagation()}
                              >
                                {s.website}
                              </a>
                            </div>
                          )}
                          {!s.phone && !s.email && !s.address && !s.website && (
                            <p className="text-xs text-muted-foreground italic">
                              Aucune coordonnée.
                            </p>
                          )}
                        </div>

                        {/* Business card thumb */}
                        {s.cardImageUrl && (
                          <div className="mb-3 rounded-lg overflow-hidden border border-border bg-muted/20 h-16">
                            <img
                              src={s.cardImageUrl}
                              alt="Carte d'affaire"
                              className="w-full h-full object-cover"
                              onError={(e) => {
                                (e.target as HTMLImageElement).style.display =
                                  "none";
                              }}
                            />
                          </div>
                        )}

                        {/* Tags */}
                        {tags.length > 0 && (
                          <div
                            className="flex flex-wrap gap-1 mb-3"
                            onClick={(e) => e.stopPropagation()}
                          >
                            {tags.slice(0, 3).map((tag, i) => (
                              <span
                                key={i}
                                className="text-[10px] px-1.5 py-0.5 rounded-full bg-primary/10 text-primary font-medium"
                              >
                                {tag}
                              </span>
                            ))}
                            {tags.length > 3 && (
                              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-muted text-muted-foreground font-medium">
                                +{tags.length - 3}
                              </span>
                            )}
                          </div>
                        )}

                        {/* Notes preview */}
                        {s.notes && (
                          <div onClick={(e) => e.stopPropagation()}>
                            <button
                              onClick={() => toggleNotes(s.id)}
                              className="flex items-center gap-1 text-[11px] text-muted-foreground hover:text-foreground transition-colors mb-1.5"
                            >
                              <Note size={11} weight="duotone" />
                              Notes
                              {notesExpanded ? (
                                <CaretUp size={10} />
                              ) : (
                                <CaretDown size={10} />
                              )}
                            </button>
                            {notesExpanded && (
                              <p className="text-xs text-muted-foreground bg-muted/30 rounded-lg px-3 py-2 border border-border leading-relaxed whitespace-pre-wrap">
                                {s.notes}
                              </p>
                            )}
                          </div>
                        )}

                        {/* Account # badge */}
                        {s.accountNumber && (
                          <div
                            className="mt-2 flex items-center gap-1.5"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <span className="text-[10px] text-muted-foreground">
                              Compte #
                            </span>
                            <span className="text-[10px] font-mono font-semibold text-foreground bg-muted px-1.5 py-0.5 rounded">
                              {s.accountNumber}
                            </span>
                          </div>
                        )}

                        {/* Footer hint */}
                        <p className="text-[10px] text-muted-foreground mt-3 opacity-0 group-hover:opacity-100 transition-opacity">
                          Cliquer pour voir tous les détails →
                        </p>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
            <p className="text-xs text-muted-foreground text-right pt-4">
              {filtered.length} fournisseur{filtered.length !== 1 ? "s" : ""}
            </p>
          </>
        )}
      </div>
    </section>
  );
}
