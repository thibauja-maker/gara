import { useState, useCallback } from "react";
import { useQuery, useMutation } from "@animaapp/playground-react-sdk";
import type { InventoryItem } from "@/lib/anima-sdk-stub";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Package,
  Plus,
  Trash,
  FloppyDisk,
  X,
  MagnifyingGlass,
  Drop,
  Wrench,
  Tag,
  PencilSimple,
  Warning,
} from "@phosphor-icons/react";
import { ContextMenu, type ContextMenuItem } from "@/components/ui/context-menu-portal";

const CATEGORY_OPTIONS = [
  "Huiles & Fluides",
  "Filtres",
  "Forfait service",
  "Pneus",
  "Freins",
  "Pièces",
  "Divers",
];

const UNIT_OPTIONS = ["litre", "unité", "forfait", "paire", "ensemble", "kg", "L"];

// Stock-level thresholds — can be configured per item; here we use a simple global default
const LOW_STOCK_THRESHOLD = 5;

const DEFAULT_ITEMS = [
  { name: "Huile moteur (par litre)", unit: "litre", price: 8.99, category: "Huiles & Fluides" },
  { name: "Filtre à huile", unit: "unité", price: 14.99, category: "Filtres" },
  { name: "Filtre à air", unit: "unité", price: 19.99, category: "Filtres" },
  { name: "Filtre à habitacle", unit: "unité", price: 24.99, category: "Filtres" },
  { name: "Changement d'huile complet — Moteur 4 cylindres", unit: "forfait", price: 79.99, category: "Forfait service" },
  { name: "Changement d'huile complet — Moteur 8 cylindres", unit: "forfait", price: 109.99, category: "Forfait service" },
];

const categoryIcon: Record<string, React.ReactNode> = {
  "Huiles & Fluides": <Drop size={14} weight="duotone" className="text-blue-500" />,
  "Filtres": <Package size={14} weight="duotone" className="text-amber-500" />,
  "Forfait service": <Wrench size={14} weight="duotone" className="text-primary" />,
  "Pneus": <Package size={14} weight="duotone" className="text-zinc-500" />,
  "Freins": <Package size={14} weight="duotone" className="text-red-500" />,
  "Pièces": <Package size={14} weight="duotone" className="text-green-600" />,
  "Divers": <Tag size={14} weight="duotone" className="text-muted-foreground" />,
};

const fmt = (n: number) =>
  n.toLocaleString("fr-CA", { style: "currency", currency: "CAD" });

const EMPTY_FORM = { name: "", unit: "unité", price: "", category: "Pièces", stock: "" };
const EMPTY_EDIT = { name: "", unit: "unité", price: "", category: "Pièces", stock: "" };

export default function Inventory({ orgId }: { orgId: string }) {
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("Tous");
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [formError, setFormError] = useState("");
  const [seeding, setSeeding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState(EMPTY_EDIT);
  const [editError, setEditError] = useState("");
  const [stockFilter, setStockFilter] = useState<"tous" | "bas">("tous");

  // context menu
  const [ctxMenu, setCtxMenu] = useState<{ x: number; y: number; itemId: string } | null>(null);

  const handleContextMenu = useCallback((e: React.MouseEvent, itemId: string) => {
    e.preventDefault();
    setCtxMenu({ x: e.clientX, y: e.clientY, itemId });
  }, []);

  // In-memory stock levels — persisted to localStorage per orgId
  const stockKey = `garagemanager_${orgId}_stock`;
  const getStock = (): Record<string, number> => {
    try { return JSON.parse(localStorage.getItem(stockKey) ?? "{}"); } catch { return {}; }
  };
  const setStock = (id: string, qty: number) => {
    const all = getStock();
    all[id] = qty;
    localStorage.setItem(stockKey, JSON.stringify(all));
  };
  const [stockMap, setStockMap] = useState<Record<string, number>>(() => getStock());
  const updateStock = (id: string, qty: number) => {
    setStock(id, qty);
    setStockMap((prev) => ({ ...prev, [id]: qty }));
  };

  const { data: items, isPending, error } = useQuery<InventoryItem>("InventoryItem", {
    where: { orgId },
    orderBy: { category: "asc" },
  });

  const { create, update, remove, isPending: isMutating } = useMutation<InventoryItem>("InventoryItem");

  const lowStockItems = (items ?? []).filter((item) => {
    const qty = stockMap[item.id] ?? 0;
    return qty <= LOW_STOCK_THRESHOLD;
  });

  const filtered = (items ?? []).filter((item) => {
    const matchSearch =
      !search ||
      item.name.toLowerCase().includes(search.toLowerCase()) ||
      (item.category ?? "").toLowerCase().includes(search.toLowerCase());
    const matchCat = categoryFilter === "Tous" || item.category === categoryFilter;
    const matchStock = stockFilter === "tous" || (stockMap[item.id] ?? 0) <= LOW_STOCK_THRESHOLD;
    return matchSearch && matchCat && matchStock;
  });

  const categories = ["Tous", ...Array.from(new Set((items ?? []).map((i) => i.category ?? "Divers").sort()))];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) { setFormError("Le nom est obligatoire."); return; }
    const price = parseFloat(form.price);
    if (isNaN(price) || price < 0) { setFormError("Le prix doit être un nombre valide."); return; }
    setFormError("");
    try {
      await create({
        orgId,
        name: form.name.trim(),
        unit: form.unit || undefined,
        price,
        category: form.category || undefined,
      });
      setForm(EMPTY_FORM);
      setShowAdd(false);
    } catch {
      setFormError("Erreur lors de l'ajout.");
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Supprimer cet article ?")) return;
    try { await remove(id); } catch { /* ignore */ }
  };

  const startEdit = (item: InventoryItem) => {
    setEditingId(item.id);
    setEditForm({
      name: item.name ?? "",
      unit: item.unitCost !== undefined ? String(item.unitCost) : "unité",
      price: String(item.unitPrice ?? 0),
      category: item.category ?? "Pièces",
      stock: "",
    });
    setEditError("");
    setShowAdd(false);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditForm(EMPTY_EDIT);
    setEditError("");
  };

  const handleEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editForm.name.trim()) { setEditError("Le nom est obligatoire."); return; }
    const price = parseFloat(editForm.price);
    if (isNaN(price) || price < 0) { setEditError("Le prix doit être un nombre valide."); return; }
    setEditError("");
    try {
      await update(editingId!, {
        name: editForm.name.trim(),
        unit: editForm.unit || undefined,
        price,
        category: editForm.category || undefined,
        orgId,
      });
      cancelEdit();
    } catch {
      setEditError("Erreur lors de la modification.");
    }
  };

  const seedDefaults = async () => {
    setSeeding(true);
    for (const item of DEFAULT_ITEMS) {
      try { await create({ ...item, orgId }); } catch { /* ignore */ }
    }
    setSeeding(false);
  };

  return (
    <section id="inventory" className="bg-background min-h-screen py-10 px-4 md:px-8 lg:px-12">
      {/* Header */}
      <div className="max-w-5xl mx-auto mb-7">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-3">
            <Package weight="duotone" className="w-6 h-6 text-primary" />
            <div>
              <h1 className="font-heading text-2xl font-semibold text-foreground tracking-tight">
                Inventaire & Prix
              </h1>
              <p className="text-sm text-muted-foreground">
                Articles, fournitures, huiles, filtres et forfaits de service.
              </p>
            </div>
          </div>
          <div className="flex gap-2 flex-wrap items-center">
            {lowStockItems.length > 0 && (
              <button
                onClick={() => setStockFilter(stockFilter === "bas" ? "tous" : "bas")}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                  stockFilter === "bas"
                    ? "bg-red-500 text-white border-red-500"
                    : "bg-red-500/10 text-red-500 border-red-500/30 hover:bg-red-500/20"
                }`}
              >
                <Warning size={13} weight="duotone" />
                {lowStockItems.length} article{lowStockItems.length !== 1 ? "s" : ""} en rupture
              </button>
            )}
            {(!items || items.length === 0) && !isPending && (
              <Button
                variant="outline"
                onClick={seedDefaults}
                disabled={seeding || isMutating}
                className="rounded-lg text-sm border-border gap-1.5"
              >
                {seeding ? "Ajout en cours…" : "Charger les articles par défaut"}
              </Button>
            )}
            <Button
              onClick={() => setShowAdd(!showAdd)}
              className="bg-primary text-primary-foreground rounded-lg text-sm font-medium gap-1.5 shadow-sm"
            >
              {showAdd ? <X size={15} weight="duotone" /> : <Plus size={15} weight="duotone" />}
              {showAdd ? "Annuler" : "Nouvel article"}
            </Button>
          </div>
        </div>
        <Separator className="mt-5" />
      </div>

      <div className="max-w-5xl mx-auto space-y-5">
        {/* Add form */}
        {showAdd && (
          <Card className="rounded-xl border border-primary/30 shadow-sm bg-card">
            <CardHeader className="pb-2 pt-5 px-5">
              <div className="flex items-center gap-2">
                <Plus weight="duotone" className="w-4 h-4 text-primary" />
                <CardTitle className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                  Ajouter un article / service
                </CardTitle>
              </div>
              <Separator className="mt-3" />
            </CardHeader>
            <CardContent className="px-5 pb-5">
              <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2 space-y-1.5">
                  <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                    Nom de l'article / service <span className="text-primary">*</span>
                  </Label>
                  <Input
                    value={form.name}
                    onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                    placeholder="Ex. : Huile moteur 5W-30 (par litre)"
                    className="rounded-lg border-border text-sm"
                    disabled={isMutating}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                    Catégorie
                  </Label>
                  <select
                    value={form.category}
                    onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
                    className="w-full h-9 rounded-lg border border-border bg-background text-sm px-3 text-foreground focus:outline-none focus:ring-1 focus:ring-ring"
                    disabled={isMutating}
                  >
                    {CATEGORY_OPTIONS.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                    Unité
                  </Label>
                  <select
                    value={form.unit}
                    onChange={(e) => setForm((f) => ({ ...f, unit: e.target.value }))}
                    className="w-full h-9 rounded-lg border border-border bg-background text-sm px-3 text-foreground focus:outline-none focus:ring-1 focus:ring-ring"
                    disabled={isMutating}
                  >
                    {UNIT_OPTIONS.map((u) => (
                      <option key={u} value={u}>{u}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                    Prix ($) <span className="text-primary">*</span>
                  </Label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    value={form.price}
                    onChange={(e) => setForm((f) => ({ ...f, price: e.target.value }))}
                    placeholder="0.00"
                    className="rounded-lg border-border text-sm"
                    disabled={isMutating}
                  />
                </div>
                {formError && (
                  <p className="sm:col-span-2 text-xs text-red-500">
                    {formError}
                  </p>
                )}
                <div className="sm:col-span-2 flex gap-2 pt-1">
                  <Button
                    type="submit"
                    disabled={isMutating}
                    className="bg-primary text-primary-foreground rounded-lg text-sm gap-1.5 shadow-sm"
                  >
                    <FloppyDisk size={15} weight="duotone" />
                    {isMutating ? "Enregistrement…" : "Enregistrer"}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => { setShowAdd(false); setFormError(""); }}
                    className="rounded-lg text-sm border-border"
                  >
                    Annuler
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Filters row */}
        <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center">
          <div className="relative min-w-[220px]">
            <MagnifyingGlass
              size={15}
              weight="duotone"
              className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
            />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Rechercher un article…"
              className="pl-9 rounded-lg border-border text-sm"
            />
          </div>
          <div className="flex flex-wrap gap-1.5">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setCategoryFilter(cat)}
                className={`px-2.5 py-1 rounded-full text-xs font-medium border transition-all duration-150 ${
                  categoryFilter === cat
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-background text-muted-foreground border-border hover:bg-muted"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Loading / error */}
        {isPending && (
          <div className="text-sm text-muted-foreground py-8 text-center">
            Chargement de l&#39;inventaire…
          </div>
        )}
        {error && (
          <div className="text-sm text-red-500 py-4">Erreur lors du chargement de l'inventaire.</div>
        )}

        {/* Items table */}
        {!isPending && !error && (
          <>
            {filtered.length === 0 ? (
              <div className="text-center py-16 text-muted-foreground text-sm">
                {search || categoryFilter !== "Tous"
                  ? "Aucun article ne correspond aux filtres."
                  : "Aucun article dans l'inventaire. Cliquez sur « Nouvel article » ou « Charger les articles par défaut »."}
              </div>
            ) : (
              <Card className="rounded-xl shadow-sm border border-border bg-card overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm border-collapse">
                    <thead>
                      <tr className="border-b border-border bg-muted/30">
                        <th className="text-left px-4 py-2.5 text-[10px] font-semibold text-muted-foreground uppercase tracking-widest whitespace-nowrap">
                          Article / Service
                        </th>
                        <th className="text-left px-4 py-2.5 text-[10px] font-semibold text-muted-foreground uppercase tracking-widest whitespace-nowrap">
                          Catégorie
                        </th>
                        <th className="text-left px-4 py-2.5 text-[10px] font-semibold text-muted-foreground uppercase tracking-widest whitespace-nowrap">
                          Unité
                        </th>
                        <th className="text-right px-4 py-2.5 text-[10px] font-semibold text-muted-foreground uppercase tracking-widest whitespace-nowrap">
                          Prix
                        </th>
                        <th className="text-right px-4 py-2.5 text-[10px] font-semibold text-muted-foreground uppercase tracking-widest whitespace-nowrap">
                          Stock
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {filtered.map((item, idx) =>
                        editingId === item.id ? (
                          /* ── Inline edit row ── */
                          <tr key={item.id} className="border-b border-primary/30 bg-primary/5">
                            <td colSpan={5} className="px-4 py-3">
                              <form onSubmit={handleEdit} className="grid grid-cols-1 sm:grid-cols-[1fr_160px_120px_100px_auto] gap-2 items-end">
                                <div className="space-y-1">
                                  <label className="text-[10px] text-muted-foreground uppercase tracking-wider">Nom</label>
                                  <Input
                                    value={editForm.name}
                                    onChange={(e) => setEditForm((f) => ({ ...f, name: e.target.value }))}
                                    className="h-8 rounded-lg text-sm border-border"
                                    disabled={isMutating}
                                    autoFocus
                                  />
                                </div>
                                <div className="space-y-1">
                                  <label className="text-[10px] text-muted-foreground uppercase tracking-wider">Catégorie</label>
                                  <select
                                    value={editForm.category}
                                    onChange={(e) => setEditForm((f) => ({ ...f, category: e.target.value }))}
                                    className="w-full h-8 rounded-lg border border-border bg-background text-sm px-2 text-foreground focus:outline-none focus:ring-1 focus:ring-ring"
                                    disabled={isMutating}
                                  >
                                    {CATEGORY_OPTIONS.map((c) => (
                                      <option key={c} value={c}>{c}</option>
                                    ))}
                                  </select>
                                </div>
                                <div className="space-y-1">
                                  <label className="text-[10px] text-muted-foreground uppercase tracking-wider">Unité</label>
                                  <select
                                    value={editForm.unit}
                                    onChange={(e) => setEditForm((f) => ({ ...f, unit: e.target.value }))}
                                    className="w-full h-8 rounded-lg border border-border bg-background text-sm px-2 text-foreground focus:outline-none focus:ring-1 focus:ring-ring"
                                    disabled={isMutating}
                                  >
                                    {UNIT_OPTIONS.map((u) => (
                                      <option key={u} value={u}>{u}</option>
                                    ))}
                                  </select>
                                </div>
                                <div className="space-y-1">
                                  <label className="text-[10px] text-muted-foreground uppercase tracking-wider">Prix ($)</label>
                                  <Input
                                    type="number"
                                    step="0.01"
                                    min="0"
                                    value={editForm.price}
                                    onChange={(e) => setEditForm((f) => ({ ...f, price: e.target.value }))}
                                    className="h-8 rounded-lg text-sm border-border"
                                    disabled={isMutating}
                                  />
                                </div>
                                <div className="flex gap-1 items-end pb-0.5">
                                  <button
                                    type="submit"
                                    disabled={isMutating}
                                    className="h-8 px-3 rounded-lg bg-primary text-primary-foreground text-xs font-semibold flex items-center gap-1.5 disabled:opacity-50"
                                    title="Enregistrer"
                                  >
                                    <FloppyDisk size={13} weight="duotone" />
                                    {isMutating ? "…" : "Sauv."}
                                  </button>
                                  <button
                                    type="button"
                                    onClick={cancelEdit}
                                    disabled={isMutating}
                                    className="h-8 px-2 rounded-lg border border-border text-muted-foreground hover:text-foreground text-xs flex items-center gap-1 disabled:opacity-50"
                                    title="Annuler"
                                  >
                                    <X size={13} weight="duotone" />
                                  </button>
                                </div>
                                {editError && (
                                  <p className="col-span-full text-xs text-red-500 pt-1">{editError}</p>
                                )}
                              </form>
                            </td>
                          </tr>
                        ) : (
                          /* ── Normal display row ── */
                          <tr
                            key={item.id}
                            className={`border-b border-border transition-colors hover:bg-muted/40 group ${idx % 2 === 0 ? "" : "bg-muted/10"}`}
                            onContextMenu={(e) => handleContextMenu(e, item.id)}
                          >
                            <td className="px-4 py-3 font-medium text-foreground">
                              <div className="flex items-center gap-2">
                                {item.name}
                                {(stockMap[item.id] ?? 0) <= LOW_STOCK_THRESHOLD && (stockMap[item.id] ?? 0) > 0 && (
                                  <span title="Stock bas" className="inline-flex items-center gap-0.5 text-[10px] text-amber-500 font-semibold">
                                    <Warning size={11} weight="fill" /> Bas
                                  </span>
                                )}
                                {(stockMap[item.id] ?? 0) === 0 && (
                                  <span title="Rupture de stock" className="inline-flex items-center gap-0.5 text-[10px] text-red-500 font-semibold">
                                    <Warning size={11} weight="fill" /> Rupture
                                  </span>
                                )}
                              </div>
                            </td>
                            <td className="px-4 py-3">
                              <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
                                {categoryIcon[item.category ?? "Divers"] ?? categoryIcon["Divers"]}
                                {item.category ?? "—"}
                              </span>
                            </td>
                            <td className="px-4 py-3">
                              <Badge className="text-xs rounded-full bg-muted text-muted-foreground border-0 px-2 py-0.5">
                                {item.unit ?? "—"}
                              </Badge>
                            </td>
                            <td className="px-4 py-3 text-right font-mono font-semibold text-foreground whitespace-nowrap">
                              {fmt(item.price ?? 0)}
                            </td>
                            <td className="px-4 py-3">
                              <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                <div className="flex items-center gap-1 bg-muted rounded-lg px-1 py-0.5">
                                  <button
                                    onClick={() => updateStock(item.id, Math.max(0, (stockMap[item.id] ?? 0) - 1))}
                                    className="w-5 h-5 flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors text-xs font-bold"
                                    title="Décrémenter"
                                  >−</button>
                                  <span className={`w-7 text-center text-xs font-mono font-semibold ${
                                    (stockMap[item.id] ?? 0) === 0 ? "text-red-500" :
                                    (stockMap[item.id] ?? 0) <= LOW_STOCK_THRESHOLD ? "text-amber-500" : "text-foreground"
                                  }`}>
                                    {stockMap[item.id] ?? 0}
                                  </span>
                                  <button
                                    onClick={() => updateStock(item.id, (stockMap[item.id] ?? 0) + 1)}
                                    className="w-5 h-5 flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors text-xs font-bold"
                                    title="Incrémenter"
                                  >+</button>
                                </div>
                                <button
                                  onClick={() => startEdit(item)}
                                  disabled={isMutating}
                                  className="text-muted-foreground hover:text-primary transition-colors"
                                  title="Modifier"
                                >
                                  <PencilSimple size={14} weight="duotone" />
                                </button>
                                <button
                                  onClick={() => handleDelete(item.id)}
                                  disabled={isMutating}
                                  className="text-muted-foreground hover:text-red-500 transition-colors"
                                  title="Supprimer"
                                >
                                  <Trash size={14} weight="duotone" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        )
                      )}
                    </tbody>
                  </table>
                </div>
              </Card>
            )}
            <p className="text-xs text-muted-foreground text-right pt-1">
              {filtered.length} article{filtered.length !== 1 ? "s" : ""}
            </p>
          </>
        )}
      </div>

      {ctxMenu && (() => {
        const item = (items ?? []).find((x) => x.id === ctxMenu.itemId);
        if (!item) return null;
        const menuItems: ContextMenuItem[] = [
          {
            label: "Modifier",
            icon: <PencilSimple size={13} weight="duotone" />,
            onClick: () => startEdit(item),
            disabled: isMutating,
          },
          {
            label: "Supprimer",
            icon: <Trash size={13} weight="duotone" />,
            onClick: () => handleDelete(item.id),
            danger: true,
            disabled: isMutating,
          },
        ];
        return (
          <ContextMenu
            x={ctxMenu.x}
            y={ctxMenu.y}
            items={menuItems}
            onClose={() => setCtxMenu(null)}
          />
        );
      })()}
    </section>
  );
}
