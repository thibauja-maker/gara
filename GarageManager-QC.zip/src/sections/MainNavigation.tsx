import { useState } from "react";
import { useLocalStorage } from "@/hooks/use-local-storage";
import type { ShopGeneral } from "@/components/ShopSettingsModal";
import type { WorkstationSession } from "@/components/WorkstationLogin";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { canAccess, type SectionId } from "@/lib/permissions";
import AppLogo from "@/components/AppLogo";
import {
  ClipboardText,
  CalendarBlank,
  Receipt,
  UsersThree,
  CaretLeft,
  CaretRight,
  Wrench,
  List,
  X,
  Package,
  ChartBar,
  FileText,
  Globe,
  Storefront,
} from "@phosphor-icons/react";

const navItems = [
  {
    label: "Ordres de travail",
    href: "#repair-orders",
    icon: ClipboardText,
    panelId: "repair-orders",
  },
  {
    label: "Calendrier",
    href: "#calendar",
    icon: CalendarBlank,
    panelId: "calendar",
  },
  {
    label: "Calendrier des Lifts",
    href: "#bays-schedule",
    icon: Wrench,
    panelId: "bays-schedule",
  },
  {
    label: "Clients",
    href: "#customers",
    icon: UsersThree,
    panelId: "customers",
  },
  {
    label: "Factures",
    href: "#invoices-taxes",
    icon: Receipt,
    panelId: "invoices-taxes",
  },
  {
    label: "Estimations",
    href: "#estimation",
    icon: FileText,
    panelId: "estimation",
  },
  {
    label: "Catalogue pièces",
    href: "#parts-catalog",
    icon: Package,
    panelId: "parts-catalog",
  },
  {
    label: "Inventaire",
    href: "#inventory",
    icon: Package,
    panelId: "inventory",
  },
  {
    label: "Rapports",
    href: "#reports",
    icon: ChartBar,
    panelId: "reports",
  },
  {
    label: "Fournisseurs",
    href: "#suppliers",
    icon: Storefront,
    panelId: "suppliers",
  },
  {
    label: "Intégrations",
    href: "#integrations",
    icon: Globe,
    panelId: "integrations",
  },
];

const DEFAULT_GENERAL: ShopGeneral = {
  shopName: "Nordic Garage",
  softwareName: "Ledger",
  accountHolder: "Marc Gagnon",
  accountHolderRole: "Gestionnaire",
  address: "",
  phone: "",
  email: "",
  tpsNumber: "",
  tvqNumber: "",
  currency: "CAD",
  language: "fr-CA",
  hoursOpen: "08:00",
  hoursClose: "18:00",
  lunchBreak: true,
};

export default function MainNavigation({
  activePanel = "dashboard",
  onNavigate,
  session,
}: {
  activePanel?: string;
  onNavigate?: (panelId: string) => void;
  session?: WorkstationSession;
}) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const orgId = session?.orgId ?? "default";
  const [shopGeneral] = useLocalStorage<ShopGeneral>(
    `garagemanager_${orgId}_shop_general`,
    DEFAULT_GENERAL,
  );

  const shopName = shopGeneral.shopName || "Nordic Garage";
  const softwareName = shopGeneral.softwareName || "Ledger";

  // Use session user info when available, fall back to shop settings
  const accountHolder =
    session?.userName ?? shopGeneral.accountHolder ?? "Marc Gagnon";
  const accountHolderRole =
    session?.userRole ?? shopGeneral.accountHolderRole ?? "Gestionnaire";
  const holderInitials =
    session?.userInitials ??
    accountHolder
      .split(" ")
      .map((w: string) => w[0] ?? "")
      .join("")
      .toUpperCase()
      .slice(0, 2);

  // Filter nav items by role
  const userRole = session?.userRole ?? "Admin";
  const visibleNavItems = navItems.filter((item) =>
    canAccess(userRole, item.panelId as SectionId),
  );

  const handleNavigate = (panelId: string) => {
    onNavigate?.(panelId);
    setMobileOpen(false);
  };

  const ExpandedHeader = () => (
    <div className="flex items-center justify-between px-3 h-14 shrink-0">
      <div className="flex items-center gap-2 min-w-0">
        <AppLogo className="h-9 w-auto object-contain shrink-0" />
      </div>
      <button
        onClick={() => setCollapsed(true)}
        className="w-8 h-8 shrink-0 flex items-center justify-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground transition-all duration-200"
        title="Collapse sidebar"
      >
        <CaretLeft weight="duotone" size={15} />
      </button>
    </div>
  );

  const CollapsedHeader = () => (
    <div className="flex items-center justify-center h-14 shrink-0">
      <button
        onClick={() => setCollapsed(false)}
        className="relative w-9 h-9 group rounded-md"
        title="Expand sidebar"
      >
        <span className="absolute inset-0 flex items-center justify-center transition-opacity group-hover:opacity-0">
          <AppLogo className="h-8 w-8 object-contain rounded-md" />
        </span>
        <span className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="w-7 h-7 rounded-md bg-muted flex items-center justify-center">
            <CaretRight
              weight="duotone"
              className="text-foreground"
              size={15}
            />
          </div>
        </span>
      </button>
    </div>
  );

  const NavContent = ({ isCollapsed }: { isCollapsed: boolean }) => (
    <nav className="flex-1 px-2 py-1 flex flex-col gap-0.5 overflow-y-auto">
      {visibleNavItems.map((item) => {
        const Icon = item.icon;
        const isActive = activePanel === item.panelId;
        return (
          <a
            key={item.panelId}
            href={item.href}
            onClick={(e) => {
              e.preventDefault();
              handleNavigate(item.panelId);
            }}
            title={isCollapsed ? item.label : undefined}
            className={`
              flex items-center gap-3 rounded-md transition-all duration-200 group
              ${isCollapsed ? "justify-center px-0 py-2.5" : "px-3 py-2.5"}
              ${
                isActive
                  ? "bg-accent text-accent-foreground font-medium"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              }
            `}
          >
            <Icon
              weight={isActive ? "duotone" : "duotone"}
              size={18}
              className={`shrink-0 ${isActive ? "text-primary" : "text-muted-foreground group-hover:text-foreground"}`}
            />
            {!isCollapsed && (
              <span className="text-sm truncate">{item.label}</span>
            )}
            {!isCollapsed && isActive && (
              <span className="ml-auto w-1 h-4 rounded-full bg-primary shrink-0" />
            )}
          </a>
        );
      })}
    </nav>
  );

  const UserArea = ({ isCollapsed }: { isCollapsed: boolean }) => (
    <div
      className={`shrink-0 px-2 py-3 flex items-center gap-3 ${
        isCollapsed ? "justify-center" : ""
      }`}
    >
      <Avatar className="w-8 h-8 shrink-0">
        <AvatarFallback className="bg-muted text-muted-foreground text-xs font-semibold">
          {holderInitials}
        </AvatarFallback>
      </Avatar>
      {!isCollapsed && (
        <div className="min-w-0 flex-1">
          <p className="text-xs font-semibold text-foreground truncate leading-tight">
            {accountHolder}
          </p>
          <p className="text-[10px] text-muted-foreground truncate leading-tight">
            {shopName}
          </p>
        </div>
      )}
      {!isCollapsed && (
        <Badge
          variant="outline"
          className="text-[9px] px-1.5 py-0 shrink-0 border-border text-muted-foreground"
        >
          {accountHolderRole}
        </Badge>
      )}
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <aside
        id="main-navigation"
        className={`
          hidden lg:flex flex-col bg-background border-r border-border
          transition-all duration-300 ease-out h-screen sticky top-0
          ${collapsed ? "w-16" : "w-60"}
        `}
      >
        {/* Brand / Header */}
        {collapsed ? <CollapsedHeader /> : <ExpandedHeader />}

        {/* Divider — binder accent */}
        <div className="px-3 shrink-0">
          <Separator className="bg-border" />
        </div>

        {/* Nav Items */}
        <NavContent isCollapsed={collapsed} />

        {/* Divider — binder accent */}
        <div className="px-3 shrink-0">
          <Separator className="bg-border" />
        </div>

        {/* User Area */}
        <UserArea isCollapsed={collapsed} />
      </aside>

      {/* Mobile: Hamburger Button */}
      <button
        className="lg:hidden fixed top-3 left-3 z-50 w-9 h-9 flex items-center justify-center rounded-md bg-background border border-border shadow-sm text-foreground"
        onClick={() => setMobileOpen(true)}
        title="Open menu"
      >
        <List weight="duotone" size={18} />
      </button>

      {/* Mobile: Overlay Drawer */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          {/* Backdrop */}
          <div
            className="absolute inset-0 bg-foreground/20 backdrop-blur-sm"
            onClick={() => setMobileOpen(false)}
          />

          {/* Drawer */}
          <div className="relative z-10 flex flex-col w-64 h-full bg-background border-r border-border shadow-xl">
            {/* Mobile Header */}
            <div className="flex items-center justify-between px-3 h-14 shrink-0">
              <div className="flex items-center gap-2 min-w-0">
                <div className="w-7 h-7 rounded-md bg-primary flex items-center justify-center shrink-0">
                  <Wrench
                    weight="duotone"
                    className="text-primary-foreground"
                    size={15}
                  />
                </div>
                <div className="min-w-0">
                  <span className="font-heading text-sm font-semibold text-foreground truncate block leading-tight">
                    {shopName}
                  </span>
                  <span className="text-[10px] text-muted-foreground tracking-wide uppercase truncate block leading-tight">
                    {softwareName}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setMobileOpen(false)}
                className="w-8 h-8 shrink-0 flex items-center justify-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground transition-all duration-200"
              >
                <X weight="duotone" size={16} />
              </button>
            </div>

            <div className="px-3 shrink-0">
              <Separator className="bg-border" />
            </div>

            {/* Mobile Nav */}
            <nav className="flex-1 px-2 py-1 flex flex-col gap-0.5 overflow-y-auto">
              {visibleNavItems.map((item) => {
                const Icon = item.icon;
                const isActive = activePanel === item.panelId;
                return (
                  <a
                    key={item.panelId}
                    href={item.href}
                    onClick={(e) => {
                      e.preventDefault();
                      handleNavigate(item.panelId);
                    }}
                    className={`
                      flex items-center gap-3 px-3 py-3 rounded-md transition-all duration-200 group
                      ${
                        isActive
                          ? "bg-accent text-accent-foreground font-medium"
                          : "text-muted-foreground hover:bg-muted hover:text-foreground"
                      }
                    `}
                  >
                    <Icon
                      weight="duotone"
                      size={20}
                      className={`shrink-0 ${isActive ? "text-primary" : "text-muted-foreground group-hover:text-foreground"}`}
                    />
                    <span className="text-sm">{item.label}</span>
                    {isActive && (
                      <span className="ml-auto w-1 h-4 rounded-full bg-primary shrink-0" />
                    )}
                  </a>
                );
              })}
            </nav>

            <div className="px-3 shrink-0">
              <Separator className="bg-border" />
            </div>

            {/* Mobile User Area */}
            <div className="shrink-0 px-3 py-4 flex items-center gap-3">
              <Avatar className="w-9 h-9 shrink-0">
                <AvatarFallback className="bg-muted text-muted-foreground text-xs font-semibold">
                  {holderInitials}
                </AvatarFallback>
              </Avatar>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold text-foreground truncate leading-tight">
                  {accountHolder}
                </p>
                <p className="text-xs text-muted-foreground truncate leading-tight">
                  {shopName}
                </p>
              </div>
              <Badge
                variant="outline"
                className="text-[10px] px-1.5 py-0 shrink-0 border-border text-muted-foreground"
              >
                {accountHolderRole}
              </Badge>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
