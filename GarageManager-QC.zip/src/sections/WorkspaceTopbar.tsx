import { useState, useRef, useEffect } from "react";
import { useLazyQuery } from "@animaapp/playground-react-sdk";
import type { Customer, RepairOrder } from "@/lib/anima-sdk-stub";
import type { WorkstationSession } from "@/components/WorkstationLogin";
import {
  canManageSettings,
  canManageWorkstations,
  canAccessBilling,
} from "@/lib/permissions";
import { useLocalStorage } from "@/hooks/use-local-storage";
import type { ShopGeneral } from "@/components/ShopSettingsModal";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useTheme } from "@/context/ThemeContext";
import ThemeCustomizer from "@/components/ThemeCustomizer";
import ProfileModal from "@/components/ProfileModal";
import ShopSettingsModal from "@/components/ShopSettingsModal";
import BillingModal from "@/components/BillingModal";
import WorkstationsManager from "@/components/WorkstationsManager";
import {
  Bell,
  MagnifyingGlass,
  Plus,
  CaretDown,
  User,
  Gear,
  Receipt,
  CalendarBlank,
  ClipboardText,
  X,
  Sun,
  Moon,
  PaintBrush,
  Monitor,
  ArrowsClockwise,
  Eye,
  EyeSlash,
} from "@phosphor-icons/react";
import { usePriceVisibility } from "@/context/PriceVisibilityContext";

const notifications = [
  {
    id: 1,
    type: "job",
    text: "WO-2402 — Freins terminés · Lift 1",
    time: "il y a 3 min",
    unread: true,
  },
  {
    id: 2,
    type: "invoice",
    text: "FAC-2024-047 en attente d'approbation",
    time: "il y a 18 min",
    unread: true,
  },
  {
    id: 3,
    type: "client",
    text: "Sophie B. — véhicule prêt pour ramassage",
    time: "il y a 45 min",
    unread: true,
  },
  {
    id: 4,
    type: "job",
    text: "WO-2405 · Diagnostic complété",
    time: "il y a 2 h",
    unread: false,
  },
];

const quickActions = [
  { label: "Nouvel ordre", icon: ClipboardText, action: "repair-orders" },
  { label: "Nouvelle facture", icon: Receipt, action: "invoices-taxes" },
  { label: "Rendez-vous", icon: CalendarBlank, action: "calendar" },
];

const notifTypeColor: Record<string, string> = {
  job: "bg-blue-500",
  invoice: "bg-amber-500",
  client: "bg-emerald-500",
};

export default function WorkspaceTopbar({
  onNavigate,
  session,
  onLogout,
}: {
  onNavigate?: (p: string) => void;
  session?: WorkstationSession;
  onLogout?: () => void;
}) {
  const [searchValue, setSearchValue] = useState("");
  const [searchResults, setSearchResults] = useState<
    Array<{ type: string; label: string; sub: string; panel: string }>
  >([]);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searching, setSearching] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const [notifOpen, setNotifOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [quickOpen, setQuickOpen] = useState(false);
  const [customizerOpen, setCustomizerOpen] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showBilling, setShowBilling] = useState(false);
  const [showWorkstations, setShowWorkstations] = useState(false);
  const { theme, setMode } = useTheme();

  const { query: queryCustomers } = useLazyQuery<Customer>("Customer");
  const { query: queryOrders } = useLazyQuery<RepairOrder>("RepairOrder");

  // ── Global search ────────────────────────────────────────────────────────
  const orgId = session?.orgId ?? "default";

  useEffect(() => {
    const handler = setTimeout(async () => {
      const q = searchValue.trim();
      if (q.length < 2) {
        setSearchResults([]);
        setSearchOpen(false);
        return;
      }
      setSearching(true);
      try {
        const [customers, orders] = await Promise.all([
          queryCustomers({
            where: { orgId },
          }),
          queryOrders({
            where: { orgId },
          }),
        ]);
        const results: Array<{
          type: string;
          label: string;
          sub: string;
          panel: string;
        }> = [
          ...customers.map((c) => ({
            type: "Client",
            label: c.name,
            sub: c.vehicleInfo + (c.phone ? ` · ${c.phone}` : ""),
            panel: "customers",
          })),
          ...orders.map((o) => ({
            type: "Facture",
            label: `${o.orderNumber} — ${o.customerName}`,
            sub: `${o.status} · ${o.total.toLocaleString("fr-CA", { style: "currency", currency: "CAD" })}`,
            panel: "invoices-taxes",
          })),
        ];
        setSearchResults(results);
        setSearchOpen(results.length > 0);
      } catch {
        /* ignore */
      }
      setSearching(false);
    }, 300);
    return () => clearTimeout(handler);
  }, [searchValue, orgId]);

  // Close search on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setSearchOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);
  const DEFAULT_GENERAL: ShopGeneral = {
    shopName: "Nordic Garage",
    softwareName: "Ledger",
    accountHolder: "Marc Gagnon",
    accountHolderRole: "Gestionnaire",
    address: "",
    phone: "",
    email: "",
    tpsNumber: "",
    tvqNumber: "",
    currency: "CAD",
    language: "fr-CA",
    hoursOpen: "08:00",
    hoursClose: "18:00",
    lunchBreak: true,
  };
  const [shopGeneral] = useLocalStorage<ShopGeneral>(
    `garagemanager_${orgId}_shop_general`,
    DEFAULT_GENERAL,
  );

  const { pricesVisible, togglePrices } = usePriceVisibility();
  const unreadCount = notifications.filter((n) => n.unread).length;
  const isDark = theme.mode === "dark";

  const displayName =
    session?.userName ?? shopGeneral.accountHolder ?? "Marc Gagnon";
  const displayEmail =
    session?.userEmail ?? shopGeneral.email ?? "marc@garagemanager.ca";
  const holderRole =
    session?.userRole ?? shopGeneral.accountHolderRole ?? "Gestionnaire";
  const initials =
    session?.userInitials ??
    displayName
      .split(" ")
      .map((p: string) => p[0])
      .slice(0, 2)
      .join("")
      .toUpperCase();

  return (
    <>
      <header className="bg-card border-b border-border h-14 flex items-center px-4 gap-3 w-full shrink-0 z-20 relative">
        {/* Quick Create */}
        <div className="relative">
          <button
            onClick={() => {
              setQuickOpen((p) => !p);
              setNotifOpen(false);
              setMenuOpen(false);
            }}
            className="flex items-center gap-1.5 bg-primary text-white text-[13px] font-medium px-3 py-1.5 rounded-md hover:opacity-90 transition-opacity shadow-sm"
          >
            <Plus size={14} weight="bold" />
            <span className="hidden sm:inline">Créer</span>
            <CaretDown size={11} weight="bold" />
          </button>
          {quickOpen && (
            <div className="absolute left-0 top-full mt-1.5 w-44 bg-card border border-border rounded-lg shadow-dropdown z-50 overflow-hidden py-1">
              {quickActions.map((a) => {
                const Icon = a.icon;
                return (
                  <button
                    key={a.label}
                    onClick={() => {
                      onNavigate?.(a.action);
                      setQuickOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 text-[13px] text-foreground hover:bg-muted transition-colors"
                  >
                    <Icon size={14} weight="duotone" className="text-primary" />
                    {a.label}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Global Search */}
        <div className="flex-1 max-w-lg mx-auto relative" ref={searchRef}>
          <MagnifyingGlass
            size={14}
            className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none z-10"
          />
          <Input
            type="search"
            placeholder="Recherche rapide — client, plaque, facture, ordre…"
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            onFocus={() => {
              if (searchResults.length > 0) setSearchOpen(true);
            }}
            className="pl-8 h-8 text-[13px] bg-muted/50 border-transparent focus:border-primary focus:bg-card transition-all duration-150 rounded-md w-full"
          />
          {searchValue && (
            <button
              onClick={() => {
                setSearchValue("");
                setSearchResults([]);
                setSearchOpen(false);
              }}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground z-10"
            >
              <X size={12} />
            </button>
          )}
          {/* Dropdown results */}
          {searchOpen && (
            <div className="absolute left-0 right-0 top-full mt-1.5 bg-card border border-border rounded-xl shadow-xl z-50 overflow-hidden">
              {searching ? (
                <div className="px-4 py-3 text-xs text-muted-foreground">
                  Recherche…
                </div>
              ) : (
                <>
                  {searchResults.map((r, i) => (
                    <button
                      key={i}
                      onClick={() => {
                        onNavigate?.(r.panel);
                        setSearchOpen(false);
                        setSearchValue("");
                        setSearchResults([]);
                      }}
                      className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-muted transition-colors text-left border-b border-border/50 last:border-0"
                    >
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-primary/10 text-primary font-semibold shrink-0">
                        {r.type}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="text-[13px] font-medium text-foreground truncate">
                          {r.label}
                        </p>
                        <p className="text-[11px] text-muted-foreground truncate">
                          {r.sub}
                        </p>
                      </div>
                    </button>
                  ))}
                  {searchResults.length === 0 && (
                    <div className="px-4 py-3 text-xs text-muted-foreground">
                      Aucun résultat pour « {searchValue} »
                    </div>
                  )}
                </>
              )}
            </div>
          )}
        </div>

        {/* Right actions */}
        <div className="flex items-center gap-1 shrink-0">
          {/* Dark/Light quick toggle */}
          <button
            onClick={() => setMode(isDark ? "light" : "dark")}
            title={isDark ? "Mode clair" : "Mode sombre"}
            className="w-8 h-8 flex items-center justify-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
          >
            {isDark ? (
              <Sun size={16} weight="fill" className="text-amber-400" />
            ) : (
              <Moon size={16} weight="duotone" />
            )}
          </button>

          {/* Theme customizer */}
          <button
            onClick={() => setCustomizerOpen((p) => !p)}
            title="Personnaliser le thème"
            className={`w-8 h-8 flex items-center justify-center rounded-md transition-colors ${customizerOpen ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-muted hover:text-foreground"}`}
          >
            <PaintBrush size={16} weight="duotone" />
          </button>

          <div className="h-5 w-px bg-border mx-0.5" />

          {/* Price visibility toggle — discrete, near bell */}
          <button
            onClick={togglePrices}
            title={pricesVisible ? "Masquer les prix" : "Afficher les prix"}
            className={`w-8 h-8 flex items-center justify-center rounded-md transition-colors ${
              !pricesVisible
                ? "bg-amber-500/15 text-amber-500 hover:bg-amber-500/25"
                : "text-muted-foreground hover:bg-muted hover:text-foreground"
            }`}
          >
            {pricesVisible ? (
              <Eye size={15} weight="duotone" />
            ) : (
              <EyeSlash size={15} weight="fill" className="text-amber-500" />
            )}
          </button>

          {/* Notifications */}
          <div className="relative">
            <button
              onClick={() => {
                setNotifOpen((p) => !p);
                setMenuOpen(false);
                setQuickOpen(false);
              }}
              className="relative w-8 h-8 flex items-center justify-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
            >
              <Bell
                size={17}
                weight={unreadCount > 0 ? "fill" : "regular"}
                className={unreadCount > 0 ? "text-primary" : ""}
              />
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full border border-card" />
              )}
            </button>
            {notifOpen && (
              <div className="absolute right-0 top-full mt-1.5 w-80 bg-card border border-border rounded-xl shadow-dropdown z-50 overflow-hidden">
                <div className="px-4 py-3 border-b border-border flex items-center justify-between">
                  <span className="text-[13px] font-semibold text-foreground">
                    Notifications
                  </span>
                  <Badge className="bg-primary/10 text-primary text-[10px] px-2 py-0.5 rounded-full font-medium border-0">
                    {unreadCount} nouvelles
                  </Badge>
                </div>
                <ul className="max-h-72 overflow-y-auto">
                  {notifications.map((notif) => (
                    <li
                      key={notif.id}
                      className={`flex items-start gap-3 px-4 py-3 cursor-pointer transition-colors border-b border-border/50 last:border-0 hover:bg-muted/50 ${notif.unread ? "bg-primary/5" : ""}`}
                    >
                      <span
                        className={`mt-1.5 w-2 h-2 rounded-full shrink-0 ${notif.unread ? notifTypeColor[notif.type] : "bg-transparent"}`}
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-[13px] text-foreground leading-snug">
                          {notif.text}
                        </p>
                        <p className="text-[11px] text-muted-foreground mt-0.5">
                          {notif.time}
                        </p>
                      </div>
                    </li>
                  ))}
                </ul>
                <div className="px-4 py-2.5 border-t border-border bg-muted/30">
                  <button className="text-[12px] text-primary hover:underline w-full text-center font-medium">
                    Voir tout →
                  </button>
                </div>
              </div>
            )}
          </div>

          <div className="h-5 w-px bg-border mx-0.5" />

          {/* Workstation badge */}
          {session && (
            <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-muted/60 border border-border text-xs text-muted-foreground mr-1">
              <Monitor
                size={12}
                weight="duotone"
                className="text-primary shrink-0"
              />
              <span className="font-medium text-foreground">
                {session.workstationName}
              </span>
            </div>
          )}

          {/* User Menu */}
          <div className="relative">
            <button
              onClick={() => {
                setMenuOpen((p) => !p);
                setNotifOpen(false);
                setQuickOpen(false);
              }}
              className="flex items-center gap-2 pl-1 pr-2 py-1 rounded-md hover:bg-muted transition-colors group"
            >
              <div className="w-7 h-7 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center shrink-0">
                <span className="text-white text-[11px] font-bold leading-none">
                  {initials}
                </span>
              </div>
              <div className="hidden sm:flex flex-col items-start">
                <span className="text-[12px] font-semibold text-foreground leading-tight">
                  {displayName}
                </span>
                <span className="text-[10px] text-muted-foreground leading-tight">
                  {holderRole}
                </span>
              </div>
              <CaretDown
                size={11}
                className="text-muted-foreground hidden sm:block"
              />
            </button>
            {menuOpen && (
              <div className="absolute right-0 top-full mt-1.5 w-56 bg-card border border-border rounded-xl shadow-dropdown z-50 overflow-hidden">
                <div className="px-4 py-3 border-b border-border">
                  <p className="text-[13px] font-semibold text-foreground">
                    {displayName}
                  </p>
                  <p className="text-[11px] text-muted-foreground">
                    {displayEmail}
                  </p>
                </div>
                <ul className="py-1">
                  <li>
                    <button
                      onClick={() => {
                        setShowProfile(true);
                        setMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-4 py-2.5 text-[13px] text-foreground hover:bg-muted transition-colors"
                    >
                      <User
                        size={14}
                        weight="duotone"
                        className="text-muted-foreground"
                      />
                      Mon profil
                    </button>
                  </li>
                  {canManageSettings(holderRole) && (
                    <li>
                      <button
                        onClick={() => {
                          setShowSettings(true);
                          setMenuOpen(false);
                        }}
                        className="w-full flex items-center gap-2.5 px-4 py-2.5 text-[13px] text-foreground hover:bg-muted transition-colors"
                      >
                        <Gear
                          size={14}
                          weight="duotone"
                          className="text-muted-foreground"
                        />
                        Paramètres atelier
                      </button>
                    </li>
                  )}
                  {canManageWorkstations(holderRole) && (
                    <li>
                      <button
                        onClick={() => {
                          setShowWorkstations(true);
                          setMenuOpen(false);
                        }}
                        className="w-full flex items-center gap-2.5 px-4 py-2.5 text-[13px] text-foreground hover:bg-muted transition-colors"
                      >
                        <Monitor
                          size={14}
                          weight="duotone"
                          className="text-muted-foreground"
                        />
                        Postes de travail
                      </button>
                    </li>
                  )}
                  {canAccessBilling(holderRole) && (
                    <li>
                      <button
                        onClick={() => {
                          setShowBilling(true);
                          setMenuOpen(false);
                        }}
                        className="w-full flex items-center gap-2.5 px-4 py-2.5 text-[13px] text-foreground hover:bg-muted transition-colors"
                      >
                        <Receipt
                          size={14}
                          weight="duotone"
                          className="text-muted-foreground"
                        />
                        Facturation
                      </button>
                    </li>
                  )}
                  <li className="border-t border-border mt-1 pt-1">
                    {session && onLogout && (
                      <button
                        onClick={() => {
                          onLogout();
                          setMenuOpen(false);
                        }}
                        className="w-full flex items-center gap-2.5 px-4 py-2.5 text-[13px] text-foreground hover:bg-muted transition-colors"
                      >
                        <ArrowsClockwise
                          size={14}
                          weight="duotone"
                          className="text-muted-foreground"
                        />
                        Changer de poste
                      </button>
                    )}
                  </li>
                </ul>
              </div>
            )}
          </div>
        </div>

        {/* Click outside */}
        {(notifOpen || menuOpen || quickOpen) && (
          <div
            className="fixed inset-0 z-40"
            onClick={() => {
              setNotifOpen(false);
              setMenuOpen(false);
              setQuickOpen(false);
            }}
          />
        )}
      </header>

      {/* Theme Customizer Drawer */}
      {customizerOpen && (
        <>
          <div
            className="fixed inset-0 z-40 bg-black/30 backdrop-blur-sm"
            onClick={() => setCustomizerOpen(false)}
          />
          <div className="fixed right-0 top-0 bottom-0 z-50">
            <ThemeCustomizer onClose={() => setCustomizerOpen(false)} />
          </div>
        </>
      )}

      {/* Profile Modal */}
      {showProfile && <ProfileModal onClose={() => setShowProfile(false)} orgId={orgId} />}

      {/* Shop Settings Modal */}
      {showSettings && (
        <ShopSettingsModal
          onClose={() => setShowSettings(false)}
          orgId={orgId}
        />
      )}

      {/* Billing Modal */}
      {showBilling && <BillingModal onClose={() => setShowBilling(false)} />}

      {/* Workstations Manager */}
      {showWorkstations && (
        <WorkstationsManager onClose={() => setShowWorkstations(false)} orgId={orgId} />
      )}
    </>
  );
}
