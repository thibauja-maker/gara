import { useMemo } from "react";
import { useQuery } from "@animaapp/playground-react-sdk";
import type { RepairOrder, Customer, Appointment } from "@/lib/anima-sdk-stub";
import { usePriceVisibility } from "@/context/PriceVisibilityContext";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  Receipt,
  UsersThree,
  CalendarBlank,
  CurrencyDollar,
  Warning,
  Car,
  CheckCircle,
} from "@phosphor-icons/react";

function fmt(n: number) {
  return n.toLocaleString("fr-CA", { style: "currency", currency: "CAD" });
}

export default function Dashboard({ orgId }: { orgId: string }) {
  const { pricesVisible } = usePriceVisibility();
  const fmtC = (n: number) => (pricesVisible ? fmt(n) : "• • • •");

  const today = new Date();
  const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);

  const { data: allOrders } = useQuery<RepairOrder>("RepairOrder", {
    where: { orgId },
    orderBy: { date: "desc" },
  });
  const { data: allCustomers } = useQuery<Customer>("Customer", { where: { orgId } });
  const { data: todayAppts } = useQuery<Appointment>("Appointment", { where: { orgId } });

  const orders = allOrders ?? [];
  const customers = allCustomers ?? [];
  const appointments = (todayAppts ?? []).filter((a) => {
    const d = new Date(a.date);
    return d >= todayStart && d < new Date(todayStart.getTime() + 86400000);
  });

  // ── KPIs ──────────────────────────────────────────────────────────────────
  const openOrders = orders.filter((o) => o.status !== "Payée");
  const monthRevenue = useMemo(() => {
    return orders
      .filter((o) => o.status === "Payée" && new Date(o.date) >= monthStart)
      .reduce((s, o) => s + o.total, 0);
  }, [orders]);

  const unpaidTotal = useMemo(() => {
    return orders
      .filter((o) => o.status === "Non payée" || o.status === "Partielle")
      .reduce((s, o) => s + o.total, 0);
  }, [orders]);

  const todayOrders = orders.filter((o) => new Date(o.date) >= todayStart);

  const statusColor: Record<string, string> = {
    "Non payée": "text-red-500 bg-red-50 dark:bg-red-900/20",
    "Partielle": "text-amber-500 bg-amber-50 dark:bg-amber-900/20",
    "Payée": "text-green-600 bg-green-50 dark:bg-green-900/20",
    "Brouillon": "text-blue-500 bg-blue-50 dark:bg-blue-900/20",
  };

  const kpis = [
    {
      label: "Ordres ouverts",
      value: String(openOrders.length),
      sub: `${appointments.length} RDV aujourd\'hui`,
      icon: Car,
      color: "text-blue-500",
      bg: "bg-blue-500/10",
    },
    {
      label: "Clients enregistrés",
      value: String(customers.length),
      sub: `${customers.filter((c) => new Date(c.createdAt) >= monthStart).length} ce mois`,
      icon: UsersThree,
      color: "text-violet-500",
      bg: "bg-violet-500/10",
    },
    {
      label: "Revenus du mois",
      value: fmtC(monthRevenue),
      sub: `${orders.filter((o) => o.status === "Payée" && new Date(o.date) >= monthStart).length} factures payées`,
      icon: CurrencyDollar,
      color: "text-emerald-500",
      bg: "bg-emerald-500/10",
    },
    {
      label: "Impayés en attente",
      value: fmtC(unpaidTotal),
      sub: `${orders.filter((o) => o.status === "Non payée").length} factures impayées`,
      icon: Warning,
      color: "text-amber-500",
      bg: "bg-amber-500/10",
    },
  ];

  return (
    <section className="bg-background min-h-screen px-4 py-8 md:px-8">
      <div className="max-w-6xl mx-auto">

        {/* Header */}
        <div className="mb-7">
          <p className="text-xs font-mono tracking-widest text-muted-foreground uppercase mb-1">
            {today.toLocaleDateString("fr-CA", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
          </p>
          <h1 className="font-heading text-2xl font-semibold text-foreground tracking-tight">
            Tableau de bord
          </h1>
          <div className="mt-3 h-px bg-border w-full" />
        </div>

        {/* KPI cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {kpis.map((k) => {
            const Icon = k.icon;
            return (
              <Card key={k.label} className="bg-card border border-border rounded-xl shadow-sm">
                <CardContent className="p-4">
                  <div className={`w-9 h-9 rounded-xl ${k.bg} flex items-center justify-center mb-3`}>
                    <Icon size={18} weight="duotone" className={k.color} />
                  </div>
                  <p className="text-xl font-bold font-heading text-foreground leading-tight">{k.value}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{k.label}</p>
                  {k.sub && <p className="text-[10px] text-muted-foreground mt-1.5 border-t border-border pt-1">{k.sub}</p>}
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

          {/* Factures du jour */}
          <Card className="bg-card border border-border rounded-xl shadow-sm overflow-hidden">
            <div className="px-5 pt-5 pb-3 flex items-center justify-between">
              <div>
                <p className="text-xs font-mono tracking-widest text-muted-foreground uppercase">Aujourd&#39;hui</p>
                <h2 className="font-heading text-sm font-semibold text-foreground mt-0.5">
                  Factures du jour ({todayOrders.length})
                </h2>
              </div>
              <Receipt size={16} weight="duotone" className="text-primary" />
            </div>
            <Separator />
            {todayOrders.length === 0 ? (
              <div className="py-10 text-center text-xs text-muted-foreground">
                Aucune facture aujourd&#39;hui.
              </div>
            ) : (
              <div className="divide-y divide-border">
                {todayOrders.slice(0, 5).map((o) => (
                  <div key={o.id} className="flex items-center gap-3 px-5 py-3 hover:bg-muted/30 transition-colors">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <span className="text-xs font-bold text-primary">{o.customerName.charAt(0).toUpperCase()}</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{o.customerName}</p>
                      <p className="text-[11px] text-muted-foreground truncate">{o.vehicleInfo}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-xs font-mono font-semibold text-foreground">{fmtC(o.total)}</p>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${statusColor[o.status] ?? "text-muted-foreground bg-muted"}`}>
                        {o.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>

          {/* Rendez-vous du jour */}
          <Card className="bg-card border border-border rounded-xl shadow-sm overflow-hidden">
            <div className="px-5 pt-5 pb-3 flex items-center justify-between">
              <div>
                <p className="text-xs font-mono tracking-widest text-muted-foreground uppercase">Calendrier</p>
                <h2 className="font-heading text-sm font-semibold text-foreground mt-0.5">
                  Rendez-vous du jour ({appointments.length})
                </h2>
              </div>
              <CalendarBlank size={16} weight="duotone" className="text-primary" />
            </div>
            <Separator />
            {appointments.length === 0 ? (
              <div className="py-10 text-center text-xs text-muted-foreground">
                Aucun rendez-vous aujourd&#39;hui.
              </div>
            ) : (
              <div className="divide-y divide-border">
                {appointments.slice(0, 5).map((a) => {
                  const statusCfg: Record<string, string> = {
                    "scheduled": "text-sky-600 bg-sky-50 dark:bg-sky-950/40",
                    "in-progress": "text-blue-600 bg-blue-50 dark:bg-blue-950/40",
                    "completed": "text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40",
                  };
                  const h = Number(a.startHour);
                  const hh = Math.floor(h);
                  const mm = h % 1 === 0.5 ? "30" : "00";
                  return (
                    <div key={a.id} className="flex items-center gap-3 px-5 py-3 hover:bg-muted/30 transition-colors">
                      <div className="w-12 text-center shrink-0">
                        <p className="text-xs font-mono font-bold text-foreground">{`${String(hh).padStart(2, "0")}:${mm}`}</p>
                        <p className="text-[10px] text-muted-foreground">{a.bay}</p>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{a.title}</p>
                        <p className="text-[11px] text-muted-foreground truncate">{a.customerName}</p>
                      </div>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${statusCfg[a.status] ?? "text-muted-foreground bg-muted"}`}>
                        {a.status === "scheduled" ? "Planifié" : a.status === "in-progress" ? "En cours" : "Terminé"}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </Card>

          {/* Ordres ouverts */}
          <Card className="bg-card border border-border rounded-xl shadow-sm overflow-hidden lg:col-span-2">
            <div className="px-5 pt-5 pb-3 flex items-center justify-between">
              <div>
                <p className="text-xs font-mono tracking-widest text-muted-foreground uppercase">Ordres actifs</p>
                <h2 className="font-heading text-sm font-semibold text-foreground mt-0.5">
                  Factures ouvertes / impayées ({openOrders.length})
                </h2>
              </div>
              <Warning size={16} weight="duotone" className="text-amber-500" />
            </div>
            <Separator />
            {openOrders.length === 0 ? (
              <div className="py-10 text-center text-xs text-muted-foreground">
                <CheckCircle size={20} weight="duotone" className="text-emerald-500 mx-auto mb-2" />
                Tout est à jour — aucun impayé.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border bg-muted/30">
                      {["Numéro", "Client", "Véhicule", "Date", "Statut", "Total"].map((h) => (
                        <th key={h} className="text-left px-4 py-2.5 text-[10px] font-semibold text-muted-foreground uppercase tracking-widest whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {openOrders.slice(0, 8).map((o) => (
                      <tr key={o.id} className="border-b border-border hover:bg-muted/30 transition-colors">
                        <td className="px-4 py-3 font-mono text-xs font-semibold text-foreground whitespace-nowrap">{o.orderNumber}</td>
                        <td className="px-4 py-3 font-medium text-foreground">{o.customerName}</td>
                        <td className="px-4 py-3 text-xs text-muted-foreground">{o.vehicleInfo}</td>
                        <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">
                          {new Date(o.date).toLocaleDateString("fr-CA")}
                        </td>
                        <td className="px-4 py-3">
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColor[o.status] ?? "text-muted-foreground bg-muted"}`}>
                            {o.status}
                          </span>
                        </td>
                        <td className="px-4 py-3 font-mono text-xs font-bold text-foreground">{fmtC(o.total)}</td>
                      </tr>
                    ))}
                  </tbody>
                  {openOrders.length > 0 && (
                    <tfoot>
                      <tr className="bg-muted/40">
                        <td colSpan={5} className="px-4 py-3 font-bold text-foreground text-xs">Total impayé</td>
                        <td className="px-4 py-3 font-mono font-bold text-amber-500 text-xs">{fmtC(unpaidTotal)}</td>
                      </tr>
                    </tfoot>
                  )}
                </table>
              </div>
            )}
          </Card>
        </div>
      </div>
    </section>
  );
}
