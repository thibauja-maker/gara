import { useState, useEffect, useCallback } from "react";
import { useQuery, useMutation, useLazyQuery } from "@animaapp/playground-react-sdk";
import type { RepairOrder, Customer, RepairOrderItem } from "@/lib/anima-sdk-stub";
import { usePriceVisibility } from "@/context/PriceVisibilityContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Label } from "@/components/ui/label";
import type { InvoicePrefill } from "../GarageApp";
import {
  Car,
  User,
  Wrench,
  Package,
  Drop,
  Receipt,
  CreditCard,
  Printer,
  Plus,
  Trash,
  CheckCircle,
  Clock,
  Warning,
  CaretDown,
  CaretUp,
  Calculator,
  List,
  X,
  FloppyDisk,
  Eye,
  CaretRight,
  PencilSimple,
  PaperPlaneTilt,
} from "@phosphor-icons/react";
import SendInvoiceModal, { type SendInvoiceData } from "@/components/SendInvoiceModal";
import PrintInvoiceModal, { type PrintInvoiceData } from "@/components/PrintInvoiceModal";

const GST_RATE = 0.05;
const QST_RATE = 0.09975;

const paymentStatusOptions = ["Non payée", "Partielle", "Payée"];
const paymentMethodOptions = ["Comptant", "Carte de crédit", "Débit", "Virement", "Chèque"];

type LineItem = { id: number; description: string; partNumber: string; qty: number; unitPrice: number };
type LaborItem = { id: number; description: string; hours: number; rate: number };
type SupplyItem = { id: number; description: string; amount: number };

// ── helpers ──────────────────────────────────────────────────────────────────
function parseVehicles(raw: string | undefined, primary: string): string[] {
  if (raw) {
    try {
      const arr = JSON.parse(raw);
      if (Array.isArray(arr) && arr.length > 0) {
        return arr.map((v: unknown) => {
          if (typeof v === "string") return v;
          if (v && typeof v === "object") {
            const obj = v as Record<string, string>;
            // Structured vehicle entry: build label from fields
            if (obj.label) return obj.label;
            const parts = [obj.annee, obj.marque, obj.modele].filter(Boolean).join(" ");
            return parts || primary || "Véhicule";
          }
          return primary || "Véhicule";
        });
      }
    } catch { /* fall through */ }
  }
  return primary ? [primary] : [];
}

const TIRE_TEMPLATE = {
  customer: "",
  phone: "",
  vehicle: "",
  plate: "",
  mileage: "",
  mechanic: "",
  description: "Installation de pneus",
  parts: [
    { id: 1, description: "Pneu (unité)", partNumber: "", qty: 4, unitPrice: 129.99 },
    { id: 2, description: "Valve (unité)", partNumber: "", qty: 4, unitPrice: 3.5 },
  ] as LineItem[],
  labor: [
    { id: 1, description: "Installation pneus + balancement", hours: 1.0, rate: 110.0 },
  ] as LaborItem[],
  supplies: [
    { id: 1, description: "Frais d\'environnement", amount: 5.0 },
  ] as SupplyItem[],
};

const EMPTY_TEMPLATE = {
  customer: "",
  phone: "",
  vehicle: "",
  plate: "",
  mileage: "",
  mechanic: "",
  description: "",
  parts: [{ id: 1, description: "", partNumber: "", qty: 1, unitPrice: 0 }] as LineItem[],
  labor: [{ id: 1, description: "", hours: 0, rate: 110.0 }] as LaborItem[],
  supplies: [] as SupplyItem[],
};

// ── VehiclePicker ─────────────────────────────────────────────────────────────
function VehiclePicker({
  vehicles,
  selected,
  onSelect,
  onAddNew,
}: {
  vehicles: string[];
  selected: string;
  onSelect: (v: string) => void;
  onAddNew: (v: string) => void;
}) {
  const [showNew, setShowNew] = useState(false);
  const [newVal, setNewVal] = useState("");

  return (
    <div className="space-y-2">
      <div className="flex flex-col gap-1.5">
        {vehicles.map((v, i) => (
          <button
            key={i}
            type="button"
            onClick={() => onSelect(v)}
            className={`flex items-center gap-2 w-full px-3 py-2 rounded-lg border text-left text-xs transition-all ${
              selected === v
                ? "border-primary bg-primary/10 text-foreground font-medium"
                : "border-border bg-background text-muted-foreground hover:bg-muted"
            }`}
          >
            <Car size={13} weight="duotone" className={selected === v ? "text-primary" : "text-muted-foreground"} />
            <span className="flex-1 truncate">{v}</span>
            {selected === v && <CheckCircle size={13} weight="fill" className="text-primary shrink-0" />}
          </button>
        ))}
      </div>

      {showNew ? (
        <div className="flex items-center gap-2 mt-1">
          <Input
            value={newVal}
            onChange={(e) => setNewVal(e.target.value)}
            placeholder="Ex. : Toyota RAV4 2020"
            className="h-8 text-xs rounded-lg border-border flex-1"
            onKeyDown={(e) => {
              if (e.key === "Enter" && newVal.trim()) {
                onAddNew(newVal.trim());
                setNewVal("");
                setShowNew(false);
              }
              if (e.key === "Escape") setShowNew(false);
            }}
            autoFocus
          />
          <button
            type="button"
            onClick={() => {
              if (newVal.trim()) { onAddNew(newVal.trim()); setNewVal(""); setShowNew(false); }
            }}
            className="text-primary text-xs font-medium hover:underline"
          >
            OK
          </button>
          <button type="button" onClick={() => setShowNew(false)} className="text-muted-foreground hover:text-foreground">
            <X size={13} weight="bold" />
          </button>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => setShowNew(true)}
          className="flex items-center gap-1 text-[11px] text-muted-foreground hover:text-foreground mt-1 transition-colors"
        >
          <Plus size={11} weight="duotone" />
          Nouveau véhicule
        </button>
      )}
    </div>
  );
}

// ── main component ────────────────────────────────────────────────────────────
export default function InvoicesTaxes({
  prefill,
  onPrefillConsumed,
  orgId,
}: {
  prefill: InvoicePrefill | null;
  onPrefillConsumed: () => void;
  orgId: string;
}) {
  const [activeTab, setActiveTab] = useState<"new" | "list">("new");

  // form state
  const [customerName, setCustomerName] = useState("");
  const [phone, setPhone] = useState("");
  const [vehicleInfo, setVehicleInfo] = useState("");
  const [plate, setPlate] = useState("");
  const [mileage, setMileage] = useState("");
  const [mechanic, setMechanic] = useState("");
  const [jobDesc, setJobDesc] = useState("");
  const [parts, setParts] = useState<LineItem[]>([{ id: 1, description: "", partNumber: "", qty: 1, unitPrice: 0 }]);
  const [labor, setLabor] = useState<LaborItem[]>([{ id: 1, description: "", hours: 0, rate: 110.0 }]);
  const [supplies, setSupplies] = useState<SupplyItem[]>([]);
  const [paymentStatus, setPaymentStatus] = useState("Non payée");
  const [paymentMethod, setPaymentMethod] = useState("Carte de crédit");
  const [amountPaid, setAmountPaid] = useState("0.00");
  const [saveMsg, setSaveMsg] = useState("");
  const [openSections, setOpenSections] = useState({
    customer: true, parts: true, labor: true, supplies: true, taxes: true, payment: true,
  });

  // vehicle picker state — which customer is chosen from the list
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  const [showCustomerPicker, setShowCustomerPicker] = useState(false);
  const [customerSearch, setCustomerSearch] = useState("");

  const toggleSection = (key: keyof typeof openSections) =>
    setOpenSections((prev) => ({ ...prev, [key]: !prev[key] }));

  // SDK
  const { data: savedOrders, isPending: loadingOrders, error: ordersError } = useQuery<RepairOrder>("RepairOrder", {
    where: { orgId },
    orderBy: { createdAt: "desc" },
  });
  const { data: allCustomers } = useQuery<Customer>("Customer", { where: { orgId }, orderBy: { name: "asc" } });
  const { create: createOrder, update: updateOrder, isPending: savingOrder } = useMutation<RepairOrder>("RepairOrder");
  const { create: createItem, remove: removeItem } = useMutation<RepairOrderItem>("RepairOrderItem");
  const { remove: removeOrder, isPending: deletingOrder } = useMutation<RepairOrder>("RepairOrder");
  const { update: updateCustomer } = useMutation<Customer>("Customer");
  const { query: queryItems } = useLazyQuery<RepairOrderItem>("RepairOrderItem");

  // edit mode
  const [editingOrderId, setEditingOrderId] = useState<string | null>(null);
  const [editingOrderNumber, setEditingOrderNumber] = useState<string | null>(null);

  // send invoice modal
  const [sendingInvoice, setSendingInvoice] = useState<SendInvoiceData | null>(null);
  // print/pdf modal
  const [printingInvoice, setPrintingInvoice] = useState<PrintInvoiceData | null>(null);

  // read shop settings from localStorage
  const getShopSettings = () => {
    try {
      const raw = localStorage.getItem(`garagemanager_${orgId}_shopGeneral`);
      if (raw) return JSON.parse(raw) as Record<string, string>;
    } catch { /* ignore */ }
    return {};
  };

  const buildPrintData = (
    orderNumber: string,
    dateStr: string,
    cName: string,
    cPhone: string,
    vInfo: string,
    platVal: string,
    milVal: string,
    mechVal: string,
    jobDescVal: string,
    partsVal: typeof parts,
    laborVal: typeof labor,
    suppliesVal: typeof supplies,
    stotal: number,
    tps: number,
    tvq: number,
    tot: number,
    pStatus: string,
    pMethod: string,
    aPaid: number,
  ): PrintInvoiceData => {
    const shop = getShopSettings();
    return {
      orderNumber,
      date: dateStr,
      customerName: cName,
      phone: cPhone || undefined,
      vehicleInfo: vInfo,
      plate: platVal || undefined,
      mileage: milVal || undefined,
      mechanic: mechVal || undefined,
      jobDesc: jobDescVal || undefined,
      parts: partsVal,
      labor: laborVal,
      supplies: suppliesVal,
      subtotal: stotal,
      tpsAmount: tps,
      tvqAmount: tvq,
      total: tot,
      paymentStatus: pStatus,
      paymentMethod: pMethod || undefined,
      amountPaid: aPaid,
      shopName: shop.name || "Garage",
      shopAddress: shop.address || undefined,
      shopPhone: shop.phone || undefined,
      shopTps: shop.tps || undefined,
      shopTvq: shop.tvq || undefined,
    };
  };

  // consume prefill when navigating from Customers page or Estimation
  useEffect(() => {
    if (prefill) {
      setCustomerName(prefill.customerName);
      setPhone(prefill.phone);
      setVehicleInfo(prefill.vehicleInfo);
      if (prefill.parts && prefill.parts.length > 0) {
        setParts(prefill.parts.map((p: LineItem) => ({ ...p })));
      }
      if (prefill.labor && prefill.labor.length > 0) {
        setLabor(prefill.labor.map((l: LaborItem) => ({ ...l })));
      }
      if (prefill.supplies && prefill.supplies.length > 0) {
        setSupplies(prefill.supplies.map((s: SupplyItem) => ({ ...s })));
      }
      if (prefill.sourceEstimateNumber) {
        setJobDesc(`Basé sur estimation ${prefill.sourceEstimateNumber}`);
      }
      setActiveTab("new");
      setOpenSections((s) => ({ ...s, customer: true, parts: true, labor: true, supplies: true }));
      setSaveMsg("");
      // find matching customer in list
      if (allCustomers) {
        const match = allCustomers.find(
          (c) => c.name.toLowerCase() === prefill.customerName.toLowerCase()
        );
        if (match) setSelectedCustomerId(match.id);
      }
      onPrefillConsumed();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prefill]);

  // calcs
  const partsSubtotal = parts.reduce((s, p) => s + p.qty * p.unitPrice, 0);
  const laborSubtotal = labor.reduce((s, l) => s + l.hours * l.rate, 0);
  const suppliesSubtotal = supplies.reduce((s, s2) => s + s2.amount, 0);
  const subtotal = partsSubtotal + laborSubtotal + suppliesSubtotal;
  const gst = subtotal * GST_RATE;
  const qst = subtotal * QST_RATE;
  const total = subtotal + gst + qst;
  const paid = parseFloat(amountPaid) || 0;
  const balanceDue = total - paid;

  const { pricesVisible } = usePriceVisibility();
  const fmt = (n: number) =>
    pricesVisible
      ? n.toLocaleString("fr-CA", { style: "currency", currency: "CAD" })
      : "• • • •";

  const nextOrderNumber = () => {
    const y = new Date().getFullYear();
    const n = (savedOrders?.length ?? 0) + 1;
    return `FAC-${y}-${String(n).padStart(4, "0")}`;
  };

  const resetForm = useCallback(() => {
    setCustomerName("");
    setPhone("");
    setVehicleInfo("");
    setPlate("");
    setMileage("");
    setMechanic("");
    setJobDesc("");
    setParts([{ id: 1, description: "", partNumber: "", qty: 1, unitPrice: 0 }]);
    setLabor([{ id: 1, description: "", hours: 0, rate: 110.0 }]);
    setSupplies([]);
    setPaymentStatus("Non payée");
    setPaymentMethod("Carte de crédit");
    setAmountPaid("0.00");
    setSaveMsg("");
    setSelectedCustomerId(null);
    setEditingOrderId(null);
    setEditingOrderNumber(null);
  }, []);

  const handleEditOrder = async (order: { id: string; orderNumber: string; customerName: string; vehicleInfo: string; status: string; total: number; tpsAmount: number; tvqAmount: number; subtotal: number }) => {
    // load items for this order
    let items: RepairOrderItem[] = [];
    try {
      items = queryItems({ where: { repairOrderId: order.id } });
    } catch { /* ignore */ }

    setEditingOrderId(order.id);
    setEditingOrderNumber(order.orderNumber);
    setCustomerName(order.customerName);
    setVehicleInfo(order.vehicleInfo === "—" ? "" : order.vehicleInfo);
    setPhone("");
    setPlate("");
    setMileage("");
    setMechanic("");
    setJobDesc("");
    setPaymentStatus(order.status);
    setAmountPaid("0.00");
    setSaveMsg("");

    const loadedParts: LineItem[] = [];

    items.forEach((item, i) => {
      loadedParts.push({ id: i + 1, description: item.description, partNumber: "", qty: item.qty ?? 1, unitPrice: item.unitPrice ?? item.rate ?? 0 });
    });

    if (loadedParts.length === 0) {
      loadedParts.push({ id: 1, description: "", partNumber: "", qty: 1, unitPrice: 0 });
    }

    setParts(loadedParts);
    setLabor([{ id: 1, description: "", hours: 0, rate: 110.0 }]);
    setSupplies([]);

    // try to match customer
    if (allCustomers) {
      const match = allCustomers.find(
        (c) => c.name.toLowerCase() === order.customerName.toLowerCase()
      );
      if (match) {
        setSelectedCustomerId(match.id);
        setPhone(match.phone ?? "");
      }
    }

    setActiveTab("new");
    setOpenSections({ customer: true, parts: true, labor: true, supplies: true, taxes: true, payment: true });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const loadTemplate = (tpl: typeof TIRE_TEMPLATE | typeof EMPTY_TEMPLATE) => {
    setCustomerName(tpl.customer);
    setPhone(tpl.phone);
    setVehicleInfo(tpl.vehicle);
    setPlate(tpl.plate);
    setMileage(tpl.mileage);
    setMechanic(tpl.mechanic);
    setJobDesc(tpl.description);
    setParts(tpl.parts.map((p) => ({ ...p })));
    setLabor(tpl.labor.map((l) => ({ ...l })));
    setSupplies(tpl.supplies.map((s) => ({ ...s })));
    setPaymentStatus("Non payée");
    setAmountPaid("0.00");
    setSaveMsg("");
    setSelectedCustomerId(null);
    setEditingOrderId(null);
    setEditingOrderNumber(null);
  };

  const handleSelectCustomer = (customerId: string) => {
    const c = allCustomers?.find((x) => x.id === customerId);
    if (!c) return;
    setSelectedCustomerId(customerId);
    setCustomerName(c.name);
    setPhone(c.phone ?? "");
    const vehicles = parseVehicles(c.vehicles as string | undefined, c.vehicleInfo ?? "");
    setVehicleInfo(vehicles[0] ?? c.vehicleInfo ?? "");
    setShowCustomerPicker(false);
    setCustomerSearch("");
  };

  const handleVehicleSelect = (v: string) => {
    setVehicleInfo(v);
  };

  const handleAddNewVehicleToCustomer = async (v: string) => {
    setVehicleInfo(v);
    // also persist to customer record if we have one selected
    if (selectedCustomerId) {
      const c = allCustomers?.find((x) => x.id === selectedCustomerId);
      if (c) {
        const existing = parseVehicles(c.vehicles as string | undefined, c.vehicleInfo ?? "");
        if (!existing.includes(v)) {
          const updated = [...existing, v];
          try {
            await updateCustomer(selectedCustomerId, { vehicles: JSON.stringify(updated) });
          } catch { /* ignore */ }
        }
      }
    }
  };

  const handleSave = async () => {
    if (!customerName.trim()) { setSaveMsg("⚠ Entrez le nom du client."); return; }
    setSaveMsg("");

    if (editingOrderId) {
      // ── UPDATE existing order ──
      try {
        await updateOrder(editingOrderId, {
          customerName: customerName.trim(),
          vehicleInfo: vehicleInfo.trim() || "—",
          status: paymentStatus,
          subtotal,
          tpsAmount: gst,
          tvqAmount: qst,
          total,
        });
        // replace all items: delete old, re-create new
        const oldItems = await queryItems({ where: { repairOrderId: editingOrderId } });
        for (const oi of oldItems) { await removeItem(oi.id); }
        for (const p of parts.filter((x) => x.description.trim())) {
          await createItem({ repairOrderId: editingOrderId, description: p.description, quantity: p.qty, rate: p.unitPrice });
        }
        for (const l of labor.filter((x) => x.description.trim())) {
          await createItem({ repairOrderId: editingOrderId, description: l.description, quantity: l.hours, rate: l.rate });
        }
        for (const s of supplies.filter((x) => x.description.trim())) {
          await createItem({ repairOrderId: editingOrderId, description: s.description, quantity: 1, rate: s.amount });
        }
        setSaveMsg(`✓ Facture ${editingOrderNumber} mise à jour.`);
        setEditingOrderId(null);
        setEditingOrderNumber(null);
        setActiveTab("list");
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : "Erreur inconnue";
        setSaveMsg(`Erreur : ${msg}`);
      }
      return;
    }

    // ── CREATE new order ──
    const orderNum = nextOrderNumber();
    try {
      const order = await createOrder({
        orgId,
        orderNumber: orderNum,
        customerName: customerName.trim(),
        vehicleInfo: vehicleInfo.trim() || "—",
        status: paymentStatus,
        subtotal,
        tpsAmount: gst,
        tvqAmount: qst,
        total,
        date: new Date(),
      });
      for (const p of parts.filter((x) => x.description.trim())) {
        await createItem({ repairOrderId: order.id, description: p.description, quantity: p.qty, rate: p.unitPrice });
      }
      for (const l of labor.filter((x) => x.description.trim())) {
        await createItem({ repairOrderId: order.id, description: l.description, quantity: l.hours, rate: l.rate });
      }
      for (const s of supplies.filter((x) => x.description.trim())) {
        await createItem({ repairOrderId: order.id, description: s.description, quantity: 1, rate: s.amount });
      }
      setSaveMsg(`✓ Facture ${orderNum} enregistrée.`);
      setActiveTab("list");
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Erreur inconnue";
      setSaveMsg(`Erreur : ${msg}`);
    }
  };

  const handleDeleteOrder = async (id: string) => {
    if (!confirm("Supprimer cette facture ?")) return;
    try { await removeOrder(id); } catch { /* ignore */ }
  };

  const statusColor: Record<string, string> = {
    "Non payée": "bg-accent text-accent-foreground",
    "Partielle": "bg-muted text-foreground",
    "Payée": "bg-primary text-primary-foreground",
  };

  const SectionHeader = ({
    label, icon, sectionKey, subtotalAmt,
  }: { label: string; icon: React.ReactNode; sectionKey: keyof typeof openSections; subtotalAmt?: number }) => (
    <button
      onClick={() => toggleSection(sectionKey)}
      className="w-full flex items-center justify-between py-3 px-1 group hover:bg-muted/40 rounded-md transition-all duration-150"
    >
      <div className="flex items-center gap-2 text-foreground">
        <span className="text-primary">{icon}</span>
        <span className="font-heading text-sm font-semibold tracking-wide uppercase text-muted-foreground">{label}</span>
      </div>
      <div className="flex items-center gap-3">
        {subtotalAmt !== undefined && (
          <span className="text-sm font-medium text-foreground">{fmt(subtotalAmt)}</span>
        )}
        <span className="text-muted-foreground">
          {openSections[sectionKey] ? <CaretUp size={14} weight="duotone" /> : <CaretDown size={14} weight="duotone" />}
        </span>
      </div>
    </button>
  );

  // Parts helpers
  const addPart = () => setParts((p) => [...p, { id: Date.now(), description: "", partNumber: "", qty: 1, unitPrice: 0 }]);
  const removePart = (id: number) => setParts((p) => p.filter((x) => x.id !== id));
  const updatePart = (id: number, field: string, value: string | number) =>
    setParts((p) => p.map((x) => (x.id === id ? { ...x, [field]: value } : x)));

  const addLabor = () => setLabor((l) => [...l, { id: Date.now(), description: "", hours: 0, rate: 110.0 }]);
  const removeLabor = (id: number) => setLabor((l) => l.filter((x) => x.id !== id));
  const updateLabor = (id: number, field: string, value: string | number) =>
    setLabor((l) => l.map((x) => (x.id === id ? { ...x, [field]: value } : x)));

  const addSupply = () => setSupplies((s) => [...s, { id: Date.now(), description: "", amount: 0 }]);
  const removeSupply = (id: number) => setSupplies((s) => s.filter((x) => x.id !== id));
  const updateSupply = (id: number, field: string, value: string | number) =>
    setSupplies((s) => s.map((x) => (x.id === id ? { ...x, [field]: value } : x)));

  // filtered customer list for picker
  const filteredCustomers = (allCustomers ?? []).filter((c) => {
    if (!customerSearch) return true;
    const q = customerSearch.toLowerCase();
    return c.name.toLowerCase().includes(q) || (c.vehicleInfo ?? "").toLowerCase().includes(q);
  });

  const selectedCustomer = selectedCustomerId
    ? allCustomers?.find((c) => c.id === selectedCustomerId)
    : null;

  const selectedCustomerVehicles = selectedCustomer
    ? parseVehicles(selectedCustomer.vehicles as string | undefined, selectedCustomer.vehicleInfo ?? "")
    : [];

  return (
    <section id="invoices-taxes" className="bg-background min-h-screen py-10 px-4 md:px-8">
      {/* Header */}
      <div className="max-w-6xl mx-auto mb-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="font-heading text-2xl font-bold text-foreground tracking-tight">
              Factures &amp; Taxes
            </h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              Créez et gérez vos factures manuellement — TPS &amp; TVQ Québec incluses.
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              variant={activeTab === "new" ? "default" : "outline"}
              size="sm"
              onClick={() => { resetForm(); setActiveTab("new"); }}
              className={`rounded-lg text-sm gap-1.5 ${activeTab === "new" ? "bg-primary text-primary-foreground" : "border-border"}`}
            >
              <Plus size={14} weight="duotone" />
              Nouvelle facture
            </Button>
            <Button
              variant={activeTab === "list" ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveTab("list")}
              className={`rounded-lg text-sm gap-1.5 ${activeTab === "list" ? "bg-primary text-primary-foreground" : "border-border"}`}
            >
              <List size={14} weight="duotone" />
              Toutes les factures
            </Button>
          </div>
        </div>
      </div>

      {/* ── LIST TAB ── */}
      {activeTab === "list" && (
        <div className="max-w-6xl mx-auto">
          {loadingOrders && (
            <div className="text-sm text-muted-foreground py-8 text-center">Chargement des factures…</div>
          )}
          {ordersError && (
            <div className="text-sm text-red-500 py-4">Erreur lors du chargement des factures.</div>
          )}
          {!loadingOrders && !ordersError && (
            <>
              {(!savedOrders || savedOrders.length === 0) ? (
                <div className="text-center py-16 text-muted-foreground text-sm">
                  Aucune facture enregistrée. Cliquez sur « Nouvelle facture » pour commencer.
                </div>
              ) : (
                <Card className="rounded-xl shadow-sm border border-border bg-card overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm border-collapse">
                      <thead>
                        <tr className="border-b border-border bg-muted/30">
                          {["Numéro", "Client", "Véhicule", "Date", "Statut", "Total TTC", ""].map((h) => (
                            <th key={h} className="text-left px-4 py-2.5 text-[10px] font-semibold text-muted-foreground uppercase tracking-widest whitespace-nowrap">
                              {h}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {savedOrders.map((order) => (
                          <tr key={order.id} className="border-b border-border hover:bg-muted/40 group transition-colors">
                            <td className="px-4 py-3 font-mono text-xs font-semibold text-foreground whitespace-nowrap">
                              {order.orderNumber}
                            </td>
                            <td className="px-4 py-3 text-sm font-medium text-foreground">{order.customerName}</td>
                            <td className="px-4 py-3 text-xs text-muted-foreground">{order.vehicleInfo}</td>
                            <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">
                              {new Date(order.date).toLocaleDateString("fr-CA")}
                            </td>
                            <td className="px-4 py-3">
                              <Badge className={`text-xs rounded-full border-0 px-2 py-0.5 ${statusColor[order.status] ?? "bg-muted text-muted-foreground"}`}>
                                {order.status}
                              </Badge>
                            </td>
                            <td className="px-4 py-3 text-right font-mono text-xs font-semibold text-foreground whitespace-nowrap">
                              {fmt(order.total)}
                            </td>
                            <td className="px-4 py-3">
                              <div className="flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button
                                  onClick={() => setSendingInvoice({
                                    orderNumber: order.orderNumber,
                                    customerName: order.customerName,
                                    vehicleInfo: order.vehicleInfo,
                                    total: order.total,
                                    email: allCustomers?.find(c => c.name.toLowerCase() === order.customerName.toLowerCase())?.email ?? undefined,
                                    phone: allCustomers?.find(c => c.name.toLowerCase() === order.customerName.toLowerCase())?.phone ?? undefined,
                                  })}
                                  className="text-muted-foreground hover:text-primary transition-colors"
                                  title="Envoyer au client"
                                >
                                  <PaperPlaneTilt size={14} weight="duotone" />
                                </button>
                                <button
                                  onClick={() => {
                                    const shop = getShopSettings();
                                    setPrintingInvoice({
                                      orderNumber: order.orderNumber,
                                      date: new Date(order.date).toLocaleDateString("fr-CA"),
                                      customerName: order.customerName,
                                      phone: allCustomers?.find(c => c.name.toLowerCase() === order.customerName.toLowerCase())?.phone ?? undefined,
                                      vehicleInfo: order.vehicleInfo,
                                      parts: [],
                                      labor: [],
                                      supplies: [],
                                      subtotal: order.subtotal,
                                      tpsAmount: order.tpsAmount,
                                      tvqAmount: order.tvqAmount,
                                      total: order.total,
                                      paymentStatus: order.status,
                                      shopName: shop.name || "Garage",
                                      shopAddress: shop.address || undefined,
                                      shopPhone: shop.phone || undefined,
                                      shopTps: shop.tps || undefined,
                                      shopTvq: shop.tvq || undefined,
                                    });
                                  }}
                                  className="text-muted-foreground hover:text-primary transition-colors"
                                  title="Imprimer / PDF"
                                >
                                  <Printer size={14} weight="duotone" />
                                </button>
                                <button
                                  onClick={() => handleEditOrder(order)}
                                  className="text-muted-foreground hover:text-primary transition-colors"
                                  title="Modifier"
                                >
                                  <PencilSimple size={14} weight="duotone" />
                                </button>
                                <button
                                  onClick={() => handleDeleteOrder(order.id)}
                                  disabled={deletingOrder}
                                  className="text-muted-foreground hover:text-red-500 transition-colors"
                                  title="Supprimer"
                                >
                                  <Trash size={14} weight="duotone" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </Card>
              )}
              <p className="text-xs text-muted-foreground text-right pt-2">
                {savedOrders?.length ?? 0} facture{(savedOrders?.length ?? 0) !== 1 ? "s" : ""}
              </p>
            </>
          )}
        </div>
      )}

      {/* ── NEW INVOICE TAB ── */}
      {activeTab === "new" && (
        <div className="max-w-6xl mx-auto">
          {/* Edit mode banner */}
          {editingOrderId && (
            <div className="mb-4 flex items-center justify-between px-4 py-2.5 rounded-xl border border-primary/40 bg-primary/5 text-sm">
              <div className="flex items-center gap-2 text-foreground font-medium">
                <PencilSimple size={15} weight="duotone" className="text-primary" />
                Modification de la facture <span className="font-mono font-bold text-primary">{editingOrderNumber}</span>
              </div>
              <button
                onClick={resetForm}
                className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1"
              >
                <X size={11} weight="bold" /> Annuler
              </button>
            </div>
          )}

          {/* Quick templates */}
          <div className="mb-5 flex flex-wrap gap-2 items-center">
            <span className="text-xs text-muted-foreground font-medium mr-1">Facture Rapide:</span>
            <button
              onClick={() => loadTemplate(TIRE_TEMPLATE)}
              className="px-3 py-1.5 rounded-full text-xs font-medium border border-border bg-background text-muted-foreground hover:bg-muted hover:text-foreground transition-all"
            >
              🔧 Facture pneus
            </button>
            <button
              onClick={() => loadTemplate(EMPTY_TEMPLATE)}
              className="px-3 py-1.5 rounded-full text-xs font-medium border border-border bg-background text-muted-foreground hover:bg-muted hover:text-foreground transition-all"
            >
              + Facture vide
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main form */}
            <div className="lg:col-span-2 space-y-4">

              {/* 1. Client */}
              <Card className="rounded-xl shadow-sm border border-border">
                <CardContent className="p-5">
                  <SectionHeader label="Client &amp; Bon de travail" icon={<User size={16} weight="duotone" />} sectionKey="customer" />
                  {openSections.customer && (
                    <>
                      <Separator className="mb-4" />

                      {/* Customer quick-pick */}
                      <div className="mb-4">
                        <div className="flex items-center justify-between mb-2">
                          <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                            Choisir un client enregistré
                          </Label>
                          {selectedCustomer && (
                            <button
                              type="button"
                              onClick={() => {
                                setSelectedCustomerId(null);
                                setCustomerName("");
                                setPhone("");
                                setVehicleInfo("");
                              }}
                              className="text-[11px] text-muted-foreground hover:text-foreground flex items-center gap-0.5"
                            >
                              <X size={10} weight="bold" /> Effacer
                            </button>
                          )}
                        </div>

                        {selectedCustomer ? (
                          <div className="flex items-center gap-3 px-3 py-2.5 rounded-lg border border-primary/40 bg-primary/5">
                            <div className="w-7 h-7 rounded-full bg-primary/15 flex items-center justify-center shrink-0">
                              <User size={13} weight="duotone" className="text-primary" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-semibold text-foreground truncate">{selectedCustomer.name}</p>
                              <p className="text-[11px] text-muted-foreground">{selectedCustomer.phone ?? ""}</p>
                            </div>
                            <button
                              type="button"
                              onClick={() => setShowCustomerPicker(!showCustomerPicker)}
                              className="text-xs text-primary hover:underline flex items-center gap-0.5 shrink-0"
                            >
                              Changer <CaretRight size={11} weight="bold" />
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setShowCustomerPicker(!showCustomerPicker)}
                            className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg border border-dashed border-border bg-background hover:bg-muted text-xs text-muted-foreground transition-all"
                          >
                            <span className="flex items-center gap-2">
                              <User size={13} weight="duotone" />
                              Sélectionner un client existant…
                            </span>
                            <CaretDown size={12} weight="duotone" />
                          </button>
                        )}

                        {/* Dropdown */}
                        {showCustomerPicker && (
                          <div className="mt-2 rounded-xl border border-border bg-card shadow-lg overflow-hidden z-10">
                            <div className="p-2 border-b border-border">
                              <Input
                                value={customerSearch}
                                onChange={(e) => setCustomerSearch(e.target.value)}
                                placeholder="Rechercher…"
                                className="h-7 text-xs rounded-md border-border"
                                autoFocus
                              />
                            </div>
                            <div className="max-h-48 overflow-y-auto">
                              {filteredCustomers.length === 0 ? (
                                <p className="text-xs text-muted-foreground text-center py-4">
                                  Aucun client trouvé.
                                </p>
                              ) : (
                                filteredCustomers.map((c) => (
                                  <button
                                    key={c.id}
                                    type="button"
                                    onClick={() => handleSelectCustomer(c.id)}
                                    className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-muted transition-colors text-left"
                                  >
                                    <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                                      <User size={11} weight="duotone" className="text-primary" />
                                    </div>
                                    <div className="min-w-0 flex-1">
                                      <p className="text-xs font-medium text-foreground truncate">{c.name}</p>
                                      <p className="text-[10px] text-muted-foreground truncate">{c.vehicleInfo}</p>
                                    </div>
                                    {selectedCustomerId === c.id && (
                                      <CheckCircle size={13} weight="fill" className="text-primary shrink-0" />
                                    )}
                                  </button>
                                ))
                              )}
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Vehicle picker — only shown when customer is selected */}
                      {selectedCustomer && selectedCustomerVehicles.length > 0 && (
                        <div className="mb-4">
                          <Label className="text-xs text-muted-foreground uppercase tracking-wide block mb-2">
                            Véhicule pour cette facture
                          </Label>
                          <VehiclePicker
                            vehicles={selectedCustomerVehicles}
                            selected={vehicleInfo}
                            onSelect={handleVehicleSelect}
                            onAddNew={handleAddNewVehicleToCustomer}
                          />
                        </div>
                      )}

                      <Separator className="mb-4" />

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-1.5">
                          <Label className="text-xs text-muted-foreground uppercase tracking-wide">Nom du client</Label>
                          <Input value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder="Martin Tremblay" className="rounded-lg border-border text-sm" />
                        </div>
                        <div className="space-y-1.5">
                          <Label className="text-xs text-muted-foreground uppercase tracking-wide">Téléphone</Label>
                          <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="(418) 555-0192" className="rounded-lg border-border text-sm" />
                        </div>
                        <div className="space-y-1.5">
                          <Label className="text-xs text-muted-foreground uppercase tracking-wide">Véhicule</Label>
                          <div className="flex items-center gap-2">
                            <Car size={15} weight="duotone" className="text-muted-foreground shrink-0" />
                            <Input value={vehicleInfo} onChange={(e) => setVehicleInfo(e.target.value)} placeholder="2019 Honda Civic EX" className="rounded-lg border-border text-sm" />
                          </div>
                        </div>
                        <div className="space-y-1.5">
                          <Label className="text-xs text-muted-foreground uppercase tracking-wide">Plaque / VIN</Label>
                          <Input value={plate} onChange={(e) => setPlate(e.target.value)} placeholder="ABC-1234" className="rounded-lg border-border text-sm" />
                        </div>
                        <div className="space-y-1.5">
                          <Label className="text-xs text-muted-foreground uppercase tracking-wide">Kilométrage</Label>
                          <Input value={mileage} onChange={(e) => setMileage(e.target.value)} placeholder="87 450 km" className="rounded-lg border-border text-sm" />
                        </div>
                        <div className="space-y-1.5">
                          <Label className="text-xs text-muted-foreground uppercase tracking-wide">Mécanicien assigné</Label>
                          <Input value={mechanic} onChange={(e) => setMechanic(e.target.value)} placeholder="Jean-François Côté" className="rounded-lg border-border text-sm" />
                        </div>
                        <div className="space-y-1.5 sm:col-span-2">
                          <Label className="text-xs text-muted-foreground uppercase tracking-wide">Description des travaux</Label>
                          <Input value={jobDesc} onChange={(e) => setJobDesc(e.target.value)} placeholder="Ex. : Installation pneus d&#39;hiver" className="rounded-lg border-border text-sm" />
                        </div>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              {/* 2. Parts */}
              <Card className="rounded-xl shadow-sm border border-border">
                <CardContent className="p-5">
                  <SectionHeader label="Pièces" icon={<Package size={16} weight="duotone" />} sectionKey="parts" subtotalAmt={partsSubtotal} />
                  {openSections.parts && (
                    <>
                      <Separator className="mb-4" />
                      <div className="hidden sm:grid grid-cols-12 gap-2 mb-2 px-1">
                        <span className="col-span-5 text-xs text-muted-foreground uppercase tracking-wide">Description</span>
                        <span className="col-span-2 text-xs text-muted-foreground uppercase tracking-wide">N° pièce</span>
                        <span className="col-span-1 text-xs text-muted-foreground uppercase tracking-wide text-center">Qté</span>
                        <span className="col-span-2 text-xs text-muted-foreground uppercase tracking-wide text-right">Prix unit.</span>
                        <span className="col-span-2 text-xs text-muted-foreground uppercase tracking-wide text-right">Total</span>
                      </div>
                      <div className="space-y-2">
                        {parts.map((part) => (
                          <div key={part.id} className="grid grid-cols-12 gap-2 items-center p-2 rounded-lg hover:bg-muted/30 group">
                            <div className="col-span-12 sm:col-span-5">
                              <Input value={part.description} onChange={(e) => updatePart(part.id, "description", e.target.value)} placeholder="Description" className="rounded-md border-border text-sm h-8" />
                            </div>
                            <div className="col-span-6 sm:col-span-2">
                              <Input value={part.partNumber} onChange={(e) => updatePart(part.id, "partNumber", e.target.value)} placeholder="N° pièce" className="rounded-md border-border text-sm h-8" />
                            </div>
                            <div className="col-span-2 sm:col-span-1">
                              <Input type="number" value={part.qty} onChange={(e) => updatePart(part.id, "qty", parseFloat(e.target.value) || 0)} className="rounded-md border-border text-sm h-8 text-center" />
                            </div>
                            <div className="col-span-4 sm:col-span-2">
                              <Input type="number" value={part.unitPrice} onChange={(e) => updatePart(part.id, "unitPrice", parseFloat(e.target.value) || 0)} className="rounded-md border-border text-sm h-8 text-right" />
                            </div>
                            <div className="col-span-10 sm:col-span-2 text-right">
                              <span className="text-sm font-medium text-foreground">{fmt(part.qty * part.unitPrice)}</span>
                            </div>
                            <div className="col-span-2 flex justify-end">
                              <button onClick={() => removePart(part.id)} className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-foreground transition-all">
                                <Trash size={14} weight="duotone" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                      <button onClick={addPart} className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors">
                        <Plus size={13} weight="duotone" /> Ajouter une pièce
                      </button>
                      <Separator className="mt-4 mb-2" />
                      <div className="flex justify-end">
                        <span className="text-sm text-muted-foreground mr-4">Sous-total pièces</span>
                        <span className="text-sm font-semibold text-foreground">{fmt(partsSubtotal)}</span>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              {/* 3. Labor */}
              <Card className="rounded-xl shadow-sm border border-border">
                <CardContent className="p-5">
                  <SectionHeader label="Main-d'œuvre" icon={<Wrench size={16} weight="duotone" />} sectionKey="labor" subtotalAmt={laborSubtotal} />
                  {openSections.labor && (
                    <>
                      <Separator className="mb-4" />
                      <div className="hidden sm:grid grid-cols-12 gap-2 mb-2 px-1">
                        <span className="col-span-6 text-xs text-muted-foreground uppercase tracking-wide">Description</span>
                        <span className="col-span-2 text-xs text-muted-foreground uppercase tracking-wide text-center">Heures</span>
                        <span className="col-span-2 text-xs text-muted-foreground uppercase tracking-wide text-right">Taux/h</span>
                        <span className="col-span-2 text-xs text-muted-foreground uppercase tracking-wide text-right">Total</span>
                      </div>
                      <div className="space-y-2">
                        {labor.map((entry) => (
                          <div key={entry.id} className="grid grid-cols-12 gap-2 items-center p-2 rounded-lg hover:bg-muted/30 group">
                            <div className="col-span-12 sm:col-span-6">
                              <Input value={entry.description} onChange={(e) => updateLabor(entry.id, "description", e.target.value)} placeholder="Description" className="rounded-md border-border text-sm h-8" />
                            </div>
                            <div className="col-span-4 sm:col-span-2">
                              <Input type="number" value={entry.hours} onChange={(e) => updateLabor(entry.id, "hours", parseFloat(e.target.value) || 0)} className="rounded-md border-border text-sm h-8 text-center" />
                            </div>
                            <div className="col-span-4 sm:col-span-2">
                              <Input type="number" value={entry.rate} onChange={(e) => updateLabor(entry.id, "rate", parseFloat(e.target.value) || 0)} className="rounded-md border-border text-sm h-8 text-right" />
                            </div>
                            <div className="col-span-3 sm:col-span-2 text-right">
                              <span className="text-sm font-medium text-foreground">{fmt(entry.hours * entry.rate)}</span>
                            </div>
                            <div className="col-span-1 flex justify-end">
                              <button onClick={() => removeLabor(entry.id)} className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-foreground transition-all">
                                <Trash size={14} weight="duotone" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                      <button onClick={addLabor} className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors">
                        <Plus size={13} weight="duotone" /> Ajouter une entrée
                      </button>
                      <Separator className="mt-4 mb-2" />
                      <div className="flex justify-end">
                        <span className="text-sm text-muted-foreground mr-4">Sous-total main-d&#39;œuvre</span>
                        <span className="text-sm font-semibold text-foreground">{fmt(laborSubtotal)}</span>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              {/* 4. Supplies */}
              <Card className="rounded-xl shadow-sm border border-border">
                <CardContent className="p-5">
                  <SectionHeader label="Fournitures d'atelier" icon={<Drop size={16} weight="duotone" />} sectionKey="supplies" subtotalAmt={suppliesSubtotal} />
                  {openSections.supplies && (
                    <>
                      <Separator className="mb-4" />
                      <div className="space-y-2">
                        {supplies.map((supply) => (
                          <div key={supply.id} className="grid grid-cols-12 gap-2 items-center p-2 rounded-lg hover:bg-muted/30 group">
                            <div className="col-span-9 sm:col-span-10">
                              <Input value={supply.description} onChange={(e) => updateSupply(supply.id, "description", e.target.value)} placeholder="Description" className="rounded-md border-border text-sm h-8" />
                            </div>
                            <div className="col-span-2">
                              <Input type="number" value={supply.amount} onChange={(e) => updateSupply(supply.id, "amount", parseFloat(e.target.value) || 0)} className="rounded-md border-border text-sm h-8 text-right" />
                            </div>
                            <div className="col-span-1 flex justify-end">
                              <button onClick={() => removeSupply(supply.id)} className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-foreground transition-all">
                                <Trash size={14} weight="duotone" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                      <button onClick={addSupply} className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors">
                        <Plus size={13} weight="duotone" /> Ajouter une fourniture
                      </button>
                    </>
                  )}
                </CardContent>
              </Card>

              {/* 5. Taxes */}
              <Card className="rounded-xl shadow-sm border border-border">
                <CardContent className="p-5">
                  <SectionHeader label="Taxes (Québec)" icon={<Calculator size={16} weight="duotone" />} sectionKey="taxes" />
                  {openSections.taxes && (
                    <>
                      <Separator className="mb-4" />
                      <div className="space-y-1">
                        <div className="flex items-center justify-between py-2.5 px-3 rounded-lg hover:bg-muted/30">
                          <span className="text-sm text-foreground font-medium">Sous-total avant taxes</span>
                          <span className="text-sm font-semibold text-foreground">{fmt(subtotal)}</span>
                        </div>
                        <Separator />
                        <div className="flex items-center justify-between py-2.5 px-3 rounded-lg hover:bg-muted/30">
                          <div>
                            <p className="text-sm text-foreground">TPS — Taxe sur les produits et services</p>
                            <p className="text-xs text-muted-foreground">Taux : 5,00 %</p>
                          </div>
                          <span className="text-sm font-semibold text-foreground">{fmt(gst)}</span>
                        </div>
                        <Separator />
                        <div className="flex items-center justify-between py-2.5 px-3 rounded-lg hover:bg-muted/30">
                          <div>
                            <p className="text-sm text-foreground">TVQ — Taxe de vente du Québec</p>
                            <p className="text-xs text-muted-foreground">Taux : 9,975 %</p>
                          </div>
                          <span className="text-sm font-semibold text-foreground">{fmt(qst)}</span>
                        </div>
                        <Separator />
                        <div className="flex items-center justify-between py-3 px-3 rounded-lg bg-muted/40">
                          <span className="text-base font-bold text-foreground font-heading">Total TTC</span>
                          <span className="text-base font-bold text-foreground">{fmt(total)}</span>
                        </div>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              {/* 6. Payment */}
              <Card className="rounded-xl shadow-sm border border-border">
                <CardContent className="p-5">
                  <SectionHeader label="Paiement &amp; Enregistrement" icon={<CreditCard size={16} weight="duotone" />} sectionKey="payment" />
                  {openSections.payment && (
                    <>
                      <Separator className="mb-4" />
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                        <div className="space-y-1.5">
                          <Label className="text-xs text-muted-foreground uppercase tracking-wide">Statut de paiement</Label>
                          <div className="flex flex-wrap gap-2">
                            {paymentStatusOptions.map((s) => (
                              <button key={s} onClick={() => setPaymentStatus(s)}
                                className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${paymentStatus === s ? "bg-primary text-primary-foreground border-primary" : "bg-background text-muted-foreground border-border hover:bg-muted"}`}>
                                {s}
                              </button>
                            ))}
                          </div>
                        </div>
                        <div className="space-y-1.5">
                          <Label className="text-xs text-muted-foreground uppercase tracking-wide">Mode de paiement</Label>
                          <div className="flex flex-wrap gap-2">
                            {paymentMethodOptions.map((m) => (
                              <button key={m} onClick={() => setPaymentMethod(m)}
                                className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${paymentMethod === m ? "bg-primary text-primary-foreground border-primary" : "bg-background text-muted-foreground border-border hover:bg-muted"}`}>
                                {m}
                              </button>
                            ))}
                          </div>
                        </div>
                        <div className="space-y-1.5">
                          <Label className="text-xs text-muted-foreground uppercase tracking-wide">Montant reçu ($)</Label>
                          <Input type="number" value={amountPaid} onChange={(e) => setAmountPaid(e.target.value)} className="rounded-lg border-border text-sm" />
                        </div>
                      </div>
                      <Separator className="mb-4" />
                      {saveMsg && (
                        <p className={`text-xs mb-3 ${saveMsg.startsWith("✓") ? "text-green-600" : "text-red-500"}`}>
                          {saveMsg}
                        </p>
                      )}
                      <div className="flex flex-col sm:flex-row gap-3">
                        <Button
                          onClick={handleSave}
                          disabled={savingOrder}
                          className="flex-1 bg-primary text-primary-foreground rounded-lg text-sm font-medium shadow-sm"
                        >
                          <FloppyDisk size={15} weight="duotone" className="mr-2" />
                          {savingOrder ? "Enregistrement…" : editingOrderId ? "Mettre à jour la facture" : "Enregistrer la facture"}
                        </Button>
                        <Button
                          variant="outline"
                          className="flex-1 rounded-lg text-sm font-medium border-border hover:bg-muted"
                          onClick={() => {
                            if (customerName.trim()) {
                              setSendingInvoice({
                                orderNumber: editingOrderNumber ?? nextOrderNumber(),
                                customerName: customerName.trim(),
                                vehicleInfo: vehicleInfo.trim() || "—",
                                total,
                                email: selectedCustomer?.email ?? undefined,
                                phone: (selectedCustomer?.phone ?? phone) || undefined,
                              });
                            }
                          }}
                          disabled={!customerName.trim()}
                        >
                          <PaperPlaneTilt size={15} weight="duotone" className="mr-2" />
                          Envoyer au client
                        </Button>
                        <Button
                          variant="outline"
                          className="flex-1 rounded-lg text-sm font-medium border-border hover:bg-muted"
                          onClick={() => {
                            setPrintingInvoice(buildPrintData(
                              editingOrderNumber ?? nextOrderNumber(),
                              new Date().toLocaleDateString("fr-CA"),
                              customerName.trim() || "—",
                              phone,
                              vehicleInfo.trim() || "—",
                              plate,
                              mileage,
                              mechanic,
                              jobDesc,
                              parts,
                              labor,
                              supplies,
                              subtotal,
                              gst,
                              qst,
                              total,
                              paymentStatus,
                              paymentMethod,
                              parseFloat(amountPaid) || 0,
                            ));
                          }}
                        >
                          <Printer size={15} weight="duotone" className="mr-2" />
                          Imprimer / PDF
                        </Button>
                        <Button
                          variant="outline"
                          className="flex-1 rounded-lg text-sm font-medium border-border hover:bg-muted"
                          onClick={() => setActiveTab("list")}
                        >
                          <Eye size={15} weight="duotone" className="mr-2" />
                          Voir les factures
                        </Button>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Sticky summary */}
            <div className="lg:col-span-1">
              <div className="sticky top-6 space-y-4">
                <Card className="rounded-xl shadow-md border border-border">
                  <CardHeader className="pb-2 pt-5 px-5">
                    <CardTitle className="font-heading text-sm font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-2">
                      <Receipt size={15} weight="duotone" className="text-primary" />
                      Sommaire de la facture
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="px-5 pb-5 space-y-1">
                    <div className="flex justify-between py-1.5 text-xs text-muted-foreground">
                      <span>Client</span>
                      <span className="font-medium text-foreground truncate max-w-[140px] text-right">{customerName || "—"}</span>
                    </div>
                    <div className="flex justify-between py-1.5 text-xs text-muted-foreground">
                      <span>Véhicule</span>
                      <span className="font-medium text-foreground truncate max-w-[140px] text-right">{vehicleInfo || "—"}</span>
                    </div>
                    <Separator className="my-3" />
                    <div className="flex justify-between py-1.5">
                      <span className="text-xs text-muted-foreground">Pièces</span>
                      <span className="text-xs font-medium text-foreground">{fmt(partsSubtotal)}</span>
                    </div>
                    <div className="flex justify-between py-1.5">
                      <span className="text-xs text-muted-foreground">Main-d&#39;œuvre</span>
                      <span className="text-xs font-medium text-foreground">{fmt(laborSubtotal)}</span>
                    </div>
                    <div className="flex justify-between py-1.5">
                      <span className="text-xs text-muted-foreground">Fournitures</span>
                      <span className="text-xs font-medium text-foreground">{fmt(suppliesSubtotal)}</span>
                    </div>
                    <Separator className="my-3" />
                    <div className="flex justify-between py-1.5">
                      <span className="text-xs text-muted-foreground">Sous-total</span>
                      <span className="text-xs font-medium text-foreground">{fmt(subtotal)}</span>
                    </div>
                    <div className="flex justify-between py-1.5">
                      <Badge className="text-xs px-1.5 py-0 rounded bg-muted text-muted-foreground font-normal">TPS 5%</Badge>
                      <span className="text-xs font-medium text-foreground">{fmt(gst)}</span>
                    </div>
                    <div className="flex justify-between py-1.5">
                      <Badge className="text-xs px-1.5 py-0 rounded bg-muted text-muted-foreground font-normal">TVQ 9.975%</Badge>
                      <span className="text-xs font-medium text-foreground">{fmt(qst)}</span>
                    </div>
                    <Separator className="my-3" />
                    <div className="flex justify-between py-2 px-1 rounded-lg bg-muted/40">
                      <span className="text-sm font-bold text-foreground font-heading">Total TTC</span>
                      <span className="text-sm font-bold text-foreground">{fmt(total)}</span>
                    </div>
                    <Separator className="my-3" />
                    <div className="flex justify-between py-1.5 px-1">
                      <span className="text-xs text-muted-foreground">Montant reçu</span>
                      <span className="text-xs font-medium text-foreground">{fmt(paid)}</span>
                    </div>
                    <div className="flex justify-between py-2 px-1 rounded-lg bg-muted/40">
                      <span className="text-sm font-bold text-foreground font-heading">Solde dû</span>
                      <span className="text-sm font-bold text-foreground">{fmt(Math.max(0, balanceDue))}</span>
                    </div>
                    <div className="pt-3 flex items-center justify-between">
                      <span className="text-xs text-muted-foreground">Statut</span>
                      <Badge className={`text-xs px-3 py-1 rounded-full font-medium ${statusColor[paymentStatus]}`}>
                        {paymentStatus === "Non payée" && <Warning size={11} weight="duotone" className="mr-1 inline" />}
                        {paymentStatus === "Partielle" && <Clock size={11} weight="duotone" className="mr-1 inline" />}
                        {paymentStatus === "Payée" && <CheckCircle size={11} weight="duotone" className="mr-1 inline" />}
                        {paymentStatus}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>

                <Card className="rounded-xl shadow-sm border border-border">
                  <CardContent className="p-4">
                    <p className="text-xs text-muted-foreground uppercase tracking-wide font-semibold mb-2">
                      Note interne
                    </p>
                    <textarea
                      className="w-full text-xs text-foreground bg-background border border-border rounded-lg p-2 resize-none focus:outline-none focus:ring-1 focus:ring-ring"
                      rows={3}
                      placeholder="Ajouter une note pour ce bon de travail…"
                    />
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      )}
      {/* Send Invoice Modal */}
      {sendingInvoice && (
        <SendInvoiceModal
          invoice={sendingInvoice}
          onClose={() => setSendingInvoice(null)}
        />
      )}
      {/* Print / PDF Modal */}
      {printingInvoice && (
        <PrintInvoiceModal
          data={printingInvoice}
          onClose={() => setPrintingInvoice(null)}
        />
      )}
    </section>
  );
}
