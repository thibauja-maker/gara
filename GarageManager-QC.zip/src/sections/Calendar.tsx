import { useState } from "react";
import { useApiAppointments, useApiCustomers, type ApiAppointment, type ApiCustomer } from "@/hooks/use-api-data";
import { Button } from "@/components/ui/button";
import {
  CaretLeft,
  CaretRight,
  Plus,
  CalendarBlank,
  Wrench,
  User,
  Clock,
  PencilSimple,
  Trash,
  X,
  FloppyDisk,
} from "@phosphor-icons/react";

type ViewMode = "day" | "week" | "month";

const DAYS_FR = ["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"];
const MONTHS_FR = [
  "Janvier", "Février", "Mars", "Avril", "Mai", "Juin",
  "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre",
];

const HOURS = Array.from({ length: 11 }, (_, i) => i + 7);

type CalEvent = {
  id: string;
  title: string;
  customer: string;
  phone: string;
  vehicle: string;
  bay: string;
  date: string;
  startHour: number;
  durationH: number;
  color?: string;
  status: string;
};

const TODAY = new Date(2026, 3, 17);

function isSameDay(a: Date, b: Date) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

function toDateStr(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function startOfWeek(d: Date) {
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  return new Date(d.getFullYear(), d.getMonth(), diff);
}

function hourLabel(h: number) {
  const hh = Math.floor(h);
  const mm = h % 1 === 0.5 ? "30" : "00";
  return `${String(hh).padStart(2, "0")}:${mm}`;
}

type StatusKey = "scheduled" | "in-progress" | "completed";

const statusColors: Record<StatusKey, { bg: string; border: string; text: string; dot: string }> = {
  scheduled:    { bg: "bg-sky-50 dark:bg-sky-950/40",       border: "border-sky-300 dark:border-sky-700",    text: "text-sky-800 dark:text-sky-200",    dot: "bg-sky-500" },
  "in-progress":{ bg: "bg-blue-50 dark:bg-blue-950/40",     border: "border-blue-400 dark:border-blue-500",  text: "text-blue-800 dark:text-blue-200",  dot: "bg-blue-500" },
  completed:    { bg: "bg-emerald-50 dark:bg-emerald-950/30", border: "border-emerald-300 dark:border-emerald-700", text: "text-emerald-800 dark:text-emerald-200", dot: "bg-emerald-500" },
};

function cfgForStatus(s: string) {
  return statusColors[(s as StatusKey)] ?? statusColors["scheduled"];
}

const HOUR_HEIGHT = 64;
const DAY_START = 7;

function EventBlock({ evt, compact = false, onClick }: { evt: CalEvent; compact?: boolean; onClick: () => void }) {
  const cfg = cfgForStatus(evt.status);
  const top = (evt.startHour - DAY_START) * HOUR_HEIGHT;
  const height = Math.max(evt.durationH * HOUR_HEIGHT - 4, 22);
  return (
    <div
      className={`absolute left-1 right-1 rounded-lg border-l-4 px-2 py-1 overflow-hidden cursor-pointer hover:shadow-md hover:-translate-y-px transition-all duration-150 select-none ${cfg.bg} ${cfg.border}`}
      style={{ top, height }}
      onClick={(e) => { e.stopPropagation(); onClick(); }}
      title={`${evt.title} · ${evt.customer}`}
    >
      <p className={`text-[11px] font-bold leading-tight truncate ${cfg.text}`}>{evt.title}</p>
      {!compact && height > 36 && (
        <>
          <p className={`text-[10px] truncate ${cfg.text} opacity-80`}>{evt.customer}</p>
          <div className="flex items-center gap-1 mt-0.5">
            <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot} shrink-0`} />
            <span className={`text-[9px] ${cfg.text} opacity-70`}>{evt.bay}</span>
          </div>
        </>
      )}
    </div>
  );
}

const DURATION_OPTIONS = [
  { label: "30 min",          value: "0.5" },
  { label: "1h00",            value: "1" },
  { label: "1h30",            value: "1.5" },
  { label: "2h00",            value: "2" },
  { label: "2h30",            value: "2.5" },
  { label: "3h00",            value: "3" },
  { label: "3h30",            value: "3.5" },
  { label: "4h00",            value: "4" },
  { label: "5h00",            value: "5" },
  { label: "6h00",            value: "6" },
  { label: "Journée complète", value: "8" },
];

const EMPTY_FORM = {
  title: "",
  customerName: "",
  customerPhone: "",
  customerVehicle: "",
  bay: "Lift 1",
  date: toDateStr(TODAY),
  startHour: "8",
  durationH: "1",
  status: "scheduled",
  color: "blue",
};

type FormState = typeof EMPTY_FORM;

function AppointmentModal({
  mode,
  initial,
  onSave,
  onClose,
  isPending,
  orgId,
}: {
  mode: "create" | "edit";
  initial: FormState;
  onSave: (f: FormState) => void;
  onClose: () => void;
  isPending: boolean;
  orgId: string;
}) {
  const [form, setForm] = useState<FormState>(initial);
  const [customerSearch, setCustomerSearch] = useState("");
  const [showCustomerDropdown, setShowCustomerDropdown] = useState(false);

  const { data: allCustomers } = useApiCustomers(orgId);

  const filteredCustomers = (allCustomers ?? []).filter((c) =>
    c.name.toLowerCase().includes(customerSearch.toLowerCase())
  );

  function selectCustomer(c: ApiCustomer) {
    // Parse vehicles JSON to get first vehicle label
    let vehicleLabel = c.vehicleInfo ?? "";
    try {
      const vehicles = c.vehicles;
      const parsed = JSON.parse(typeof vehicles === "string" ? vehicles : "[]");
      if (Array.isArray(parsed) && parsed.length > 0) {
        const first = parsed[0];
        if (typeof first === "object" && first !== null) {
          vehicleLabel = [first.annee, first.marque, first.modele].filter(Boolean).join(" ");
        } else {
          vehicleLabel = String(first);
        }
      }
    } catch {}
    setForm((p) => ({
      ...p,
      customerName: c.name,
      customerPhone: c.phone ?? "",
      customerVehicle: vehicleLabel,
    }));
    setCustomerSearch(c.name);
    setShowCustomerDropdown(false);
  }

  function textField(key: keyof FormState, label: string, type = "text") {
    return (
      <div key={key}>
        <label className="block text-[11px] font-semibold text-muted-foreground mb-1 uppercase tracking-wide">{label}</label>
        <input
          type={type}
          className="w-full rounded-lg border border-border bg-background text-foreground text-[13px] px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/40"
          value={form[key]}
          onChange={(e) => setForm((p) => ({ ...p, [key]: e.target.value }))}
        />
      </div>
    );
  }

  function selectField(key: keyof FormState, label: string, options: { label: string; value: string }[]) {
    return (
      <div key={key}>
        <label className="block text-[11px] font-semibold text-muted-foreground mb-1 uppercase tracking-wide">{label}</label>
        <select
          className="w-full rounded-lg border border-border bg-background text-foreground text-[13px] px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/40"
          value={form[key]}
          onChange={(e) => setForm((p) => ({ ...p, [key]: e.target.value }))}
        >
          {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-card rounded-2xl shadow-2xl border border-border w-full max-w-md mx-4 overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between px-5 py-4 border-b border-border">
          <div className="flex items-center gap-2">
            <CalendarBlank size={16} weight="duotone" className="text-primary" />
            <h2 className="text-[14px] font-bold text-foreground">
              {mode === "create" ? "Nouveau rendez-vous" : "Modifier le rendez-vous"}
            </h2>
          </div>
          <button onClick={onClose} className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground">
            <X size={14} />
          </button>
        </div>
        <div className="p-5 space-y-3 overflow-y-auto max-h-[70vh]">
          {/* Titre */}
          {textField("title", "Titre / Service")}

          {/* Client avec sélecteur */}
          <div className="relative">
            <label className="block text-[11px] font-semibold text-muted-foreground mb-1 uppercase tracking-wide">Client</label>
            <input
              type="text"
              placeholder="Rechercher ou saisir un client…"
              className="w-full rounded-lg border border-border bg-background text-foreground text-[13px] px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/40"
              value={customerSearch || form.customerName}
              onChange={(e) => {
                setCustomerSearch(e.target.value);
                setForm((p) => ({ ...p, customerName: e.target.value }));
                setShowCustomerDropdown(true);
              }}
              onFocus={() => setShowCustomerDropdown(true)}
              onBlur={() => setTimeout(() => setShowCustomerDropdown(false), 150)}
            />
            {showCustomerDropdown && filteredCustomers.length > 0 && (
              <div className="absolute z-50 top-full left-0 right-0 mt-1 bg-card border border-border rounded-lg shadow-xl max-h-40 overflow-y-auto">
                {filteredCustomers.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    className="w-full text-left px-3 py-2 text-[12px] hover:bg-muted transition-colors flex flex-col"
                    onMouseDown={() => selectCustomer(c)}
                  >
                    <span className="font-semibold text-foreground">{c.name}</span>
                    <span className="text-muted-foreground text-[10px]">{c.vehicleInfo}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Téléphone */}
          {textField("customerPhone", "Téléphone")}

          {/* Véhicule */}
          {textField("customerVehicle", "Véhicule")}

          {/* Lift */}
          {selectField("bay", "Lift", [
            { label: "Lift 1", value: "Lift 1" },
            { label: "Lift 2", value: "Lift 2" },
            { label: "Lift 3", value: "Lift 3" },
          ])}

          {/* Date */}
          {textField("date", "Date", "date")}

          {/* Heure de début */}
          <div>
            <label className="block text-[11px] font-semibold text-muted-foreground mb-1 uppercase tracking-wide">Heure de début (ex: 8.5 = 8h30)</label>
            <input
              type="number"
              min="7"
              max="17"
              step="0.5"
              className="w-full rounded-lg border border-border bg-background text-foreground text-[13px] px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/40"
              value={form.startHour}
              onChange={(e) => setForm((p) => ({ ...p, startHour: e.target.value }))}
            />
          </div>

          {/* Durée approximative */}
          {selectField("durationH", "Durée approximative", DURATION_OPTIONS)}

          {/* Statut */}
          {selectField("status", "Statut", [
            { label: "Planifié", value: "scheduled" },
            { label: "En cours", value: "in-progress" },
            { label: "Terminé",  value: "completed" },
          ])}
        </div>
        <div className="flex justify-end gap-2 px-5 py-4 border-t border-border bg-muted/30">
          <Button variant="outline" size="sm" onClick={onClose} disabled={isPending}>Annuler</Button>
          <Button size="sm" className="gap-1.5" onClick={() => onSave(form)} disabled={isPending}>
            <FloppyDisk size={13} weight="bold" />
            {isPending ? "Enregistrement…" : "Enregistrer"}
          </Button>
        </div>
      </div>
    </div>
  );
}

function DeleteConfirmModal({ title, onConfirm, onClose, isPending }: { title: string; onConfirm: () => void; onClose: () => void; isPending: boolean }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-card rounded-2xl shadow-2xl border border-border w-full max-w-sm mx-4 p-6" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start gap-3 mb-4">
          <div className="w-9 h-9 rounded-full bg-red-100 dark:bg-red-950/40 flex items-center justify-center shrink-0">
            <Trash size={16} className="text-red-600" />
          </div>
          <div>
            <h3 className="text-[14px] font-bold text-foreground">Supprimer ce rendez-vous ?</h3>
            <p className="text-[12px] text-muted-foreground mt-1 line-clamp-2">{title}</p>
          </div>
        </div>
        <div className="flex justify-end gap-2">
          <Button variant="outline" size="sm" onClick={onClose} disabled={isPending}>Annuler</Button>
          <Button size="sm" className="bg-red-600 hover:bg-red-700 text-white gap-1.5" onClick={onConfirm} disabled={isPending}>
            <Trash size={13} weight="bold" />
            {isPending ? "Suppression…" : "Supprimer"}
          </Button>
        </div>
      </div>
    </div>
  );
}

function dbToCalEvent(a: ApiAppointment): CalEvent {
  // Parse time "HH:MM" → decimal hour
  let startHour = 8;
  if (a.time) {
    const [hh, mm] = a.time.split(":").map(Number);
    startHour = hh + (mm ?? 0) / 60;
  }
  const durationH = a.duration ? a.duration / 60 : 1;
  return {
    id: a.id,
    title: a.service ?? "Rendez-vous",
    customer: a.customerName,
    phone: a.phone ?? "",
    vehicle: a.vehicleInfo ?? "",
    bay: a.mechanic ?? "—",
    date: a.date,
    startHour,
    durationH,
    color: "blue",
    status: a.status ?? "scheduled",
  };
}

function formToDbDraft(f: FormState) {
  // Convert decimal hour back to "HH:MM"
  const h = parseFloat(f.startHour) || 8;
  const hh = Math.floor(h);
  const mm = h % 1 === 0.5 ? "30" : "00";
  const timeStr = `${String(hh).padStart(2, "0")}:${mm}`;
  const durationMin = Math.round((parseFloat(f.durationH) || 1) * 60);
  return {
    service: f.title.trim() || "Rendez-vous",
    customerName: f.customerName.trim() || "Client inconnu",
    phone: f.customerPhone.trim() || null,
    vehicleInfo: f.customerVehicle.trim() || null,
    mechanic: f.bay.trim() || null,
    date: f.date,
    time: timeStr,
    duration: durationMin,
    status: f.status,
  };
}

export default function CalendarSection({ orgId }: { orgId: string }) {
  const [viewMode, setViewMode] = useState<ViewMode>("week");
  const [currentDate, setCurrentDate] = useState(new Date(TODAY));
  const [selectedEvent, setSelectedEvent] = useState<CalEvent | null>(null);
  const [createModal, setCreateModal] = useState(false);
  const [editModal, setEditModal] = useState(false);
  const [deleteModal, setDeleteModal] = useState(false);

  // ── Drag & drop state ────────────────────────────────────────────────────
  const [_dragEvt, _setDragEvt] = useState<CalEvent | null>(null);
  const [_dragOffset, _setDragOffset] = useState(0); // offset in hours within the event where user grabbed
  const [_dropTarget, _setDropTarget] = useState<{ date: string; hour: number } | null>(null);

  const { data: appts, isPending: loadingAppts, refetch, create, update, remove } = useApiAppointments(orgId);
  const mutating = false; // optimistic — modals close after await

  const events: CalEvent[] = (appts ?? []).map(dbToCalEvent);

  function navigate(dir: 1 | -1) {
    const d = new Date(currentDate);
    if (viewMode === "day")   d.setDate(d.getDate() + dir);
    if (viewMode === "week")  d.setDate(d.getDate() + dir * 7);
    if (viewMode === "month") d.setMonth(d.getMonth() + dir);
    setCurrentDate(d);
  }
  function goToday() { setCurrentDate(new Date(TODAY)); }

  const weekStart = startOfWeek(currentDate);
  const weekDates = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(weekStart);
    d.setDate(weekStart.getDate() + i);
    return d;
  });

  const monthStart = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
  const monthStartDay = monthStart.getDay() === 0 ? 6 : monthStart.getDay() - 1;
  const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
  const monthCells = Array.from({ length: monthStartDay + daysInMonth }, (_, i) => {
    if (i < monthStartDay) return null;
    return new Date(currentDate.getFullYear(), currentDate.getMonth(), i - monthStartDay + 1);
  });
  while (monthCells.length % 7 !== 0) monthCells.push(null);

  const headerTitle = viewMode === "month"
    ? `${MONTHS_FR[currentDate.getMonth()]} ${currentDate.getFullYear()}`
    : viewMode === "week"
      ? `${MONTHS_FR[weekDates[0].getMonth()]} ${weekDates[0].getDate()} – ${MONTHS_FR[weekDates[6].getMonth()]} ${weekDates[6].getDate()}, ${weekDates[6].getFullYear()}`
      : `${DAYS_FR[currentDate.getDay()]} ${currentDate.getDate()} ${MONTHS_FR[currentDate.getMonth()]} ${currentDate.getFullYear()}`;

  function eventsForDate(d: Date) {
    const ds = toDateStr(d);
    return events.filter((e) => e.date === ds);
  }

  async function handleCreate(f: FormState) {
    try {
      await create({ ...formToDbDraft(f), orgId });
      await refetch();
      setCreateModal(false);
    } catch (err) { console.error(err); }
  }

  async function handleEdit(f: FormState) {
    if (!selectedEvent) return;
    try {
      await update(selectedEvent.id, formToDbDraft(f));
      await refetch();
      setEditModal(false);
      setSelectedEvent(null);
    } catch (err) { console.error(err); }
  }

  async function handleDelete() {
    if (!selectedEvent) return;
    try {
      await remove(selectedEvent.id);
      await refetch();
      setDeleteModal(false);
      setSelectedEvent(null);
    } catch (err) { console.error(err); }
  }

  function editInitial(): FormState {
    if (!selectedEvent) return EMPTY_FORM;
    return {
      title: selectedEvent.title,
      customerName: selectedEvent.customer,
      customerPhone: selectedEvent.phone ?? "",
      customerVehicle: selectedEvent.vehicle ?? "",
      bay: selectedEvent.bay,
      date: selectedEvent.date,
      startHour: String(selectedEvent.startHour),
      durationH: String(selectedEvent.durationH),
      status: selectedEvent.status,
      color: "blue",
    };
  }

  return (
    <div className="flex flex-col h-full bg-background">
      <div className="bg-card border-b border-border px-6 py-4 flex items-center justify-between gap-4 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
            <CalendarBlank size={16} weight="duotone" className="text-primary" />
          </div>
          <div>
            <h1 className="text-[15px] font-bold text-foreground">{headerTitle}</h1>
            <p className="text-[11px] text-muted-foreground">2 lifts · 2 mécaniciens</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-muted rounded-lg p-0.5 gap-0.5">
            {(["day", "week", "month"] as ViewMode[]).map((v) => (
              <button
                key={v}
                onClick={() => setViewMode(v)}
                className={`px-3 py-1.5 text-[12px] font-semibold rounded-md transition-all duration-150 capitalize ${
                  viewMode === v ? "bg-card shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {v === "day" ? "Jour" : v === "week" ? "Semaine" : "Mois"}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-1">
            <button onClick={() => navigate(-1)} className="w-8 h-8 flex items-center justify-center rounded-md border border-border hover:bg-muted transition-colors">
              <CaretLeft size={14} />
            </button>
            <button onClick={goToday} className="px-3 h-8 text-[12px] font-semibold border border-border rounded-md hover:bg-muted transition-colors text-foreground">
              Aujourd&#39;hui
            </button>
            <button onClick={() => navigate(1)} className="w-8 h-8 flex items-center justify-center rounded-md border border-border hover:bg-muted transition-colors">
              <CaretRight size={14} />
            </button>
          </div>
          <Button size="sm" className="h-8 gap-1.5 text-[12px] font-medium" onClick={() => setCreateModal(true)}>
            <Plus size={13} weight="bold" />
            Planifier
          </Button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        <div className="flex-1 overflow-auto">

          {loadingAppts && (
            <div className="flex items-center justify-center h-40 text-muted-foreground text-[13px]">
              Chargement…
            </div>
          )}

          {!loadingAppts && viewMode === "day" && (
            <div className="flex flex-col min-h-full">
              <div className="flex border-b border-border bg-card sticky top-0 z-10">
                <div className="w-16 shrink-0" />
                <div className={`flex-1 flex items-center justify-center py-3 border-l border-border ${isSameDay(currentDate, TODAY) ? "bg-primary/5" : ""}`}>
                  <div className="text-center">
                    <p className="text-[11px] text-muted-foreground uppercase tracking-wide">{DAYS_FR[currentDate.getDay()]}</p>
                    <p className={`text-[18px] font-bold mt-0.5 w-9 h-9 flex items-center justify-center rounded-full mx-auto ${isSameDay(currentDate, TODAY) ? "bg-primary text-white" : "text-foreground"}`}>
                      {currentDate.getDate()}
                    </p>
                  </div>
                </div>
              </div>
              <div className="flex flex-1">
                <div className="w-16 shrink-0 border-r border-border">
                  {HOURS.map((h) => (
                    <div key={h} className="relative flex items-start justify-end pr-2 pt-1" style={{ height: HOUR_HEIGHT }}>
                      <span className="text-[10px] text-muted-foreground leading-none">{`${String(h).padStart(2, "0")}:00`}</span>
                    </div>
                  ))}
                </div>
                <div className="flex-1 border-l border-border relative">
                  {HOURS.map((h) => (
                    <div key={h} className="border-b border-border/50" style={{ height: HOUR_HEIGHT }} />
                  ))}
                  <div className="absolute inset-x-0" style={{ top: 0, bottom: 0 }}>
                    {eventsForDate(currentDate).map((evt) => (
                      <EventBlock key={evt.id} evt={evt} onClick={() => setSelectedEvent(evt)} />
                    ))}
                  </div>
                  {isSameDay(currentDate, TODAY) && (
                    <div className="absolute left-0 right-0 z-10 pointer-events-none" style={{ top: (10 - DAY_START) * HOUR_HEIGHT }}>
                      <div className="h-0.5 bg-red-500 relative">
                        <div className="w-3 h-3 bg-red-500 rounded-full -ml-1.5 -mt-1.5 absolute left-0" />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {!loadingAppts && viewMode === "week" && (
            <div className="flex flex-col min-h-full">
              <div className="flex border-b border-border bg-card sticky top-0 z-10">
                <div className="w-16 shrink-0" />
                {weekDates.map((d) => {
                  const isToday = isSameDay(d, TODAY);
                  return (
                    <div key={d.toISOString()} className={`flex-1 flex flex-col items-center justify-center py-2.5 border-l border-border ${isToday ? "bg-primary/5" : ""}`}>
                      <p className="text-[10px] text-muted-foreground uppercase tracking-wide">{DAYS_FR[d.getDay()]}</p>
                      <div className={`text-[16px] font-bold mt-1 w-8 h-8 flex items-center justify-center rounded-full ${isToday ? "bg-primary text-white" : "text-foreground"}`}>
                        {d.getDate()}
                      </div>
                      {eventsForDate(d).length > 0 && (
                        <div className="flex gap-0.5 mt-1">
                          {eventsForDate(d).slice(0, 3).map((e) => (
                            <span key={e.id} className={`w-1.5 h-1.5 rounded-full ${cfgForStatus(e.status).dot}`} />
                          ))}
                          {eventsForDate(d).length > 3 && <span className="text-[8px] text-muted-foreground">+{eventsForDate(d).length - 3}</span>}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
              <div className="flex flex-1">
                <div className="w-16 shrink-0 border-r border-border">
                  {HOURS.map((h) => (
                    <div key={h} className="relative flex items-start justify-end pr-2 pt-1" style={{ height: HOUR_HEIGHT }}>
                      <span className="text-[10px] text-muted-foreground leading-none">{`${String(h).padStart(2, "0")}:00`}</span>
                    </div>
                  ))}
                </div>
                {weekDates.map((d) => {
                  const isToday = isSameDay(d, TODAY);
                  return (
                    <div key={d.toISOString()} className={`flex-1 border-l border-border relative ${isToday ? "bg-primary/2" : ""}`}>
                      {HOURS.map((h) => (
                        <div key={h} className="border-b border-border/40" style={{ height: HOUR_HEIGHT }} />
                      ))}
                      <div className="absolute inset-0">
                        {eventsForDate(d).map((evt) => (
                          <EventBlock key={evt.id} evt={evt} compact onClick={() => setSelectedEvent(evt)} />
                        ))}
                      </div>
                      {isToday && (
                        <div className="absolute left-0 right-0 z-10 pointer-events-none" style={{ top: (10 - DAY_START) * HOUR_HEIGHT }}>
                          <div className="h-0.5 bg-red-500 relative">
                            <div className="w-2.5 h-2.5 bg-red-500 rounded-full -ml-1 -mt-1 absolute left-0" />
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {!loadingAppts && viewMode === "month" && (
            <div className="p-4">
              <div className="grid grid-cols-7 mb-1">
                {["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"].map((d) => (
                  <div key={d} className="text-center py-2 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">{d}</div>
                ))}
              </div>
              <div className="grid grid-cols-7 gap-1">
                {monthCells.map((d, idx) => {
                  const isToday = d ? isSameDay(d, TODAY) : false;
                  const isCurrentMonth = d ? d.getMonth() === currentDate.getMonth() : false;
                  const dayEvents = d ? eventsForDate(d) : [];
                  return (
                    <div
                      key={idx}
                      className={`min-h-[100px] rounded-xl border p-2 cursor-pointer hover:border-primary/40 transition-colors ${
                        !d || !isCurrentMonth
                          ? "bg-muted/20 border-border/30"
                          : isToday
                            ? "bg-primary/5 border-primary/40"
                            : "bg-card border-border hover:bg-muted/20"
                      }`}
                      onClick={() => { if (d) { setCurrentDate(d); setViewMode("day"); } }}
                    >
                      {d && (
                        <>
                          <div className={`w-7 h-7 flex items-center justify-center rounded-full text-[12px] font-bold mb-1.5 ${
                            isToday ? "bg-primary text-white" : isCurrentMonth ? "text-foreground" : "text-muted-foreground/40"
                          }`}>{d.getDate()}</div>
                          <div className="space-y-0.5">
                            {dayEvents.slice(0, 3).map((evt) => {
                              const cfg = cfgForStatus(evt.status);
                              return (
                                <div
                                  key={evt.id}
                                  className={`text-[10px] px-1.5 py-0.5 rounded font-medium truncate border-l-2 ${cfg.bg} ${cfg.border} ${cfg.text}`}
                                  onClick={(e) => { e.stopPropagation(); setSelectedEvent(evt); }}
                                >
                                  {evt.title.split(" — ")[0]}
                                </div>
                              );
                            })}
                            {dayEvents.length > 3 && (
                              <p className="text-[10px] text-muted-foreground pl-1">+{dayEvents.length - 3} autres</p>
                            )}
                          </div>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        <div className="w-64 shrink-0 border-l border-border bg-card overflow-y-auto">
          <div className="px-4 py-4 border-b border-border">
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold mb-3">Légende</p>
            <div className="space-y-2">
              {(["scheduled", "in-progress", "completed"] as StatusKey[]).map((s) => {
                const cfg = statusColors[s];
                const labels: Record<string, string> = { scheduled: "Planifié", "in-progress": "En cours", completed: "Terminé" };
                return (
                  <div key={s} className="flex items-center gap-2">
                    <span className={`w-3 h-3 rounded ${cfg.dot}`} />
                    <span className={`text-[11px] font-medium ${cfg.text}`}>{labels[s]}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {selectedEvent ? (
            <div className="px-4 py-4">
              <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold mb-3">Détails</p>
              <div className={`rounded-xl border-l-4 p-3 ${cfgForStatus(selectedEvent.status).bg} ${cfgForStatus(selectedEvent.status).border}`}>
                <p className={`text-[13px] font-bold leading-tight mb-1 ${cfgForStatus(selectedEvent.status).text}`}>{selectedEvent.title}</p>
                <div className="space-y-1.5 mt-2">
                  {[
                    { icon: User,   val: selectedEvent.customer },
                    { icon: Wrench, val: `${selectedEvent.vehicle ? selectedEvent.vehicle + " · " : ""}${selectedEvent.bay}` },
                    { icon: Clock,  val: `${hourLabel(selectedEvent.startHour)} · ${DURATION_OPTIONS.find(d => d.value === String(selectedEvent.durationH))?.label ?? selectedEvent.durationH + "h"}` },
                  ].map(({ icon: Icon, val }, i) => (
                    <div key={i} className="flex items-center gap-1.5">
                      <Icon size={11} weight="duotone" className={`${cfgForStatus(selectedEvent.status).text} opacity-70`} />
                      <span className={`text-[11px] ${cfgForStatus(selectedEvent.status).text}`}>{val}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-2 mt-3">
                <button
                  onClick={() => setEditModal(true)}
                  className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-primary/10 hover:bg-primary/20 text-primary text-[12px] font-semibold transition-colors"
                >
                  <PencilSimple size={13} weight="bold" />
                  Modifier
                </button>
                <button
                  onClick={() => setDeleteModal(true)}
                  className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-600 dark:text-red-400 text-[12px] font-semibold transition-colors"
                >
                  <Trash size={13} weight="bold" />
                  Supprimer
                </button>
              </div>

              <button
                onClick={() => setSelectedEvent(null)}
                className="mt-2 text-[11px] text-muted-foreground hover:text-foreground transition-colors"
              >
                Fermer ×
              </button>
            </div>
          ) : (
            <div className="px-4 py-6 text-center">
              <CalendarBlank size={24} weight="duotone" className="text-muted-foreground mx-auto mb-2" />
              <p className="text-[11px] text-muted-foreground">Cliquer sur<br/>un événement</p>
            </div>
          )}
        </div>
      </div>

      {createModal && (
        <AppointmentModal
          mode="create"
          initial={{ ...EMPTY_FORM, date: toDateStr(currentDate) }}
          onSave={handleCreate}
          onClose={() => setCreateModal(false)}
          isPending={mutating}
          orgId={orgId}
        />
      )}
      {editModal && selectedEvent && (
        <AppointmentModal
          mode="edit"
          initial={editInitial()}
          onSave={handleEdit}
          onClose={() => setEditModal(false)}
          isPending={mutating}
          orgId={orgId}
        />
      )}
      {deleteModal && selectedEvent && (
        <DeleteConfirmModal
          title={selectedEvent.title}
          onConfirm={handleDelete}
          onClose={() => setDeleteModal(false)}
          isPending={mutating}
        />
      )}
    </div>
  );
}
