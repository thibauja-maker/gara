import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  MagnifyingGlass,
  CaretRight,
  Package,
  ShoppingCart,
  Trash,
  Plus,
  CheckCircle,
  X,
  Wrench,
  Drop,
  Car,
  Thermometer,
  Lightning,
  Gear,
  Wind,
  SealCheck,
  Funnel,
} from "@phosphor-icons/react";

// ─── Types ───────────────────────────────────────────────────────────────────
export type CatalogPart = {
  id: string;
  category: string;
  subcategory: string;
  name: string;
  partNumber?: string;
  brand?: string;
  unit?: string;
  desc?: string;
};

export type QuotePart = {
  part: CatalogPart;
  qty: number;
};

// ─── Arbre complet style RockAuto ────────────────────────────────────────────
// Format : { category, subcategory, items: string[] }
const CATALOG_TREE: { category: string; icon?: string; subcategories: { name: string; items: string[] }[] }[] = [
  {
    category: "Courroies & Entraînement",
    subcategories: [
      { name: "Courroie serpentine", items: ["Courroie serpentine", "Kit courroie serpentine", "Tensionneur de courroie", "Galet enrouleur", "Poulie de vilebrequin"] },
      { name: "Distribution", items: ["Kit de distribution (courroie)", "Kit de distribution (chaîne)", "Courroie de distribution", "Chaîne de distribution", "Tendeur de distribution", "Pignon d'arbre à cames", "Pignon de vilebrequin", "Couvre-culasse / cache distribution"] },
      { name: "Courroie de transmission", items: ["Courroie d'alternateur", "Courroie de compresseur A/C", "Courroie de direction assistée"] },
    ],
  },
  {
    category: "Carrosserie & Éclairage",
    subcategories: [
      { name: "Phares & Feux", items: ["Phare avant (assemblage)", "Phare avant (ampoule)", "Feu arrière (assemblage)", "Feu arrière (ampoule)", "Feu de brouillard", "Feu de recul", "Feu de plaque", "Feu clignotant (avant)", "Feu clignotant (arrière)", "Feu stop supplémentaire (3e feu)"] },
      { name: "Poignées & Serrures", items: ["Poignée de porte extérieure", "Poignée de porte intérieure", "Cylindre de serrure de porte", "Serrure de capot", "Câble de capot"] },
      { name: "Rétroviseurs", items: ["Rétroviseur extérieur (assemblage)", "Glace de rétroviseur", "Moteur de rétroviseur"] },
      { name: "Calandre & Carrosserie", items: ["Calandre", "Pare-choc avant (assemblage)", "Pare-choc arrière (assemblage)", "Aile avant", "Capot", "Hayon / coffre (ressort / vérin)"] },
    ],
  },
  {
    category: "Freins & Moyeu",
    subcategories: [
      { name: "Plaquettes de frein", items: ["Plaquettes avant", "Plaquettes arrière", "Plaquettes avant céramique", "Plaquettes arrière céramique", "Plaquettes avant performance", "Plaquettes arrière performance"] },
      { name: "Disques & Tambours", items: ["Disque avant", "Disque arrière", "Disques avant (paire)", "Disques arrière (paire)", "Disques percés / fentes", "Tambour de frein arrière"] },
      { name: "Étriers", items: ["Étrier avant gauche", "Étrier avant droit", "Étrier arrière gauche", "Étrier arrière droit", "Kit de réparation d'étrier", "Piston d'étrier"] },
      { name: "Maître-cylindre & Servos", items: ["Maître-cylindre de frein", "Servo-frein (amplificateur)", "Kit maître-cylindre + servo"] },
      { name: "Frein de stationnement", items: ["Câble de frein à main avant", "Câble de frein à main arrière gauche", "Câble de frein à main arrière droit", "Levier de frein à main"] },
      { name: "Tuyaux & Flexibles de frein", items: ["Flexible de frein avant", "Flexible de frein arrière", "Durite de frein (acier)", "Raccord de frein"] },
      { name: "Liquide & Produits", items: ["Liquide de frein DOT 3", "Liquide de frein DOT 4", "Liquide de frein DOT 5.1", "Graisse de frein"] },
      { name: "Frein ABS", items: ["Modulateur ABS", "Capteur ABS avant gauche", "Capteur ABS avant droit", "Capteur ABS arrière gauche", "Capteur ABS arrière droit", "Anneau ABS (roue dentée)"] },
      { name: "Moyeu & Roulement", items: ["Moyeu de roue avant", "Moyeu de roue arrière", "Roulement de roue avant", "Roulement de roue arrière", "Kit moyeu + roulement", "Joint de roue / joint d'étanchéité"] },
    ],
  },
  {
    category: "Refroidissement",
    subcategories: [
      { name: "Radiateur", items: ["Radiateur moteur", "Radiateur de chauffage (heater core)", "Bouchon de radiateur", "Drain de radiateur"] },
      { name: "Pompe à eau", items: ["Pompe à eau", "Kit pompe à eau + joint"] },
      { name: "Thermostat", items: ["Thermostat", "Boîtier de thermostat", "Joint de thermostat"] },
      { name: "Ventilateur & Embrayage", items: ["Embrayage de ventilateur", "Ventilateur de refroidissement (électrique)", "Moteur de ventilateur", "Module de commande de ventilateur"] },
      { name: "Tuyaux & Durites", items: ["Durite radiateur supérieure", "Durite radiateur inférieure", "Durite de chauffage", "Raccord de durite", "Collier de serrage"] },
      { name: "Liquide de refroidissement", items: ["Liquide de refroidissement concentré (rouge/OAT)", "Liquide de refroidissement concentré (vert)", "Liquide de refroidissement universel (prémélangé)", "Additif anti-fuite radiateur"] },
      { name: "Réservoir & Accessoires", items: ["Vase d'expansion", "Bouchon de vase d'expansion", "Capteur de température moteur", "Capteur de niveau liquide de refroidissement"] },
    ],
  },
  {
    category: "Transmission Automatique",
    subcategories: [
      { name: "Composants internes", items: ["Kit de joints de boîte automatique", "Filtre de boîte automatique", "Joint de carter de boîte automatique", "Disques d'embrayage internes", "Jeu de bandes de freinage"] },
      { name: "Convertisseur de couple", items: ["Convertisseur de couple", "Joint d'étanchéité d'arbre d'entrée"] },
      { name: "Huile de transmission", items: ["ATF Dexron VI", "ATF Mercon V", "ATF CVT", "ATF Toyota WS", "ATF Honda DW-1"] },
      { name: "Capteurs & Solénoïdes", items: ["Solénoïde de commande de passage", "Solénoïde de verrouillage convertisseur", "Capteur de vitesse de sortie", "Capteur de position sélecteur"] },
    ],
  },
  {
    category: "Transmission Manuelle",
    subcategories: [
      { name: "Embrayage", items: ["Kit embrayage complet (disque + pression + butée)", "Disque d'embrayage seul", "Plateau de pression seul", "Butée de débrayage", "Fourchette de débrayage", "Cylindre émetteur d'embrayage", "Cylindre récepteur d'embrayage", "Kit cylindres d'embrayage"] },
      { name: "Boîte de vitesses", items: ["Huile de boîte manuelle 75W-90", "Huile de boîte manuelle GL-4", "Joint d'étanchéité de sélecteur", "Soufflet de câble de vitesses", "Câble de vitesses"] },
      { name: "Volant moteur", items: ["Volant moteur (standard)", "Volant bi-masse", "Kit rodage volant", "Couronne de démarreur"] },
    ],
  },
  {
    category: "Électrique",
    subcategories: [
      { name: "Batterie", items: ["Batterie 12V standard", "Batterie AGM", "Batterie EFB (Start-Stop)", "Serre-batterie / fixation", "Câbles de batterie"] },
      { name: "Alternateur & Démarreur", items: ["Alternateur", "Démarreur", "Régulateur de tension", "Relais de charge"] },
      { name: "Ampoules", items: ["Ampoule H4", "Ampoule H7", "Ampoule H11", "Ampoule HB3 (9005)", "Ampoule HB4 (9006)", "Ampoule LED H7", "Ampoule LED H11", "Ampoule de clignotant (1156 / 1157)", "Ampoule de feu arrière (921)", "Ampoule intérieure (festoon)"] },
      { name: "Fusibles & Relais", items: ["Boîte à fusibles", "Fusible auto (assortiment)", "Relais multifonction (5 broches)", "Relais de démarrage", "Fusible principal (cartouche)"] },
      { name: "Fenêtres & Portes", items: ["Moteur de lève-vitre avant gauche", "Moteur de lève-vitre avant droit", "Moteur de lève-vitre arrière gauche", "Moteur de lève-vitre arrière droit", "Interrupteur de lève-vitre", "Actionneur de serrure de porte", "Module de commande de lève-vitre"] },
      { name: "Tableau de bord & Commandes", items: ["Combiné d'instruments (cluster)", "Interrupteur d'allumage", "Commutateur de colonne de direction", "Commutateur d'essuie-glace", "Commutateur de phares", "Capteur de position pédale de frein"] },
      { name: "Klaxon & Avertisseurs", items: ["Klaxon simple", "Klaxon double", "Klaxon air comprimé"] },
    ],
  },
  {
    category: "Ampoules & Prises",
    subcategories: [
      { name: "Ampoules standards", items: ["H1", "H3", "H4", "H7", "H8", "H9", "H11", "H13", "9004", "9005 (HB3)", "9006 (HB4)", "9007"] },
      { name: "Ampoules latérales & intérieures", items: ["194 (T10 / W5W)", "168", "921 (T15)", "1156 (BA15S)", "1157 (BAY15D)", "3156", "3157", "Festoon 31mm", "Festoon 36mm", "Festoon 42mm"] },
      { name: "Ampoules DEL (LED)", items: ["Kit LED H4", "Kit LED H7", "Kit LED H11", "Kit LED 9005", "Kit LED 9006", "Barre LED universelle", "Ruban LED intérieur"] },
    ],
  },
  {
    category: "Échappement & Émissions",
    subcategories: [
      { name: "Catalyseur", items: ["Catalyseur avant", "Catalyseur arrière", "Catalyseur précat (direct-fit)", "Catalyseur universel"] },
      { name: "Silencieux & Tuyaux", items: ["Silencieux central", "Silencieux arrière", "Tuyau d'échappement avant", "Tuyau d'échappement central", "Tuyau d'échappement arrière", "Collecteur d'échappement", "Manchon de raccordement"] },
      { name: "Joints & Fixations", items: ["Joint de collecteur d'échappement", "Joint de catalyseur", "Joint de silencieux", "Collier d'échappement", "Suspension d'échappement (rondelle caoutchouc)", "Écrou de bride d'échappement"] },
      { name: "Capteurs d'émissions", items: ["Sonde lambda amont (O2 avant)", "Sonde lambda aval (O2 après catalyseur)", "Capteur MAP (pression collecteur)", "Capteur de pression différentielle DPF", "Vanne EGR", "Joint de vanne EGR"] },
    ],
  },
  {
    category: "Carburant & Air",
    subcategories: [
      { name: "Pompe à carburant", items: ["Pompe à carburant (in-tank)", "Module pompe à carburant complet", "Relais de pompe à carburant", "Crépine de pompe à carburant"] },
      { name: "Filtre à carburant", items: ["Filtre à carburant essence", "Filtre à carburant diesel", "Filtre à carburant (intégré au module)"] },
      { name: "Injection & Régulation", items: ["Injecteur (unité)", "Kit joints d'injecteurs", "Rampe d'injection", "Régulateur de pression carburant", "Amortisseur de pression injection", "Corps papillon (throttle body)", "Joint corps papillon", "Capteur TPS (position papillon)", "Capteur MAP", "Capteur MAF (débit masse d'air)"] },
      { name: "Filtre à air & Admission", items: ["Filtre à air moteur", "Filtre à air haute performance (lavable)", "Boîte à air / filtre Sport", "Capteur de température d'air d'admission"] },
      { name: "Réservoir & Évaporation", items: ["Jauge de carburant / flotteur", "Bouchon de réservoir avec clé", "Bouchon de réservoir sans clé", "Canister (filtre charbon actif)", "Vanne de purge du canister", "Tuyau de remplissage réservoir"] },
    ],
  },
  {
    category: "Équipements de Garage",
    subcategories: [
      { name: "Outils de mesure", items: ["Jauge de profondeur de pneu", "Manomètre de pression de pneu", "Thermomètre infrarouge", "Multimètre auto"] },
      { name: "Produits d'atelier", items: ["Nettoyant pour freins (aérosol)", "Dégrippant WD-40 / lubrifiant", "Nettoyant pour carburateur", "Joint liquide silicone RTV", "Frein-filet bleu (Loctite)", "Frein-filet rouge (Loctite)", "Pâte à joint cuivre"] },
    ],
  },
  {
    category: "Visserie & Fixations",
    subcategories: [
      { name: "Boulons & Écrous", items: ["Boulon de roue", "Écrou de roue", "Goujon de roue", "Boulon de carter moteur", "Boulon d'huile (drain plug)"] },
      { name: "Clips & Attaches", items: ["Clips de carrosserie (assortiment)", "Rivet aveugle (assortiment)", "Agrafe de passage de roue", "Clip de fixation de pare-choc"] },
    ],
  },
  {
    category: "Climatisation",
    subcategories: [
      { name: "Compresseur", items: ["Compresseur A/C (assemblage)", "Embrayage compresseur A/C", "Poulie compresseur A/C", "Bobine d'embrayage compresseur", "Joint d'arbre compresseur"] },
      { name: "Condenseur & Évaporateur", items: ["Condenseur A/C", "Évaporateur A/C", "Filtre déshydrateur (bouteille)", "Orifice / tube d'expansion / détendeur"] },
      { name: "Tuyaux & Flexibles A/C", items: ["Flexible A/C haute pression", "Flexible A/C basse pression", "Kit de tuyaux A/C", "Raccord A/C"] },
      { name: "Réfrigérant & Produits", items: ["Réfrigérant R-134a (boîte 250g)", "Réfrigérant R-1234yf", "Huile pour compresseur A/C (PAG 46)", "Huile pour compresseur A/C (PAG 100)", "Kit de recharge A/C avec manomètre", "Colorant fluorescent A/C"] },
      { name: "Chauffage & Ventilation", items: ["Moteur de soufflante (blower motor)", "Module de résistance de soufflante", "Radiateur de chauffage (heater core)", "Vanne de chauffage", "Capteur de température habitacle"] },
    ],
  },
  {
    category: "Allumage",
    subcategories: [
      { name: "Bougies", items: ["Bougie standard (cuivre)", "Bougie platine", "Bougie iridium", "Bougie double platine", "Bougie diesel (bougie de préchauffage)"] },
      { name: "Bobines & Fils HT", items: ["Bobine d'allumage (individuelle)", "Module d'allumage (pack de bobines)", "Fils haute tension (jeu complet)", "Capuchon de fil de bougie"] },
      { name: "Distributeur (allumage classique)", items: ["Distributeur d'allumage", "Rotor de distributeur", "Calotte de distributeur", "Condensateur d'allumage", "Vis platinées"] },
      { name: "Capteurs d'allumage", items: ["Capteur PMH (vilebrequin)", "Capteur d'arbre à cames (phase)", "Module de commande d'allumage ICM"] },
    ],
  },
  {
    category: "Intérieur",
    subcategories: [
      { name: "Tapis & Revêtements", items: ["Tapis de sol avant (caoutchouc)", "Tapis de sol arrière (caoutchouc)", "Tapis de sol avant (molleton)", "Tapis de coffre"] },
      { name: "Ceintures & Sécurité", items: ["Prétensionneur de ceinture", "Enrouleur de ceinture", "Bouclette de ceinture"] },
      { name: "Commandes & Commutateurs", items: ["Bouton de lève-vitre", "Interrupteur de rétroviseur", "Bouton de verrouillage des portes"] },
      { name: "Habitacle", items: ["Accoudoir central", "Poignée de maintien (plafond)", "Garniture de portière (clip de fixation)", "Cendrier"] },
    ],
  },
  {
    category: "Éclairage",
    subcategories: [
      { name: "Phares", items: ["Phare complet avant gauche", "Phare complet avant droit", "Verre de phare", "Réflecteur de phare"] },
      { name: "Feux arrière", items: ["Feu arrière gauche (assemblage)", "Feu arrière droit (assemblage)", "Lentille de feu arrière"] },
      { name: "Feux de jour (DRL)", items: ["Module DRL", "Feu de jour LED"] },
      { name: "Éclairage intérieur", items: ["Plafonnier", "Éclairage de boîte à gants", "Éclairage de coffre", "Éclairage de tableau de bord"] },
    ],
  },
  {
    category: "Direction",
    subcategories: [
      { name: "Crémaillère & Boîtier de direction", items: ["Crémaillère de direction (mécanique)", "Crémaillère de direction assistée (hydraulique)", "Crémaillère de direction assistée (électrique EPS)", "Boîtier de direction (recirculation à billes)", "Joint d'entrée de crémaillère (soufflet)"] },
      { name: "Colonne de direction", items: ["Colonne de direction (assemblage)", "Joint de cardan de colonne", "Palier de colonne de direction", "Commutateur de colonne de direction"] },
      { name: "Biellettes & Rotules de direction", items: ["Biellette de direction intérieure gauche", "Biellette de direction intérieure droite", "Biellette de direction extérieure gauche", "Biellette de direction extérieure droite", "Kit biellette complète (int + ext)"] },
      { name: "Direction assistée hydraulique", items: ["Pompe de direction assistée", "Réservoir de direction assistée", "Flexible haute pression direction assistée", "Tuyau de retour direction assistée", "Liquide de direction assistée"] },
    ],
  },
  {
    category: "Suspension",
    subcategories: [
      { name: "Amortisseurs & Ressorts", items: ["Amortisseur avant gauche", "Amortisseur avant droit", "Amortisseur arrière gauche", "Amortisseur arrière droit", "Ressort de suspension avant gauche", "Ressort de suspension avant droit", "Ressort de suspension arrière gauche", "Ressort de suspension arrière droit", "Kit complet (amortisseur + ressort)", "Butée d'amortisseur (coupelle supérieure)"] },
      { name: "Triangles & Bras de suspension", items: ["Bras inférieur avant gauche", "Bras inférieur avant droit", "Bras supérieur avant gauche", "Bras supérieur avant droit", "Bras de suspension arrière gauche", "Bras de suspension arrière droit", "Silentbloc de triangle avant", "Silentbloc de triangle arrière"] },
      { name: "Rotules de suspension", items: ["Rotule inférieure avant gauche", "Rotule inférieure avant droit", "Rotule supérieure avant gauche", "Rotule supérieure avant droit", "Rotule de biellette de direction"] },
      { name: "Barre stabilisatrice", items: ["Biellette de barre stabilisatrice avant gauche", "Biellette de barre stabilisatrice avant droit", "Biellette de barre stabilisatrice arrière gauche", "Biellette de barre stabilisatrice arrière droit", "Silent-bloc de barre stabilisatrice avant (paire)", "Silent-bloc de barre stabilisatrice arrière (paire)"] },
      { name: "Géométrie & Alignement", items: ["Boulon d'alignement", "Cale de carrossage", "Douille de carrossage / chasse", "Plaque de réglage de carrossage"] },
    ],
  },
  {
    category: "Tuyaux, Durites & Colliers",
    subcategories: [
      { name: "Durites moteur", items: ["Durite radiateur supérieure", "Durite radiateur inférieure", "Durite de dégazage", "Tuyau de reniflard moteur"] },
      { name: "Durites de chauffage", items: ["Durite de chauffage entrée", "Durite de chauffage sortie"] },
      { name: "Colliers & Raccords", items: ["Collier de serrage Jubilee (assortiment)", "Collier de serrage à oreille", "Raccord en T / Y (caoutchouc)", "Réducteur de durite"] },
    ],
  },
  {
    category: "Roues & Pneus",
    subcategories: [
      { name: "Pneus été", items: ["Pneu 185/65R15 été", "Pneu 195/65R15 été", "Pneu 205/55R16 été", "Pneu 215/55R17 été", "Pneu 225/45R17 été", "Pneu 225/50R18 été"] },
      { name: "Pneus hiver", items: ["Pneu 185/65R15 hiver", "Pneu 195/65R15 hiver", "Pneu 205/55R16 hiver", "Pneu 215/55R17 hiver", "Pneu 225/45R17 hiver", "Pneu 225/50R18 hiver"] },
      { name: "Pneus toutes saisons", items: ["Pneu 205/55R16 toutes saisons", "Pneu 215/55R17 toutes saisons", "Pneu 225/65R17 toutes saisons"] },
      { name: "TPMS & Valves", items: ["Capteur TPMS 433MHz", "Capteur TPMS 315MHz", "Kit de valve TPMS en caoutchouc", "Kit de valve TPMS en métal", "Outil de programmation TPMS"] },
      { name: "Jantes", items: ["Jante en acier (universelle)", "Capsule de jante (enjoliveur)", "Kit de centrage de jante"] },
    ],
  },
  {
    category: "Moteur & Culasse",
    subcategories: [
      { name: "Joints moteur", items: ["Joint de culasse", "Kit joints moteur complet (bas moteur)", "Kit joints moteur complet (haut moteur)", "Joint de cache-culbuteurs", "Joint de carter d'huile", "Joint de collecteur d'admission", "Joint de collecteur d'échappement", "Joint d'étanchéité d'arbre à cames", "Joint d'étanchéité de vilebrequin (avant)", "Joint d'étanchéité de vilebrequin (arrière)"] },
      { name: "Distribution & Arbre à cames", items: ["Arbre à cames (admission)", "Arbre à cames (échappement)", "Poussoir hydraulique (lifter)", "Culbuteur (rocker arm)", "Tige de culbuteur (pushrod)", "Ressort de soupape", "Joint de queue de soupape"] },
      { name: "Pistons & Vilebrequin", items: ["Piston (unité)", "Bague segment de piston (kit)", "Bielle (unité)", "Coussinets de bielle", "Coussinets de vilebrequin (kit palier)"] },
      { name: "Huile moteur", items: ["Huile moteur synthétique 0W-20", "Huile moteur synthétique 0W-40", "Huile moteur synthétique 5W-20", "Huile moteur synthétique 5W-30", "Huile moteur synthétique 5W-40", "Huile moteur synthétique 10W-30", "Huile moteur conventionnelle 10W-40", "Huile moteur dieselible 5W-30 C3"] },
      { name: "Filtres", items: ["Filtre à huile", "Filtre à huile à double paroi (anti-retour)", "Bouchon vidange d'huile"] },
      { name: "Lubrification", items: ["Pompe à huile", "Crépine de pompe à huile", "Joint de crépine", "Radiateur d'huile (refroidisseur)", "Durite de radiateur d'huile"] },
    ],
  },
  {
    category: "Transmission & Arbres",
    subcategories: [
      { name: "Arbres de transmission (demi-arbres)", items: ["Demi-arbre avant gauche (complet)", "Demi-arbre avant droit (complet)", "Demi-arbre arrière gauche (complet)", "Demi-arbre arrière droit (complet)"] },
      { name: "Cardan & Soufflets", items: ["Soufflet de cardan côté roue (extérieur)", "Soufflet de cardan côté boîte (intérieur)", "Kit soufflet complet (arbre)", "Joint de cardan (CV joint rebuild)", "Graisse de cardan"] },
      { name: "Différentiel", items: ["Joint d'entrée de différentiel", "Joint de pignon de différentiel", "Roulement de différentiel", "Huile de pont / différentiel 75W-90", "Huile de pont / différentiel 80W-90"] },
      { name: "Arbre de transmission (propshaft)", items: ["Arbre de transmission central (propeller shaft)", "Palier central d'arbre de transmission", "Joint universel (U-joint)", "Bride d'arbre de transmission"] },
    ],
  },
  {
    category: "Essuie-glace & Lave-glace",
    subcategories: [
      { name: "Essuie-glace", items: ["Balai d'essuie-glace avant conducteur", "Balai d'essuie-glace avant passager", "Balai d'essuie-glace arrière", "Bras d'essuie-glace avant", "Bras d'essuie-glace arrière", "Moteur d'essuie-glace avant", "Moteur d'essuie-glace arrière", "Mécanisme d'essuie-glace (linkage)"] },
      { name: "Lave-glace", items: ["Pompe de lave-glace avant", "Pompe de lave-glace arrière", "Réservoir de lave-glace", "Gicleur de lave-glace avant", "Gicleur de lave-glace arrière", "Liquide lave-vitre été (concentré)", "Liquide lave-vitre hiver -40°C"] },
    ],
  },
];

// Aplatir le catalogue en objets CatalogPart pour la recherche
function buildFlatCatalog(): CatalogPart[] {
  const flat: CatalogPart[] = [];
  for (const catNode of CATALOG_TREE) {
    for (const sub of catNode.subcategories) {
      for (const item of sub.items) {
        flat.push({
          id: `${catNode.category}__${sub.name}__${item}`.replace(/\s+/g, "_").replace(/[^a-zA-Z0-9_]/g, ""),
          category: catNode.category,
          subcategory: sub.name,
          name: item,
        });
      }
    }
  }
  return flat;
}

const FLAT_CATALOG = buildFlatCatalog();

// ─── Icônes par catégorie ────────────────────────────────────────────────────
const CAT_ICON: Record<string, React.ReactNode> = {
  "Courroies & Entraînement":   <Gear size={15} weight="duotone" className="text-amber-500" />,
  "Carrosserie & Éclairage":    <Car size={15} weight="duotone" className="text-zinc-500" />,
  "Freins & Moyeu":             <Car size={15} weight="duotone" className="text-red-500" />,
  "Refroidissement":            <Thermometer size={15} weight="duotone" className="text-cyan-500" />,
  "Transmission Automatique":   <Gear size={15} weight="duotone" className="text-violet-500" />,
  "Transmission Manuelle":      <Wrench size={15} weight="duotone" className="text-orange-500" />,
  "Électrique":                 <Lightning size={15} weight="duotone" className="text-yellow-500" />,
  "Ampoules & Prises":          <Lightning size={15} weight="duotone" className="text-yellow-400" />,
  "Échappement & Émissions":    <Wind size={15} weight="duotone" className="text-slate-500" />,
  "Carburant & Air":            <Drop size={15} weight="duotone" className="text-blue-500" />,
  "Équipements de Garage":      <Wrench size={15} weight="duotone" className="text-stone-500" />,
  "Visserie & Fixations":       <Package size={15} weight="duotone" className="text-stone-400" />,
  "Climatisation":              <Wind size={15} weight="duotone" className="text-sky-400" />,
  "Allumage":                   <Lightning size={15} weight="duotone" className="text-orange-400" />,
  "Intérieur":                  <Car size={15} weight="duotone" className="text-indigo-400" />,
  "Éclairage":                  <Lightning size={15} weight="duotone" className="text-amber-400" />,
  "Direction":                  <Gear size={15} weight="duotone" className="text-teal-500" />,
  "Suspension":                 <Car size={15} weight="duotone" className="text-green-500" />,
  "Tuyaux, Durites & Colliers": <Package size={15} weight="duotone" className="text-blue-400" />,
  "Roues & Pneus":              <Car size={15} weight="duotone" className="text-gray-500" />,
  "Moteur & Culasse":           <Wrench size={15} weight="duotone" className="text-red-400" />,
  "Transmission & Arbres":      <Gear size={15} weight="duotone" className="text-purple-500" />,
  "Essuie-glace & Lave-glace":  <Wind size={15} weight="duotone" className="text-blue-300" />,
};

// ─── Composant Principal ─────────────────────────────────────────────────────
export default function PartsCatalog({
  orgId,
  onCreateEstimate,
}: {
  orgId: string;
  onCreateEstimate?: (parts: QuotePart[]) => void;
}) {
  const [search, setSearch] = useState("");
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set());
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedSubcategory, setSelectedSubcategory] = useState<string | null>(null);
  const [quoteParts, setQuoteParts] = useState<QuotePart[]>([]);
  const [showCart, setShowCart] = useState(false);
  const [addedId, setAddedId] = useState<string | null>(null);

  const toggleCategory = (cat: string) => {
    setExpandedCategories((prev) => {
      const next = new Set(prev);
      if (next.has(cat)) {
        next.delete(cat);
        if (selectedCategory === cat) {
          setSelectedCategory(null);
          setSelectedSubcategory(null);
        }
      } else {
        next.add(cat);
        setSelectedCategory(cat);
        setSelectedSubcategory(null);
      }
      return next;
    });
    setSearch("");
  };

  const handleSelectSub = (cat: string, sub: string) => {
    setSelectedCategory(cat);
    setSelectedSubcategory(selectedSubcategory === sub && selectedCategory === cat ? null : sub);
    setSearch("");
  };

  // Pièces visibles selon navigation / recherche
  const visibleItems = useMemo(() => {
    if (search.trim().length >= 2) {
      const q = search.toLowerCase();
      return FLAT_CATALOG.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.subcategory.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q)
      );
    }
    if (selectedSubcategory && selectedCategory) {
      return FLAT_CATALOG.filter(
        (p) => p.category === selectedCategory && p.subcategory === selectedSubcategory
      );
    }
    if (selectedCategory) {
      return FLAT_CATALOG.filter((p) => p.category === selectedCategory);
    }
    return [];
  }, [search, selectedCategory, selectedSubcategory]);

  const addToQuote = (part: CatalogPart) => {
    setQuoteParts((prev) => {
      const existing = prev.find((q) => q.part.id === part.id);
      if (existing) return prev.map((q) => (q.part.id === part.id ? { ...q, qty: q.qty + 1 } : q));
      return [...prev, { part, qty: 1 }];
    });
    setAddedId(part.id);
    setTimeout(() => setAddedId(null), 1200);
  };

  const removeFromQuote = (partId: string) =>
    setQuoteParts((prev) => prev.filter((q) => q.part.id !== partId));

  const updateQty = (partId: string, qty: number) => {
    if (qty <= 0) { removeFromQuote(partId); return; }
    setQuoteParts((prev) => prev.map((q) => (q.part.id === partId ? { ...q, qty } : q)));
  };

  const quoteCount = quoteParts.reduce((s, q) => s + q.qty, 0);

  return (
    <section className="bg-background min-h-screen">
      <div className="flex h-[calc(100vh-56px)]">

        {/* ══ Sidebar arbre ══ */}
        <aside className="w-72 shrink-0 border-r border-border bg-card flex flex-col overflow-hidden">
          {/* Header sidebar */}
          <div className="px-4 py-3 border-b border-border flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <Funnel size={15} weight="duotone" className="text-primary shrink-0" />
              <span className="text-xs font-semibold text-foreground uppercase tracking-wider truncate">Catalogue</span>
            </div>
            <Badge className="text-[10px] px-1.5 py-0 bg-muted text-muted-foreground border-0 shrink-0">
              {FLAT_CATALOG.length} pièces
            </Badge>
          </div>

          {/* Arbre scrollable */}
          <nav className="flex-1 overflow-y-auto py-1">
            {CATALOG_TREE.map((catNode) => {
              const isExpanded = expandedCategories.has(catNode.category);
              const isActivecat = selectedCategory === catNode.category;
              const catCount = FLAT_CATALOG.filter((p) => p.category === catNode.category).length;

              return (
                <div key={catNode.category}>
                  {/* Catégorie principale */}
                  <button
                    onClick={() => toggleCategory(catNode.category)}
                    className={`w-full flex items-center gap-2 px-3 py-2.5 text-left transition-colors group ${
                      isActivecat
                        ? "bg-primary/10 text-primary"
                        : "text-muted-foreground hover:bg-muted hover:text-foreground"
                    }`}
                  >
                    <span className="shrink-0">
                      {CAT_ICON[catNode.category] ?? <Package size={15} weight="duotone" />}
                    </span>
                    <span className="flex-1 text-xs font-medium truncate">{catNode.category}</span>
                    <span className="text-[10px] opacity-50 shrink-0">{catCount}</span>
                    <CaretRight
                      size={11}
                      weight="bold"
                      className={`shrink-0 transition-transform duration-200 opacity-50 ${isExpanded ? "rotate-90" : ""}`}
                    />
                  </button>

                  {/* Sous-catégories */}
                  {isExpanded && (
                    <div className="border-l-2 border-primary/20 ml-5">
                      {catNode.subcategories.map((sub) => {
                        const isActiveSub = selectedSubcategory === sub.name && selectedCategory === catNode.category;
                        return (
                          <button
                            key={sub.name}
                            onClick={() => handleSelectSub(catNode.category, sub.name)}
                            className={`w-full flex items-center gap-1.5 pl-3 pr-3 py-2 text-left transition-colors ${
                              isActiveSub
                                ? "bg-primary/10 text-primary font-semibold"
                                : "text-muted-foreground hover:bg-muted/60 hover:text-foreground"
                            }`}
                          >
                            <CaretRight size={9} weight="bold" className="shrink-0 opacity-40" />
                            <span className="flex-1 text-xs truncate">{sub.name}</span>
                            <span className="text-[10px] opacity-40 shrink-0">{sub.items.length}</span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </nav>
        </aside>

        {/* ══ Contenu principal ══ */}
        <div className="flex-1 flex flex-col overflow-hidden">

          {/* Topbar: recherche + panier */}
          <div className="px-6 py-3 border-b border-border bg-card flex items-center gap-3 shrink-0">
            <div className="relative flex-1 max-w-xl">
              <MagnifyingGlass size={15} weight="duotone" className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Rechercher une pièce (ex: plaquettes, AR avant, joint…)"
                className="pl-9 h-9 rounded-lg border-border text-sm bg-background"
              />
              {search && (
                <button
                  onClick={() => setSearch("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  <X size={13} weight="bold" />
                </button>
              )}
            </div>

            {/* Bouton soumission */}
            <button
              onClick={() => setShowCart(!showCart)}
              className={`relative flex items-center gap-2 px-3 py-2 rounded-lg border text-sm font-medium transition-all shrink-0 ${
                quoteParts.length > 0
                  ? "bg-primary text-primary-foreground border-primary shadow-sm"
                  : "bg-background text-muted-foreground border-border hover:bg-muted"
              }`}
            >
              <ShoppingCart size={15} weight="duotone" />
              <span className="hidden sm:inline">Soumission</span>
              {quoteCount > 0 && (
                <span className="bg-primary-foreground text-primary text-[10px] font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center">
                  {quoteCount}
                </span>
              )}
            </button>
          </div>

          {/* Panier slide-down */}
          {showCart && (
            <div className="border-b border-border bg-card/95 px-6 py-4 shadow-md shrink-0">
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-xs font-semibold uppercase tracking-wider text-foreground flex items-center gap-2">
                  <ShoppingCart size={13} weight="duotone" className="text-primary" />
                  Pièces sélectionnées pour la soumission
                </h2>
                <button onClick={() => setShowCart(false)} className="text-muted-foreground hover:text-foreground">
                  <X size={14} weight="bold" />
                </button>
              </div>

              {quoteParts.length === 0 ? (
                <p className="text-xs text-muted-foreground py-2 text-center">
                  Aucune pièce ajoutée. Sélectionnez des pièces dans le catalogue et cliquez « Ajouter ».
                </p>
              ) : (
                <>
                  <div className="space-y-2 max-h-56 overflow-y-auto mb-3">
                    {quoteParts.map((q) => (
                      <div key={q.part.id} className="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-muted/40 hover:bg-muted/60 group">
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-medium text-foreground leading-snug" style={{ display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }} title={q.part.name}>{q.part.name}</p>
                          <p className="text-[10px] text-muted-foreground mt-0.5 truncate">{q.part.category} › {q.part.subcategory}</p>
                        </div>
                        {/* Quantité saisie directement */}
                        <div className="flex items-center gap-1.5 shrink-0">
                          <span className="text-[10px] text-muted-foreground">Qté</span>
                          <Input
                            type="number"
                            min="1"
                            value={q.qty}
                            onChange={(e) => updateQty(q.part.id, parseInt(e.target.value) || 1)}
                            className="w-20 h-9 text-center text-sm font-medium border-border rounded px-2 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                          />
                        </div>
                        <button
                          onClick={() => removeFromQuote(q.part.id)}
                          className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-red-500 transition-all"
                        >
                          <Trash size={13} weight="duotone" />
                        </button>
                      </div>
                    ))}
                  </div>
                  <div className="flex items-center justify-between gap-3 pt-2 border-t border-border">
                    <p className="text-xs text-muted-foreground">
                      <span className="font-semibold text-foreground">{quoteCount}</span> pièce{quoteCount > 1 ? "s" : ""} — les prix seront entrés dans la soumission.
                    </p>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={() => setQuoteParts([])} className="text-xs rounded-lg border-border gap-1">
                        <Trash size={11} weight="duotone" /> Vider
                      </Button>
                      {onCreateEstimate && (
                        <Button
                          size="sm"
                          onClick={() => { onCreateEstimate(quoteParts); setQuoteParts([]); setShowCart(false); }}
                          className="text-xs rounded-lg bg-primary text-primary-foreground gap-1.5 shadow-sm"
                        >
                          <SealCheck size={12} weight="duotone" />
                          Créer la soumission
                        </Button>
                      )}
                    </div>
                  </div>
                </>
              )}
            </div>
          )}

          {/* ── Zone de résultats ── */}
          <div className="flex-1 overflow-y-auto px-6 py-4">

            {/* Fil d'Ariane */}
            {(selectedCategory || search.trim().length >= 2) && (
              <div className="flex items-center flex-wrap gap-1 text-xs text-muted-foreground mb-4">
                <button
                  onClick={() => { setSelectedCategory(null); setSelectedSubcategory(null); setExpandedCategories(new Set()); setSearch(""); }}
                  className="hover:text-primary transition-colors"
                >
                  Catalogue
                </button>
                {selectedCategory && !search && (
                  <>
                    <CaretRight size={9} weight="bold" />
                    <button
                      onClick={() => { setSelectedSubcategory(null); }}
                      className={`transition-colors ${!selectedSubcategory ? "text-foreground font-medium" : "hover:text-primary"}`}
                    >
                      {selectedCategory}
                    </button>
                  </>
                )}
                {selectedSubcategory && !search && (
                  <>
                    <CaretRight size={9} weight="bold" />
                    <span className="text-foreground font-medium">{selectedSubcategory}</span>
                  </>
                )}
                {search.trim().length >= 2 && (
                  <>
                    <CaretRight size={9} weight="bold" />
                    <span className="text-foreground font-medium">Recherche : « {search} »</span>
                  </>
                )}
                <span className="text-muted-foreground/50 ml-1">
                  — {visibleItems.length} résultat{visibleItems.length !== 1 ? "s" : ""}
                </span>
              </div>
            )}

            {/* État vide: aucune sélection */}
            {!selectedCategory && search.trim().length < 2 && (
              <div className="flex flex-col items-center justify-center h-full text-center px-4 py-20">
                <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center mb-4">
                  <Package size={28} weight="duotone" className="text-muted-foreground/50" />
                </div>
                <h3 className="text-sm font-semibold text-foreground mb-1">Sélectionnez une catégorie</h3>
                <p className="text-xs text-muted-foreground max-w-xs">
                  Utilisez l&#39;arbre de gauche pour naviguer dans les {CATALOG_TREE.length} catégories de composants automobiles, ou recherchez directement une pièce.
                </p>
              </div>
            )}

            {/* Résultats: vue par sous-catégories groupées */}
            {visibleItems.length > 0 && search.trim().length < 2 && (
              <div className="space-y-6">
                {(() => {
                  // Grouper par sous-catégorie
                  const groups: Record<string, CatalogPart[]> = {};
                  for (const item of visibleItems) {
                    if (!groups[item.subcategory]) groups[item.subcategory] = [];
                    groups[item.subcategory].push(item);
                  }
                  return Object.entries(groups).map(([subName, items]) => (
                    <div key={subName}>
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{subName}</h3>
                        <Separator className="flex-1" />
                        <span className="text-[10px] text-muted-foreground/60">{items.length}</span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-2">
                        {items.map((part) => (
                          <PartCard
                            key={part.id}
                            part={part}
                            inQuote={quoteParts.find((q) => q.part.id === part.id)}
                            justAdded={addedId === part.id}
                            onAdd={() => addToQuote(part)}
                          />
                        ))}
                      </div>
                    </div>
                  ));
                })()}
              </div>
            )}

            {/* Résultats de recherche: liste plate */}
            {search.trim().length >= 2 && visibleItems.length > 0 && (
              <div className="space-y-2">
                {visibleItems.map((part) => (
                  <div
                    key={part.id}
                    className={`flex items-center gap-3 px-4 py-3 rounded-xl border bg-card transition-all ${
                      addedId === part.id ? "border-primary/60 bg-primary/5" : "border-border hover:border-primary/30 hover:bg-muted/30"
                    }`}
                  >
                    <div className="flex-1 min-w-0">
                      <p title={part.name} className="text-sm font-medium text-foreground whitespace-normal leading-snug">{part.name}</p>
                      <p className="text-[11px] text-muted-foreground">
                        {part.category} <CaretRight size={8} weight="bold" className="inline" /> {part.subcategory}
                      </p>
                    </div>
                    <AddButton
                      inQuote={quoteParts.find((q) => q.part.id === part.id)}
                      justAdded={addedId === part.id}
                      onAdd={() => addToQuote(part)}
                    />
                  </div>
                ))}
              </div>
            )}

            {/* Aucun résultat de recherche */}
            {search.trim().length >= 2 && visibleItems.length === 0 && (
              <div className="text-center py-16 text-muted-foreground text-sm">
                <MagnifyingGlass size={32} weight="duotone" className="mx-auto mb-3 opacity-30" />
                Aucune pièce trouvée pour « {search} ».
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Carte de pièce ──────────────────────────────────────────────────────────
function PartCard({
  part,
  inQuote,
  justAdded,
  onAdd,
}: {
  part: CatalogPart;
  inQuote?: QuotePart;
  justAdded: boolean;
  onAdd: () => void;
}) {
  return (
    <div
      className={`flex items-start justify-between gap-3 px-4 py-3 rounded-xl border bg-card transition-all ${
        justAdded ? "border-primary/60 bg-primary/5" : "border-border hover:border-primary/30 hover:bg-muted/20"
      }`}
    >
      <p
        title={part.name}
        className="text-sm font-medium text-foreground flex-1 min-w-0 leading-snug"
        style={{ display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}
      >{part.name}</p>
      <AddButton inQuote={inQuote} justAdded={justAdded} onAdd={onAdd} />
    </div>
  );
}

function AddButton({
  inQuote,
  justAdded,
  onAdd,
}: {
  inQuote?: QuotePart;
  justAdded: boolean;
  onAdd: () => void;
}) {
  return (
    <button
      onClick={onAdd}
      className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all shrink-0 ${
        justAdded
          ? "bg-green-600 text-white"
          : inQuote
          ? "bg-primary/15 text-primary border border-primary/40"
          : "bg-primary text-primary-foreground hover:opacity-90"
      }`}
    >
      {justAdded ? (
        <><CheckCircle size={12} weight="fill" /> Ajouté</>
      ) : inQuote ? (
        <><Plus size={11} weight="bold" /> +1 ({inQuote.qty})</>
      ) : (
        <><Plus size={11} weight="bold" /> Ajouter</>
      )}
    </button>
  );
}
