import { useState, useMemo } from "react";
import { useQuery } from "@animaapp/playground-react-sdk";
import type { RepairOrder, Customer } from "@/lib/anima-sdk-stub";
import { usePriceVisibility } from "@/context/PriceVisibilityContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import {
  ChartBar,
  CurrencyDollar,
  Receipt,
  UsersThree,
  Wrench,
  TrendUp,
  TrendDown,
  CalendarBlank,
  DownloadSimple,
  CheckCircle,
  Warning,
  Clock,
  Car,
  Package,
} from "@phosphor-icons/react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  Legend,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from "recharts";

const TABS = [
  { id: "today", label: "Résumé du jour", icon: CalendarBlank },
  { id: "overview", label: "Aperçu", icon: ChartBar },
  { id: "revenue", label: "Revenus", icon: CurrencyDollar },
  { id: "invoices", label: "Factures", icon: Receipt },
  { id: "customers", label: "Clients", icon: UsersThree },
  { id: "services", label: "Services", icon: Wrench },
];

const MONTH_LABELS_FR = ["Jan", "Fév", "Mar", "Avr", "Mai", "Jun", "Jul", "Aoû", "Sep", "Oct", "Nov", "Déc"];
const PERIODS = ["Ce mois", "3 derniers mois", "6 derniers mois", "Cette année"];

type Period = typeof PERIODS[number];

function getPeriodMonths(period: Period): number {
  if (period === "Ce mois") return 1;
  if (period === "3 derniers mois") return 3;
  if (period === "6 derniers mois") return 6;
  return 12;
}

function exportCSV(rows: string[][], filename: string) {
  const csv = rows.map((r) => r.map((c) => `"${c}"`).join(",")).join("\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export default function Reports({ orgId }: { orgId: string }) {
  const { pricesVisible } = usePriceVisibility();
  const [activeTab, setActiveTab] = useState("today");
  const [summaryView, setSummaryView] = useState<"day" | "week" | "month">("day");
  const [period, setPeriod] = useState<Period>("Cette année");

  const fmtC = (n: number) =>
    pricesVisible
      ? n.toLocaleString("fr-CA", { style: "currency", currency: "CAD" })
      : "• • • •";

  const fmtN = (n: number) =>
    pricesVisible ? n.toFixed(2) + " $" : "• • • •";

  // ── Summary window helpers ───────────────────────────────────────────────
  const summaryStart = useMemo(() => {
    const d = new Date();
    if (summaryView === "day") return new Date(d.getFullYear(), d.getMonth(), d.getDate());
    if (summaryView === "week") {
      const day = d.getDay(); // 0=Sun
      const diff = day === 0 ? 6 : day - 1; // Monday-first
      return new Date(d.getFullYear(), d.getMonth(), d.getDate() - diff);
    }
    return new Date(d.getFullYear(), d.getMonth(), 1);
  }, [summaryView]);

  const summaryLabel = summaryView === "day" ? "aujourd\'hui" : summaryView === "week" ? "cette semaine" : "ce mois-ci";

  // ── DB data ──────────────────────────────────────────────────────────────
  const { data: allOrders } = useQuery<RepairOrder>("RepairOrder", {
    where: { orgId },
    orderBy: { date: "asc" },
  });
  const { data: allCustomers } = useQuery<Customer>("Customer", { where: { orgId } });

  const orders = allOrders ?? [];
  const customers = allCustomers ?? [];

  // ── Summary metrics ──────────────────────────────────────────────────────
  const summaryOrders = useMemo(
    () => orders.filter((o) => new Date(o.date) >= summaryStart),
    [orders, summaryStart]
  );
  const summaryCustomers = useMemo(
    () => customers.filter((c) => new Date(c.createdAt) >= summaryStart),
    [customers, summaryStart]
  );
  const summaryPaid = summaryOrders.filter((o) => o.status === "Payée");
  const summaryUnpaid = summaryOrders.filter((o) => o.status === "Non payée" || o.status === "Partielle");
  const summaryRevenue = summaryPaid.reduce((s, o) => s + o.total, 0);
  const summaryTPS = summaryPaid.reduce((s, o) => s + o.tpsAmount, 0);
  const summaryTVQ = summaryPaid.reduce((s, o) => s + o.tvqAmount, 0);
  // Estimations = orders with status "Brouillon" or "Soumission"
  const summaryEstimates = summaryOrders.filter(
    (o) => o.status === "Brouillon" || o.status === "Soumission" || o.status === "Estimation"
  );
  // Unique clients served (appeared in an order)
  const summaryServedNames = useMemo(
    () => [...new Set(summaryOrders.map((o) => o.customerName))],
    [summaryOrders]
  );

  // ── Period filter ────────────────────────────────────────────────────────
  const periodMonths = getPeriodMonths(period);
  const now = new Date();
  const periodStart = new Date(now.getFullYear(), now.getMonth() - (periodMonths - 1), 1);

  const filteredOrders = useMemo(() =>
    orders.filter((o) => new Date(o.date) >= periodStart),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [orders, period]
  );

  // ── Revenue by month ─────────────────────────────────────────────────────
  const revenueByMonth = useMemo(() => {
    const map: Record<string, { revenue: number; count: number; tps: number; tvq: number }> = {};
    for (let i = periodMonths - 1; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = `${MONTH_LABELS_FR[d.getMonth()]} ${d.getFullYear()}`;
      map[key] = { revenue: 0, count: 0, tps: 0, tvq: 0 };
    }
    for (const o of orders) {
      const d = new Date(o.date);
      if (d < periodStart) continue;
      const key = `${MONTH_LABELS_FR[d.getMonth()]} ${d.getFullYear()}`;
      if (!map[key]) continue;
      if (o.status === "Payée") {
        map[key].revenue += o.total;
        map[key].tps += o.tpsAmount;
        map[key].tvq += o.tvqAmount;
      }
      map[key].count++;
    }
    return Object.entries(map).map(([label, v]) => ({
      label: periodMonths <= 3 ? label : label.split(" ")[0],
      revenue: parseFloat(v.revenue.toFixed(2)),
      tps: parseFloat(v.tps.toFixed(2)),
      tvq: parseFloat(v.tvq.toFixed(2)),
      count: v.count,
    }));
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orders, period]);

  // ── Aggregates ───────────────────────────────────────────────────────────
  const totalRevenue = filteredOrders.filter((o) => o.status === "Payée").reduce((s, o) => s + o.total, 0);
  const totalTPS = filteredOrders.filter((o) => o.status === "Payée").reduce((s, o) => s + o.tpsAmount, 0);
  const totalTVQ = filteredOrders.filter((o) => o.status === "Payée").reduce((s, o) => s + o.tvqAmount, 0);
  const totalSubtotal = filteredOrders.filter((o) => o.status === "Payée").reduce((s, o) => s + o.subtotal, 0);
  const unpaidTotal = filteredOrders.filter((o) => o.status !== "Payée").reduce((s, o) => s + o.total, 0);
  const invoiceCount = filteredOrders.length;
  const paidCount = filteredOrders.filter((o) => o.status === "Payée").length;
  const unpaidCount = filteredOrders.filter((o) => o.status === "Non payée" || o.status === "Partielle").length;
  const avgInvoice = paidCount > 0 ? totalRevenue / paidCount : 0;

  // ── Customer stats ───────────────────────────────────────────────────────
  const customerOrderMap = useMemo(() => {
    const map: Record<string, { name: string; count: number; total: number }> = {};
    for (const o of filteredOrders) {
      if (!map[o.customerName]) map[o.customerName] = { name: o.customerName, count: 0, total: 0 };
      map[o.customerName].count++;
      if (o.status === "Payée") map[o.customerName].total += o.total;
    }
    return Object.values(map).sort((a, b) => b.total - a.total);
  }, [filteredOrders]);

  const topCustomers = customerOrderMap.slice(0, 8);

  // ── Service type breakdown (heuristic from vehicleInfo / customerName) ───
  const statusBreakdown = useMemo(() => {
    const paid = filteredOrders.filter((o) => o.status === "Payée").length;
    const unpaid = filteredOrders.filter((o) => o.status === "Non payée").length;
    const partial = filteredOrders.filter((o) => o.status === "Partielle").length;
    const total = Math.max(1, filteredOrders.length);
    return [
      { name: "Payées", value: paid, pct: Math.round((paid / total) * 100), color: "hsl(var(--primary))" },
      { name: "Non payées", value: unpaid, pct: Math.round((unpaid / total) * 100), color: "hsl(var(--destructive))" },
      { name: "Partielles", value: partial, pct: Math.round((partial / total) * 100), color: "hsl(var(--muted-foreground))" },
    ];
  }, [filteredOrders]);

  // ── New customers by month ───────────────────────────────────────────────
  const newCustomersByMonth = useMemo(() => {
    const map: Record<string, number> = {};
    for (let i = periodMonths - 1; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = `${MONTH_LABELS_FR[d.getMonth()]} ${d.getFullYear()}`;
      map[key] = 0;
    }
    for (const c of customers) {
      const d = new Date(c.createdAt);
      if (d < periodStart) continue;
      const key = `${MONTH_LABELS_FR[d.getMonth()]} ${d.getFullYear()}`;
      if (map[key] !== undefined) map[key]++;
    }
    return Object.entries(map).map(([label, count]) => ({
      label: periodMonths <= 3 ? label : label.split(" ")[0],
      count,
    }));
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [customers, period]);

  // ── Export CSV ───────────────────────────────────────────────────────────
  const handleExportRevenue = () => {
    const rows = [
      ["Mois", "Revenus (TTC)", "Sous-total", "TPS", "TVQ", "Nb factures"],
      ...revenueByMonth.map((r) => [
        r.label,
        r.revenue.toFixed(2),
        (r.revenue - r.tps - r.tvq).toFixed(2),
        r.tps.toFixed(2),
        r.tvq.toFixed(2),
        String(r.count),
      ]),
    ];
    exportCSV(rows, `rapport-revenus-${new Date().toISOString().slice(0, 10)}.csv`);
  };

  const handleExportInvoices = () => {
    const rows = [
      ["Numéro", "Client", "Véhicule", "Date", "Statut", "Sous-total", "TPS", "TVQ", "Total TTC"],
      ...filteredOrders.map((o) => [
        o.orderNumber,
        o.customerName,
        o.vehicleInfo,
        new Date(o.date).toLocaleDateString("fr-CA"),
        o.status,
        o.subtotal.toFixed(2),
        o.tpsAmount.toFixed(2),
        o.tvqAmount.toFixed(2),
        o.total.toFixed(2),
      ]),
    ];
    exportCSV(rows, `rapport-factures-${new Date().toISOString().slice(0, 10)}.csv`);
  };

  // ── KPI card ─────────────────────────────────────────────────────────────
  const KpiCard = ({
    label, value, sub, icon: Icon, trend, trendUp,
  }: {
    label: string;
    value: string;
    sub?: string;
    icon: React.ElementType;
    trend?: string;
    trendUp?: boolean;
  }) => (
    <Card className="bg-card border border-border rounded-xl shadow-sm">
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-2">
          <Icon weight="duotone" size={20} className="text-primary" />
          {trend && (
            <span className={`flex items-center gap-0.5 text-[10px] font-semibold ${trendUp ? "text-green-500" : "text-red-400"}`}>
              {trendUp ? <TrendUp size={12} weight="bold" /> : <TrendDown size={12} weight="bold" />}
              {trend}
            </span>
          )}
        </div>
        <p className="text-xl font-bold font-heading text-foreground leading-tight">{value}</p>
        <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
        {sub && <p className="text-[10px] text-muted-foreground mt-1 border-t border-border pt-1">{sub}</p>}
      </CardContent>
    </Card>
  );

  return (
    <section id="reports" className="bg-background min-h-screen px-4 py-8 md:px-8">
      {/* Header */}
      <div className="max-w-7xl mx-auto mb-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <p className="text-xs font-mono tracking-widest text-muted-foreground uppercase mb-1">Rapports</p>
            <h1 className="font-heading text-2xl font-semibold text-foreground tracking-tight">Rapports & Analyses</h1>
          </div>
          {/* Period selector */}
          <div className="flex gap-1.5 flex-wrap">
            {PERIODS.map((p) => (
              <button
                key={p}
                onClick={() => setPeriod(p)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                  period === p
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-background text-muted-foreground border-border hover:bg-muted"
                }`}
              >
                {p}
              </button>
            ))}
          </div>
        </div>
        <div className="mt-3 h-px bg-border" />
      </div>

      {/* Tabs */}
      <div className="max-w-7xl mx-auto mb-6">
        <div className="flex gap-1 overflow-x-auto pb-1">
          {TABS.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
                  activeTab === tab.id
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
              >
                <Icon size={15} weight="duotone" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      <div className="max-w-7xl mx-auto space-y-6">

        {/* ══════════════════════════ RÉSUMÉ DU JOUR ══════════════════════════ */}
        {activeTab === "today" && (
          <>
            {/* View toggle */}
            <div className="flex items-center gap-2">
              {(["day", "week", "month"] as const).map((v) => {
                const labels = { day: "Aujourd\'hui", week: "Cette semaine", month: "Ce mois-ci" };
                return (
                  <button
                    key={v}
                    onClick={() => setSummaryView(v)}
                    className={`px-4 py-1.5 rounded-full text-xs font-medium border transition-all ${
                      summaryView === v
                        ? "bg-primary text-primary-foreground border-primary"
                        : "bg-background text-muted-foreground border-border hover:bg-muted"
                    }`}
                  >
                    {labels[v]}
                  </button>
                );
              })}
              <span className="ml-auto text-xs text-muted-foreground">
                {new Date().toLocaleDateString("fr-CA", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
              </span>
            </div>

            {/* KPI row */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <KpiCard
                label={`Factures ${summaryLabel}`}
                value={String(summaryOrders.length)}
                sub={`${summaryPaid.length} payées · ${summaryUnpaid.length} impayées`}
                icon={Receipt}
              />
              <KpiCard
                label={`Revenus ${summaryLabel}`}
                value={fmtC(summaryRevenue)}
                sub={`TPS ${fmtC(summaryTPS)} · TVQ ${fmtC(summaryTVQ)}`}
                icon={CurrencyDollar}
              />
              <KpiCard
                label={`Estimations ${summaryLabel}`}
                value={String(summaryEstimates.length)}
                sub="Brouillons / soumissions"
                icon={Package}
              />
              <KpiCard
                label={`Clients servis ${summaryLabel}`}
                value={String(summaryServedNames.length)}
                sub={`${summaryCustomers.length} nouveau${summaryCustomers.length !== 1 ? "x" : ""}`}
                icon={UsersThree}
              />
            </div>

            {/* Factures du jour */}
            <Card className="bg-card border border-border rounded-xl shadow-sm overflow-hidden">
              <CardHeader className="pb-2 pt-5 px-5">
                <p className="text-xs font-mono tracking-widest text-muted-foreground uppercase">Factures</p>
                <CardTitle className="font-heading text-base font-semibold text-foreground mt-0.5">
                  Factures {summaryLabel} ({summaryOrders.length})
                </CardTitle>
              </CardHeader>
              <Separator />
              {summaryOrders.length === 0 ? (
                <CardContent className="py-12 text-center text-sm text-muted-foreground">
                  Aucune facture {summaryLabel}.
                </CardContent>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border bg-muted/30">
                        {["Numéro", "Client", "Véhicule", "Date", "Statut", "Total TTC"].map((h) => (
                          <th key={h} className="text-left px-4 py-2.5 text-[10px] font-semibold text-muted-foreground uppercase tracking-widest whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {summaryOrders.map((o) => {
                        const statusColors: Record<string, string> = {
                          "Payée": "text-green-600 bg-green-50 dark:bg-green-900/20",
                          "Non payée": "text-red-500 bg-red-50 dark:bg-red-900/20",
                          "Partielle": "text-amber-500 bg-amber-50 dark:bg-amber-900/20",
                          "Brouillon": "text-blue-500 bg-blue-50 dark:bg-blue-900/20",
                          "Soumission": "text-violet-500 bg-violet-50 dark:bg-violet-900/20",
                          "Estimation": "text-violet-500 bg-violet-50 dark:bg-violet-900/20",
                        };
                        return (
                          <tr key={o.id} className="border-b border-border hover:bg-muted/30 transition-colors">
                            <td className="px-4 py-3 font-mono text-xs font-semibold text-foreground whitespace-nowrap">{o.orderNumber}</td>
                            <td className="px-4 py-3 font-medium text-foreground">{o.customerName}</td>
                            <td className="px-4 py-3 text-xs text-muted-foreground">{o.vehicleInfo}</td>
                            <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">
                              {new Date(o.date).toLocaleDateString("fr-CA")}
                            </td>
                            <td className="px-4 py-3">
                              <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColors[o.status] ?? "text-muted-foreground bg-muted"}`}>
                                {o.status}
                              </span>
                            </td>
                            <td className="px-4 py-3 font-mono text-xs font-bold text-foreground">{fmtN(o.total)}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                    {summaryOrders.length > 0 && (
                      <tfoot>
                        <tr className="bg-muted/40">
                          <td colSpan={5} className="px-4 py-3 font-bold text-foreground text-xs">Total</td>
                          <td className="px-4 py-3 font-mono font-bold text-primary text-xs">{fmtN(summaryRevenue)}</td>
                        </tr>
                      </tfoot>
                    )}
                  </table>
                </div>
              )}
            </Card>

            {/* Clients servis */}
            <Card className="bg-card border border-border rounded-xl shadow-sm overflow-hidden">
              <CardHeader className="pb-2 pt-5 px-5">
                <p className="text-xs font-mono tracking-widest text-muted-foreground uppercase">Clients</p>
                <CardTitle className="font-heading text-base font-semibold text-foreground mt-0.5">
                  Clients servis {summaryLabel} ({summaryServedNames.length})
                </CardTitle>
              </CardHeader>
              <Separator />
              {summaryServedNames.length === 0 ? (
                <CardContent className="py-12 text-center text-sm text-muted-foreground">
                  Aucun client {summaryLabel}.
                </CardContent>
              ) : (
                <div className="divide-y divide-border">
                  {summaryServedNames.map((name) => {
                    const clientOrders = summaryOrders.filter((o) => o.customerName === name);
                    const clientRevenue = clientOrders.filter((o) => o.status === "Payée").reduce((s, o) => s + o.total, 0);
                    const isNew = summaryCustomers.some((c) => c.name === name);
                    return (
                      <div key={name} className="flex items-center justify-between px-5 py-3 hover:bg-muted/30 transition-colors">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                            <span className="text-xs font-bold text-primary">{name.charAt(0).toUpperCase()}</span>
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-medium text-foreground">{name}</span>
                              {isNew && (
                                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-green-50 dark:bg-green-900/20 text-green-600 font-semibold">Nouveau</span>
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground">{clientOrders.length} ordre{clientOrders.length !== 1 ? "s" : ""}</p>
                          </div>
                        </div>
                        <span className="font-mono text-sm font-semibold text-foreground">{fmtC(clientRevenue)}</span>
                      </div>
                    );
                  })}
                </div>
              )}
            </Card>

            {/* Estimations du jour */}
            {summaryEstimates.length > 0 && (
              <Card className="bg-card border border-border rounded-xl shadow-sm overflow-hidden">
                <CardHeader className="pb-2 pt-5 px-5">
                  <p className="text-xs font-mono tracking-widest text-muted-foreground uppercase">Estimations</p>
                  <CardTitle className="font-heading text-base font-semibold text-foreground mt-0.5">
                    Estimations / soumissions {summaryLabel} ({summaryEstimates.length})
                  </CardTitle>
                </CardHeader>
                <Separator />
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border bg-muted/30">
                        {["Numéro", "Client", "Véhicule", "Date", "Statut", "Montant"].map((h) => (
                          <th key={h} className="text-left px-4 py-2.5 text-[10px] font-semibold text-muted-foreground uppercase tracking-widest whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {summaryEstimates.map((o) => (
                        <tr key={o.id} className="border-b border-border hover:bg-muted/30 transition-colors">
                          <td className="px-4 py-3 font-mono text-xs font-semibold text-foreground">{o.orderNumber}</td>
                          <td className="px-4 py-3 font-medium text-foreground">{o.customerName}</td>
                          <td className="px-4 py-3 text-xs text-muted-foreground">{o.vehicleInfo}</td>
                          <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">
                            {new Date(o.date).toLocaleDateString("fr-CA")}
                          </td>
                          <td className="px-4 py-3">
                            <span className="text-xs px-2 py-0.5 rounded-full font-medium text-violet-500 bg-violet-50 dark:bg-violet-900/20">
                              {o.status}
                            </span>
                          </td>
                          <td className="px-4 py-3 font-mono text-xs font-semibold text-foreground">{fmtN(o.total)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>
            )}
          </>
        )}

        {/* ══════════════════════════ APERÇU ══════════════════════════ */}
        {activeTab === "overview" && (
          <>
            {/* KPIs */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
              <KpiCard
                label="Revenus (TTC)"
                value={fmtC(totalRevenue)}
                sub={`${paidCount} factures payées`}
                icon={CurrencyDollar}
              />
              <KpiCard
                label="Factures émises"
                value={String(invoiceCount)}
                sub={`${unpaidCount} impayées`}
                icon={Receipt}
              />
              <KpiCard
                label="Clients actifs"
                value={String(customers.length)}
                sub={`${newCustomersByMonth.reduce((s, m) => s + m.count, 0)} nouveaux`}
                icon={UsersThree}
              />
              <KpiCard
                label="Facture moyenne"
                value={fmtC(avgInvoice)}
                sub="parmi les factures payées"
                icon={ChartBar}
              />
              <KpiCard
                label="Impayés"
                value={fmtC(unpaidTotal)}
                sub={`${unpaidCount} en attente`}
                icon={Warning}
              />
            </div>

            {/* Revenue chart + status pie */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="lg:col-span-2 bg-card border border-border rounded-xl shadow-sm">
                <CardHeader className="pb-2 pt-5 px-5">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs font-mono tracking-widest text-muted-foreground uppercase">Revenus</p>
                      <CardTitle className="font-heading text-base font-semibold text-foreground mt-0.5">
                        Revenus mensuels (TTC)
                      </CardTitle>
                    </div>
                    <Button variant="outline" size="sm" onClick={handleExportRevenue} className="text-xs gap-1.5 rounded-lg border-border h-8">
                      <DownloadSimple size={14} weight="duotone" />
                      CSV
                    </Button>
                  </div>
                </CardHeader>
                <Separator />
                <CardContent className="pt-4 px-2 pb-4">
                  {orders.length === 0 ? (
                    <div className="h-48 flex items-center justify-center text-sm text-muted-foreground">
                      Aucune donnée disponible pour cette période.
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height={220}>
                      <BarChart data={revenueByMonth} barCategoryGap="30%">
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                        <XAxis dataKey="label" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
                        <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} width={50} tickFormatter={(v) => `${v} $`} />
                        <RechartsTooltip
                          contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px", fontSize: "12px" }}
                          labelStyle={{ color: "hsl(var(--foreground))", fontWeight: 600 }}
                          formatter={(value: unknown, name: unknown) => [`${(value as number).toFixed(2)} $`, name === "revenue" ? "Revenu TTC" : String(name)]}
                        />
                        <Bar dataKey="revenue" name="revenue" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  )}
                </CardContent>
              </Card>

              {/* Donut statut */}
              <Card className="bg-card border border-border rounded-xl shadow-sm">
                <CardHeader className="pb-2 pt-5 px-5">
                  <p className="text-xs font-mono tracking-widest text-muted-foreground uppercase">Statuts</p>
                  <CardTitle className="font-heading text-base font-semibold text-foreground mt-0.5">
                    Répartition des factures
                  </CardTitle>
                </CardHeader>
                <Separator />
                <CardContent className="pt-4 pb-4 flex flex-col items-center">
                  {invoiceCount === 0 ? (
                    <div className="h-40 flex items-center justify-center text-sm text-muted-foreground">
                      Aucune facture.
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height={160}>
                      <PieChart>
                        <Pie
                          data={statusBreakdown}
                          dataKey="value"
                          nameKey="name"
                          cx="50%"
                          cy="50%"
                          innerRadius={45}
                          outerRadius={70}
                          paddingAngle={2}
                        >
                          {statusBreakdown.map((entry, i) => (
                            <Cell key={i} fill={entry.color} />
                          ))}
                        </Pie>
                        <RechartsTooltip
                          contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px", fontSize: "12px" }}
                          formatter={(v: unknown, name: unknown) => [v as number, String(name)]}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  )}
                  <div className="w-full space-y-1.5 mt-2">
                    {statusBreakdown.map((s) => (
                      <div key={s.name} className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: s.color }} />
                          <span className="text-muted-foreground">{s.name}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-foreground">{s.value}</span>
                          <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-4">{s.pct}%</Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Tax summary */}
            <Card className="bg-card border border-border rounded-xl shadow-sm">
              <CardHeader className="pb-2 pt-5 px-5">
                <p className="text-xs font-mono tracking-widest text-muted-foreground uppercase">Taxes remises</p>
                <CardTitle className="font-heading text-base font-semibold text-foreground mt-0.5">
                  Récapitulatif TPS / TVQ — {period}
                </CardTitle>
              </CardHeader>
              <Separator />
              <CardContent className="px-5 pt-4 pb-5">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="p-4 rounded-xl bg-muted/40 border border-border">
                    <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Sous-total (avant taxes)</p>
                    <p className="text-2xl font-bold font-heading text-foreground">{fmtC(totalSubtotal)}</p>
                  </div>
                  <div className="p-4 rounded-xl bg-muted/40 border border-border">
                    <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">TPS collectée (5%)</p>
                    <p className="text-2xl font-bold font-heading text-foreground">{fmtC(totalTPS)}</p>
                  </div>
                  <div className="p-4 rounded-xl bg-muted/40 border border-border">
                    <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">TVQ collectée (9,975%)</p>
                    <p className="text-2xl font-bold font-heading text-foreground">{fmtC(totalTVQ)}</p>
                  </div>
                </div>
                <div className="mt-4 p-4 rounded-xl bg-primary/8 border border-primary/20 flex items-center justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground">Total taxes à remettre</p>
                    <p className="text-base font-bold text-foreground mt-0.5">{fmtC(totalTPS + totalTVQ)}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground">Revenus bruts (TTC)</p>
                    <p className="text-base font-bold text-primary mt-0.5">{fmtC(totalRevenue)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        )}

        {/* ══════════════════════════ REVENUS ══════════════════════════ */}
        {activeTab === "revenue" && (
          <>
            <div className="flex justify-end">
              <Button variant="outline" size="sm" onClick={handleExportRevenue} className="text-xs gap-1.5 rounded-lg border-border">
                <DownloadSimple size={14} weight="duotone" />
                Exporter CSV
              </Button>
            </div>

            {/* Revenue trend line */}
            <Card className="bg-card border border-border rounded-xl shadow-sm">
              <CardHeader className="pb-2 pt-5 px-5">
                <p className="text-xs font-mono tracking-widest text-muted-foreground uppercase">Tendance</p>
                <CardTitle className="font-heading text-base font-semibold text-foreground mt-0.5">
                  Revenus & volume — {period}
                </CardTitle>
              </CardHeader>
              <Separator />
              <CardContent className="pt-4 px-2 pb-4">
                {orders.length === 0 ? (
                  <div className="h-48 flex items-center justify-center text-sm text-muted-foreground">Aucune donnée.</div>
                ) : (
                  <ResponsiveContainer width="100%" height={260}>
                    <LineChart data={revenueByMonth}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                      <XAxis dataKey="label" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
                      <YAxis yAxisId="left" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} width={55} tickFormatter={(v) => `${v} $`} />
                      <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} width={30} />
                      <RechartsTooltip
                        contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px", fontSize: "12px" }}
                        formatter={(value: unknown, name: unknown) => [
                          name === "revenue" ? `${(value as number).toFixed(2)} $` : value as number,
                          name === "revenue" ? "Revenu TTC" : "Nb factures",
                        ]}
                      />
                      <Legend wrapperStyle={{ fontSize: "12px", paddingTop: "8px" }} formatter={(v) => (v === "revenue" ? "Revenu TTC" : "Nb factures")} />
                      <Line yAxisId="left" type="monotone" dataKey="revenue" stroke="hsl(var(--primary))" strokeWidth={2.5} dot={{ r: 3, fill: "hsl(var(--primary))" }} activeDot={{ r: 5 }} />
                      <Line yAxisId="right" type="monotone" dataKey="count" stroke="hsl(var(--muted-foreground))" strokeWidth={1.5} strokeDasharray="4 3" dot={{ r: 2 }} />
                    </LineChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>

            {/* TPS/TVQ stacked */}
            <Card className="bg-card border border-border rounded-xl shadow-sm">
              <CardHeader className="pb-2 pt-5 px-5">
                <p className="text-xs font-mono tracking-widest text-muted-foreground uppercase">Taxes</p>
                <CardTitle className="font-heading text-base font-semibold text-foreground mt-0.5">
                  TPS & TVQ collectées par mois
                </CardTitle>
              </CardHeader>
              <Separator />
              <CardContent className="pt-4 px-2 pb-4">
                {orders.length === 0 ? (
                  <div className="h-48 flex items-center justify-center text-sm text-muted-foreground">Aucune donnée.</div>
                ) : (
                  <ResponsiveContainer width="100%" height={220}>
                    <BarChart data={revenueByMonth} barCategoryGap="30%">
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                      <XAxis dataKey="label" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} width={50} tickFormatter={(v) => `${v} $`} />
                      <RechartsTooltip
                        contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px", fontSize: "12px" }}
                        formatter={(v: unknown, name: unknown) => [`${(v as number).toFixed(2)} $`, (name as string) === "tps" ? "TPS 5%" : "TVQ 9,975%"]}
                      />
                      <Legend wrapperStyle={{ fontSize: "12px" }} formatter={(v) => (v === "tps" ? "TPS 5%" : "TVQ 9,975%")} />
                      <Bar dataKey="tps" name="tps" stackId="tax" fill="hsl(var(--primary))" radius={[0, 0, 0, 0]} opacity={0.8} />
                      <Bar dataKey="tvq" name="tvq" stackId="tax" fill="hsl(var(--muted-foreground))" radius={[3, 3, 0, 0]} opacity={0.6} />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>

            {/* Monthly detail table */}
            <Card className="bg-card border border-border rounded-xl shadow-sm overflow-hidden">
              <CardHeader className="pb-2 pt-5 px-5">
                <p className="text-xs font-mono tracking-widest text-muted-foreground uppercase">Détail mensuel</p>
                <CardTitle className="font-heading text-base font-semibold text-foreground mt-0.5">Tableau des revenus par mois</CardTitle>
              </CardHeader>
              <Separator />
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border bg-muted/30">
                      {["Mois", "Nb factures", "Sous-total", "TPS 5%", "TVQ 9,975%", "Total TTC"].map((h) => (
                        <th key={h} className="text-left px-4 py-2.5 text-[10px] font-semibold text-muted-foreground uppercase tracking-widest whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {revenueByMonth.map((row, i) => {
                      const sub = row.revenue - row.tps - row.tvq;
                      return (
                        <tr key={i} className="border-b border-border hover:bg-muted/30 transition-colors">
                          <td className="px-4 py-3 font-medium text-foreground">{row.label}</td>
                          <td className="px-4 py-3 text-muted-foreground text-center">{row.count}</td>
                          <td className="px-4 py-3 font-mono text-foreground">{fmtN(sub)}</td>
                          <td className="px-4 py-3 font-mono text-foreground">{fmtN(row.tps)}</td>
                          <td className="px-4 py-3 font-mono text-foreground">{fmtN(row.tvq)}</td>
                          <td className="px-4 py-3 font-mono font-semibold text-foreground">{fmtN(row.revenue)}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                  <tfoot>
                    <tr className="bg-muted/40">
                      <td className="px-4 py-3 font-bold text-foreground">Total</td>
                      <td className="px-4 py-3 font-bold text-center text-foreground">{invoiceCount}</td>
                      <td className="px-4 py-3 font-mono font-bold text-foreground">{fmtN(totalSubtotal)}</td>
                      <td className="px-4 py-3 font-mono font-bold text-foreground">{fmtN(totalTPS)}</td>
                      <td className="px-4 py-3 font-mono font-bold text-foreground">{fmtN(totalTVQ)}</td>
                      <td className="px-4 py-3 font-mono font-bold text-primary">{fmtN(totalRevenue)}</td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </Card>
          </>
        )}

        {/* ══════════════════════════ FACTURES ══════════════════════════ */}
        {activeTab === "invoices" && (
          <>
            <div className="flex justify-end">
              <Button variant="outline" size="sm" onClick={handleExportInvoices} className="text-xs gap-1.5 rounded-lg border-border">
                <DownloadSimple size={14} weight="duotone" />
                Exporter CSV
              </Button>
            </div>

            {/* Status KPIs */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <KpiCard label="Total émises" value={String(invoiceCount)} icon={Receipt} />
              <KpiCard label="Payées" value={String(paidCount)} icon={CheckCircle} />
              <KpiCard label="Non payées" value={String(unpaidCount)} icon={Warning} />
              <KpiCard label="Facture moyenne" value={fmtC(avgInvoice)} icon={CurrencyDollar} />
            </div>

            {/* Full invoice list */}
            <Card className="bg-card border border-border rounded-xl shadow-sm overflow-hidden">
              <CardHeader className="pb-2 pt-5 px-5">
                <p className="text-xs font-mono tracking-widest text-muted-foreground uppercase">Liste complète</p>
                <CardTitle className="font-heading text-base font-semibold text-foreground mt-0.5">
                  Factures — {period} ({filteredOrders.length})
                </CardTitle>
              </CardHeader>
              <Separator />
              {filteredOrders.length === 0 ? (
                <CardContent className="py-12 text-center text-sm text-muted-foreground">
                  Aucune facture pour cette période.
                </CardContent>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border bg-muted/30">
                        {["Numéro", "Client", "Véhicule", "Date", "Statut", "Sous-total", "TPS", "TVQ", "Total TTC"].map((h) => (
                          <th key={h} className="text-left px-4 py-2.5 text-[10px] font-semibold text-muted-foreground uppercase tracking-widest whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {filteredOrders.map((o) => {
                        const statusColors: Record<string, string> = {
                          "Payée": "text-green-600 bg-green-50 dark:bg-green-900/20",
                          "Non payée": "text-red-500 bg-red-50 dark:bg-red-900/20",
                          "Partielle": "text-amber-500 bg-amber-50 dark:bg-amber-900/20",
                        };
                        return (
                          <tr key={o.id} className="border-b border-border hover:bg-muted/30 transition-colors group">
                            <td className="px-4 py-3 font-mono text-xs font-semibold text-foreground whitespace-nowrap">{o.orderNumber}</td>
                            <td className="px-4 py-3 font-medium text-foreground">{o.customerName}</td>
                            <td className="px-4 py-3 text-xs text-muted-foreground">{o.vehicleInfo}</td>
                            <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">{new Date(o.date).toLocaleDateString("fr-CA")}</td>
                            <td className="px-4 py-3">
                              <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColors[o.status] ?? "text-muted-foreground bg-muted"}`}>
                                {o.status}
                              </span>
                            </td>
                            <td className="px-4 py-3 font-mono text-xs text-foreground">{fmtN(o.subtotal)}</td>
                            <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{fmtN(o.tpsAmount)}</td>
                            <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{fmtN(o.tvqAmount)}</td>
                            <td className="px-4 py-3 font-mono text-xs font-bold text-foreground">{fmtN(o.total)}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </Card>
          </>
        )}

        {/* ══════════════════════════ CLIENTS ══════════════════════════ */}
        {activeTab === "customers" && (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <KpiCard label="Clients totaux" value={String(customers.length)} icon={UsersThree} />
              <KpiCard label="Clients avec factures" value={String(customerOrderMap.length)} icon={Receipt} />
              <KpiCard label="Nouveaux (période)" value={String(newCustomersByMonth.reduce((s, m) => s + m.count, 0))} icon={TrendUp} />
            </div>

            {/* New customers by month */}
            <Card className="bg-card border border-border rounded-xl shadow-sm">
              <CardHeader className="pb-2 pt-5 px-5">
                <p className="text-xs font-mono tracking-widest text-muted-foreground uppercase">Acquisition</p>
                <CardTitle className="font-heading text-base font-semibold text-foreground mt-0.5">
                  Nouveaux clients par mois
                </CardTitle>
              </CardHeader>
              <Separator />
              <CardContent className="pt-4 px-2 pb-4">
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={newCustomersByMonth} barCategoryGap="35%">
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                    <XAxis dataKey="label" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} width={24} allowDecimals={false} />
                    <RechartsTooltip
                      contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px", fontSize: "12px" }}
                      formatter={(v: unknown) => [v as number, "Nouveaux clients"]}
                    />
                    <Bar dataKey="count" name="count" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Top customers */}
            <Card className="bg-card border border-border rounded-xl shadow-sm overflow-hidden">
              <CardHeader className="pb-2 pt-5 px-5">
                <p className="text-xs font-mono tracking-widest text-muted-foreground uppercase">Fidélité</p>
                <CardTitle className="font-heading text-base font-semibold text-foreground mt-0.5">
                  Meilleurs clients par revenus
                </CardTitle>
              </CardHeader>
              <Separator />
              {topCustomers.length === 0 ? (
                <CardContent className="py-10 text-center text-sm text-muted-foreground">Aucune donnée.</CardContent>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border bg-muted/30">
                        {["#", "Client", "Nb visites", "Revenus générés"].map((h) => (
                          <th key={h} className="text-left px-4 py-2.5 text-[10px] font-semibold text-muted-foreground uppercase tracking-widest">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {topCustomers.map((c, i) => (
                        <tr key={c.name} className="border-b border-border hover:bg-muted/30 transition-colors">
                          <td className="px-4 py-3 text-xs text-muted-foreground font-mono">#{i + 1}</td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                                <span className="text-xs font-bold text-primary">{c.name.charAt(0).toUpperCase()}</span>
                              </div>
                              <span className="font-medium text-foreground text-sm">{c.name}</span>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-sm text-center text-foreground">{c.count}</td>
                          <td className="px-4 py-3 font-mono text-sm font-semibold text-foreground">{fmtC(c.total)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </Card>
          </>
        )}

        {/* ══════════════════════════ SERVICES ══════════════════════════ */}
        {activeTab === "services" && (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <KpiCard label="Ordres de travail" value={String(filteredOrders.length)} icon={Wrench} />
              <KpiCard label="Véhicules uniques" value={String(new Set(filteredOrders.map((o) => o.vehicleInfo)).size)} icon={Car} />
              <KpiCard label="Durée moy. (estimation)" value="2,4 h" icon={Clock} sub="Calculé bientôt" />
            </div>

            {/* Placeholder for future mechanic/service breakdown */}
            <Card className="bg-card border border-border rounded-xl shadow-sm">
              <CardHeader className="pb-2 pt-5 px-5">
                <p className="text-xs font-mono tracking-widest text-muted-foreground uppercase">Services</p>
                <CardTitle className="font-heading text-base font-semibold text-foreground mt-0.5">
                  Récapitulatif des ordres de travail
                </CardTitle>
              </CardHeader>
              <Separator />
              {filteredOrders.length === 0 ? (
                <CardContent className="py-12 text-center text-sm text-muted-foreground">Aucun ordre pour cette période.</CardContent>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border bg-muted/30">
                        {["Numéro", "Client", "Véhicule", "Date", "Statut", "Total"].map((h) => (
                          <th key={h} className="text-left px-4 py-2.5 text-[10px] font-semibold text-muted-foreground uppercase tracking-widest whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {filteredOrders.slice(0, 20).map((o) => (
                        <tr key={o.id} className="border-b border-border hover:bg-muted/30 transition-colors">
                          <td className="px-4 py-3 font-mono text-xs font-semibold text-foreground">{o.orderNumber}</td>
                          <td className="px-4 py-3 text-sm font-medium text-foreground">{o.customerName}</td>
                          <td className="px-4 py-3 text-xs text-muted-foreground">{o.vehicleInfo}</td>
                          <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">{new Date(o.date).toLocaleDateString("fr-CA")}</td>
                          <td className="px-4 py-3">
                            <Badge variant={o.status === "Payée" ? "default" : o.status === "Non payée" ? "destructive" : "secondary"} className="text-xs px-2 py-0 h-4">
                              {o.status}
                            </Badge>
                          </td>
                          <td className="px-4 py-3 font-mono text-xs font-semibold text-foreground">{fmtC(o.total)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </Card>
          </>
        )}
      </div>
    </section>
  );
}
