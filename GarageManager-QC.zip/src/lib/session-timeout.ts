import type { UserRole } from "./permissions";

/**
 * Durée d'inactivité avant verrouillage de session, par rôle (millisecondes).
 * L'administrateur peut rester connecté plus longtemps.
 * Les rôles atelier ont un délai court pour raisons de sécurité.
 */
export const IDLE_TIMEOUT_BY_ROLE: Record<string, number> = {
  Admin: 60 * 60 * 1000, // 60 minutes
  Gérant: 45 * 60 * 1000, // 45 minutes
  "Chef mécanicien": 30 * 60 * 1000, // 30 minutes
  Mécanicien: 20 * 60 * 1000, // 20 minutes
  Apprenti: 15 * 60 * 1000, // 15 minutes
  Réceptionniste: 30 * 60 * 1000, // 30 minutes
  Comptable: 45 * 60 * 1000, // 45 minutes
};

const DEFAULT_TIMEOUT = 20 * 60 * 1000; // 20 min par défaut

/** Retourne le timeout d'inactivité (ms) pour un rôle donné. */
export function getIdleTimeout(role: UserRole): number {
  return IDLE_TIMEOUT_BY_ROLE[role] ?? DEFAULT_TIMEOUT;
}

/** Durée de l'avertissement avant verrouillage (même pour tous les rôles). */
export const IDLE_WARNING_MS = 60_000; // 60 secondes d'avertissement

/** Clé sessionStorage pour marquer la dernière activité */
export const LAST_ACTIVITY_KEY = "garagemanager_last_activity";
