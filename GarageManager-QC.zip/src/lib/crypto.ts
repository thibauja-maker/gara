/**
 * GarageManager — Chiffrement AES-GCM natif (Web Crypto API)
 * Aucune dépendance externe — fonctionne dans tous les navigateurs modernes.
 *
 * Stratégie :
 *  - Clé dérivée via PBKDF2 à partir d'un secret d'application fixe + sel aléatoire
 *  - Chaque valeur chiffrée est stockée sous la forme : base64(sel) + "." + base64(iv) + "." + base64(ciphertext)
 *  - Le sel et l'IV sont regénérés à chaque écriture (IND-CPA)
 */

const APP_SECRET = "garagemanager-v1-secure-storage-key-2024";
const PBKDF2_ITERATIONS = 100_000;

// ── Utilitaires base64 ────────────────────────────────────────────────────────
function bufToBase64(buf: ArrayBuffer): string {
  return btoa(String.fromCharCode(...new Uint8Array(buf)));
}

function base64ToBuf(b64: string): Uint8Array {
  return Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
}

// ── Dérivation de clé ─────────────────────────────────────────────────────────
async function deriveKey(salt: Uint8Array): Promise<CryptoKey> {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    "raw",
    enc.encode(APP_SECRET),
    { name: "PBKDF2" },
    false,
    ["deriveKey"],
  );
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: salt.buffer as ArrayBuffer,
      iterations: PBKDF2_ITERATIONS,
      hash: "SHA-256",
    },
    keyMaterial,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"],
  );
}

// ── Chiffrement ───────────────────────────────────────────────────────────────
export async function encryptValue(plaintext: string): Promise<string> {
  const enc = new TextEncoder();
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await deriveKey(salt);

  const cipherBuf = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    enc.encode(plaintext),
  );

  return `${bufToBase64(salt.buffer as ArrayBuffer)}.${bufToBase64(iv.buffer as ArrayBuffer)}.${bufToBase64(cipherBuf)}`;
}

// ── Déchiffrement ─────────────────────────────────────────────────────────────
export async function decryptValue(token: string): Promise<string> {
  const parts = token.split(".");
  if (parts.length !== 3) throw new Error("Token invalide");

  const [saltB64, ivB64, cipherB64] = parts;
  const salt = base64ToBuf(saltB64);
  const iv = base64ToBuf(ivB64);
  const cipherBuf = base64ToBuf(cipherB64);
  const key = await deriveKey(salt);

  const plainBuf = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: iv as unknown as BufferSource },
    key,
    cipherBuf.buffer as ArrayBuffer,
  );

  return new TextDecoder().decode(plainBuf);
}

// ── Chiffrement synchrone (léger, XOR + base64) — pour données non-critiques ─
// Utilisé pour éviter l'async dans les hooks React tout en masquant les données
// lisibles à l'œil nu dans localStorage (ex. noms, rôles).
// NOTE: Ce n'est PAS du chiffrement fort — utilisez encryptValue/decryptValue
// pour les mots de passe et les NIP.
export function obfuscate(value: string): string {
  const key = APP_SECRET;
  const result = Array.from(value).map((char, i) =>
    String.fromCharCode(char.charCodeAt(0) ^ key.charCodeAt(i % key.length)),
  );
  return btoa(result.join(""));
}

export function deobfuscate(encoded: string): string {
  try {
    const key = APP_SECRET;
    const decoded = atob(encoded);
    return Array.from(decoded)
      .map((char, i) =>
        String.fromCharCode(
          char.charCodeAt(0) ^ key.charCodeAt(i % key.length),
        ),
      )
      .join("");
  } catch {
    return "";
  }
}

// ── Hash à sens unique (pour comparaison de mots de passe sans les stocker en clair) ─
export async function hashPassword(
  password: string,
  salt?: string,
): Promise<string> {
  const enc = new TextEncoder();
  const actualSalt =
    salt ?? bufToBase64(crypto.getRandomValues(new Uint8Array(16)).buffer as ArrayBuffer);
  const saltBytes = base64ToBuf(actualSalt);

  const keyMaterial = await crypto.subtle.importKey(
    "raw",
    enc.encode(password),
    { name: "PBKDF2" },
    false,
    ["deriveKey"],
  );
  const derived = await crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: saltBytes.buffer as ArrayBuffer,
      iterations: PBKDF2_ITERATIONS,
      hash: "SHA-256",
    },
    keyMaterial,
    { name: "AES-GCM", length: 256 },
    true,
    ["encrypt"],
  );
  const exported = await crypto.subtle.exportKey("raw", derived);
  return `${actualSalt}:${bufToBase64(exported)}`;
}

export async function verifyPassword(
  password: string,
  hash: string,
): Promise<boolean> {
  try {
    const [salt] = hash.split(":");
    const rehash = await hashPassword(password, salt);
    return rehash === hash;
  } catch {
    return false;
  }
}

// ── Chiffrement synchrone de bloc JSON ─────────────────────────────────────────
// Wrapper pratique pour chiffrer/déchiffrer des objets JSON entiers
export function encryptObjectSync(obj: unknown): string {
  return obfuscate(JSON.stringify(obj));
}

export function decryptObjectSync<T>(encoded: string): T | null {
  try {
    return JSON.parse(deobfuscate(encoded)) as T;
  } catch {
    return null;
  }
}
