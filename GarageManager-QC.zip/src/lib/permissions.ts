// ─── Rôles définis ────────────────────────────────────────────────────────────
export type UserRole =
  | "Admin"
  | "Gérant"
  | "Chef mécanicien"
  | "Mécanicien"
  | "Apprenti"
  | "Réceptionniste"
  | "Comptable"
  | string; // catch-all pour futurs rôles

// ─── Sections de navigation ────────────────────────────────────────────────────
export type SectionId =
  | "dashboard"
  | "repair-orders"
  | "bays-schedule"
  | "calendar"
  | "invoices-taxes"
  | "customers"
  | "inventory"
  | "estimation"
  | "parts-catalog"
  | "reports"
  | "integrations"
  | "suppliers";

// ─── Permissions par rôle ─────────────────────────────────────────────────────
// Chaque rôle liste les sections AUTORISÉES.
// Admin & Gérant ont tout accès.
const ROLE_PERMISSIONS: Record<string, SectionId[]> = {
  Admin: [
    "dashboard",
    "repair-orders",
    "bays-schedule",
    "calendar",
    "invoices-taxes",
    "customers",
    "inventory",
    "estimation",
    "parts-catalog",
    "reports",
    "integrations",
    "suppliers",
  ],
  Gérant: [
    "dashboard",
    "repair-orders",
    "bays-schedule",
    "calendar",
    "invoices-taxes",
    "customers",
    "inventory",
    "estimation",
    "parts-catalog",
    "reports",
    "integrations",
    "suppliers",
  ],
  "Chef mécanicien": [
    "dashboard",
    "repair-orders",
    "bays-schedule",
    "calendar",
    "customers",
    "inventory",
    "estimation",
    "parts-catalog",
    "suppliers",
  ],
  Mécanicien: [
    "dashboard",
    "repair-orders",
    "bays-schedule",
    "calendar",
    "parts-catalog",
  ],
  Apprenti: [
    "dashboard",
    "repair-orders",
    "bays-schedule",
    "calendar",
    "parts-catalog",
  ],
  Réceptionniste: [
    "dashboard",
    "repair-orders",
    "calendar",
    "customers",
    "invoices-taxes",
    "estimation",
    "suppliers",
  ],
  Comptable: ["dashboard", "invoices-taxes", "reports", "customers"],
};

// Accès par défaut si le rôle n'est pas reconnu
const DEFAULT_PERMISSIONS: SectionId[] = ["dashboard"];

/**
 * Retourne la liste des sections autorisées pour un rôle donné.
 */
export function getAllowedSections(role: UserRole): SectionId[] {
  return ROLE_PERMISSIONS[role] ?? DEFAULT_PERMISSIONS;
}

/**
 * Vérifie si un rôle peut accéder à une section donnée.
 */
export function canAccess(role: UserRole, section: SectionId): boolean {
  return getAllowedSections(role).includes(section);
}

// ─── Permissions de menu admin ────────────────────────────────────────────────
// Contrôle qui peut voir les entrées de menu "Paramètres", "Postes", "Facturation"
export function canManageSettings(role: UserRole): boolean {
  return ["Admin", "Gérant"].includes(role);
}

export function canManageWorkstations(role: UserRole): boolean {
  return role === "Admin";
}

export function canAccessBilling(role: UserRole): boolean {
  return ["Admin", "Gérant", "Comptable"].includes(role);
}

export function canAccessReports(role: UserRole): boolean {
  return ["Admin", "Gérant", "Comptable"].includes(role);
}

export function canAccessIntegrations(role: UserRole): boolean {
  return ["Admin", "Gérant"].includes(role);
}
