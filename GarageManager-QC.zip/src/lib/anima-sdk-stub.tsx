/**
 * Stub local pour @animaapp/playground-react-sdk
 * Remplace les hooks useQuery / useMutation / useLazyQuery par une
 * implémentation basée sur localStorage, sans dépendance externe.
 */

import { useState, useEffect, useCallback, useRef } from "react";

// ── Types exportés ────────────────────────────────────────────────────────────

export interface Customer {
  id: string;
  orgId: string;
  name: string;
  phone?: string;
  email?: string;
  address?: string;
  city?: string;
  postalCode?: string;
  notes?: string;
  vehicleInfo?: string;
  vehicles?: Vehicle[] | string;
  createdAt: string;
}

export interface Vehicle {
  id: string;
  customerId: string;
  orgId: string;
  make: string;
  model: string;
  year: number;
  plate?: string;
  vin?: string;
  mileage?: number;
  color?: string;
  notes?: string;
}

export interface RepairOrder {
  id: string;
  orgId: string;
  orderNumber: string;
  customerName: string;
  phone?: string;
  vehicleInfo: string;
  plate?: string;
  mileage?: string;
  mechanic?: string;
  jobDesc?: string;
  status: string;
  paymentStatus?: string;
  paymentMethod?: string;
  amountPaid?: number;
  parts: Array<{ id: number; description: string; partNumber?: string; qty: number; unitPrice: number }>;
  labor: Array<{ id: number; description: string; hours: number; rate: number }>;
  supplies: Array<{ id: number; description: string; amount: number }>;
  subtotal: number;
  tpsAmount: number;
  tvqAmount: number;
  total: number;
  date: string;
  createdAt: string;
}

export interface Appointment {
  id: string;
  orgId: string;
  title: string;
  customerName: string;
  phone?: string;
  vehicleInfo?: string;
  bay: string;
  date: string;
  startHour: number;
  duration: number;
  status: string;
  notes?: string;
  mechanic?: string;
  createdAt: string;
}

export interface InventoryItem {
  id: string;
  orgId: string;
  name: string;
  partNumber?: string;
  description?: string;
  category?: string;
  brand?: string;
  location?: string;
  unit?: string;
  price?: number;
  qty: number;
  minQty?: number;
  unitCost: number;
  unitPrice: number;
  supplier?: string;
  notes?: string;
  createdAt: string;
}

export interface Estimation {
  id: string;
  orgId: string;
  estimateNumber: string;
  customerName: string;
  phone?: string;
  vehicleInfo: string;
  status: string;
  parts: Array<{ id: number; description: string; partNumber?: string; qty: number; unitPrice: number }>;
  labor: Array<{ id: number; description: string; hours: number; rate: number }>;
  supplies: Array<{ id: number; description: string; amount: number }>;
  subtotal: number;
  tpsAmount: number;
  tvqAmount: number;
  total: number;
  notes?: string;
  validUntil?: string;
  createdAt: string;
}

export interface Supplier {
  id: string;
  orgId: string;
  name: string;
  companyName: string;
  contactName?: string;
  phone?: string;
  email?: string;
  address?: string;
  city?: string;
  postalCode?: string;
  website?: string;
  accountNumber?: string;
  cardImageUrl?: string;
  tags?: string;
  category?: string;
  notes?: string;
  createdAt: string;
}

export interface RepairOrderItem {
  id: string;
  orgId: string;
  repairOrderId: string;
  type: string;
  description: string;
  qty?: number;
  unitPrice?: number;
  hours?: number;
  rate?: number;
  amount?: number;
}

// ── Registre des modèles ──────────────────────────────────────────────────────

type ModelName =
  | "Customer"
  | "Vehicle"
  | "RepairOrder"
  | "RepairOrderItem"
  | "Appointment"
  | "InventoryItem"
  | "Estimation"
  | "Supplier";

function storageKey(model: ModelName, orgId?: string): string {
  return orgId ? `garagemanager_${orgId}_data_${model}` : `garagemanager_data_${model}`;
}

function loadAll<T extends { id: string }>(model: ModelName, orgId?: string): T[] {
  try {
    const raw = localStorage.getItem(storageKey(model, orgId));
    return raw ? (JSON.parse(raw) as T[]) : [];
  } catch {
    return [];
  }
}

function saveAll<T>(model: ModelName, items: T[], orgId?: string): void {
  try {
    localStorage.setItem(storageKey(model, orgId), JSON.stringify(items));
  } catch {
    // quota exceeded
  }
}

function genId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

// ── Événement global pour synchroniser les hooks ──────────────────────────────

const DB_CHANGE_EVENT = "garagemanager_db_change";

function notifyChange(model: ModelName) {
  window.dispatchEvent(new CustomEvent(DB_CHANGE_EVENT, { detail: { model } }));
}

// ── Filtrage simple ───────────────────────────────────────────────────────────

function applyWhere<T extends Record<string, unknown>>(
  items: T[],
  where?: Record<string, unknown>
): T[] {
  if (!where) return items;
  return items.filter((item) =>
    Object.entries(where).every(([k, v]) => item[k] === v)
  );
}
function applyOrderBy<T extends Record<string, unknown>>(
  items: T[],
  orderBy?: Record<string, "asc" | "desc">
): T[] {
  if (!orderBy) return items;
  const [field, dir] = Object.entries(orderBy)[0];
  return [...items].sort((a, b) => {
    const av = a[field] as string | number;
    const bv = b[field] as string | number;
    if (av < bv) return dir === "asc" ? -1 : 1;
    if (av > bv) return dir === "asc" ? 1 : -1;
    return 0;
  });
}

// ── useQuery ─────────────────────────────────────────────────────────────────

export function useQuery<T extends { id: string }>(
  model: ModelName,
  options?: {
    where?: Record<string, unknown>;
    orderBy?: Record<string, "asc" | "desc">;
  }
): { data: T[] | undefined; isPending: boolean; error: null } {
  const orgId = options?.where?.orgId as string | undefined;

  const [data, setData] = useState<T[] | undefined>(() => {
    const all = loadAll<T>(model, orgId) as unknown as Record<string, unknown>[];
    const filtered = applyWhere(all, options?.where);
    return applyOrderBy(filtered, options?.orderBy) as unknown as T[];
  });

  const optionsRef = useRef(options);
  optionsRef.current = options;

  useEffect(() => {
    const refresh = () => {
      const currentOrgId = optionsRef.current?.where?.orgId as string | undefined;
      const all = loadAll<T>(model, currentOrgId) as unknown as Record<string, unknown>[];
      const filtered = applyWhere(all, optionsRef.current?.where);
      setData(applyOrderBy(filtered, optionsRef.current?.orderBy) as unknown as T[]);
    };

    const handler = (e: Event) => {
      const evt = e as CustomEvent<{ model: ModelName }>;
      if (evt.detail.model === model) refresh();
    };

    window.addEventListener(DB_CHANGE_EVENT, handler);
    return () => window.removeEventListener(DB_CHANGE_EVENT, handler);
  }, [model]);

  return { data, isPending: false, error: null };
}

// ── useLazyQuery ──────────────────────────────────────────────────────────────

export function useLazyQuery<T extends { id: string }>(
  model: ModelName
): {
  query: (options?: { where?: Record<string, unknown>; orderBy?: Record<string, "asc" | "desc"> }) => T[];
  fetch: (options?: { where?: Record<string, unknown>; orderBy?: Record<string, "asc" | "desc"> }) => T[];
  data: T[] | undefined;
  isPending: boolean;
} {
  const [data, setData] = useState<T[] | undefined>(undefined);

  const run = useCallback(
    (options?: { where?: Record<string, unknown>; orderBy?: Record<string, "asc" | "desc"> }) => {
      const orgId = options?.where?.orgId as string | undefined;
      const all = loadAll<T>(model, orgId) as unknown as Record<string, unknown>[];
      const filtered = applyWhere(all, options?.where);
      const sorted = applyOrderBy(filtered, options?.orderBy) as unknown as T[];
      setData(sorted);
      return sorted;
    },
    [model]
  );

  return { query: run, fetch: run, data, isPending: false };
}

// ── useMutation ───────────────────────────────────────────────────────────────

export function useMutation<T extends { id: string }>(
  model: ModelName
): {
  create: (data: Record<string, unknown>) => T;
  update: (id: string, data: Record<string, unknown>) => T | undefined;
  remove: (id: string, orgId?: string) => void;
  isPending: boolean;
} {
  const create = useCallback(
    (input: Record<string, unknown>): T => {
      const orgId = input.orgId as string | undefined;
      const all = loadAll<T>(model, orgId);
      const item = {
        ...input,
        id: (input.id as string | undefined) ?? genId(),
        createdAt: (input.createdAt as string | undefined) ?? new Date().toISOString(),
      } as unknown as T;
      all.push(item);
      saveAll(model, all, orgId);
      notifyChange(model);
      return item;
    },
    [model]
  );

  const update = useCallback(
    (id: string, data: Record<string, unknown>): T | undefined => {
      const orgId = data.orgId as string | undefined;
      const all = loadAll<T>(model, orgId);
      const idx = all.findIndex((i) => i.id === id);
      if (idx === -1) return undefined;
      all[idx] = { ...all[idx], ...data } as T;
      saveAll(model, all, orgId);
      notifyChange(model);
      return all[idx];
    },
    [model]
  );

  const remove = useCallback(
    (id: string, orgId?: string): void => {
      const all = loadAll<T>(model, orgId).filter((i) => i.id !== id);
      saveAll(model, all, orgId);
      notifyChange(model);
    },
    [model]
  );

  return { create, update, remove, isPending: false };
}

// ── AnimaProvider (no-op wrapper) ─────────────────────────────────────────────

export function AnimaProvider({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
